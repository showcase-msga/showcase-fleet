# support_screen: "Remove the driver too" (trial 7). Takes the Virtual Display Driver off this NUC:
# the virtual device, the driver package and its settings folder. Trial 7 installs trust the driver's publisher only
# while installing, so there's no trust left to remove (one that was there before Fleet is never touched).
# Remove the Support screen module first, so the real screen is the main display again.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$Driver = Join-Path $PSScriptRoot 'driver'
if (-not (Test-Admin)) { Fail 'Needs admin.'; return }
if (Get-ScheduledTask -TaskName 'showcase_fleet_support_screen' -ErrorAction SilentlyContinue) { Fail 'Remove the Support screen module first, so the real screen becomes the main display again.'; return }

$ErrorActionPreference = 'Continue'   # devcon's stderr would otherwise stop the script
$out = & (Join-Path $Driver 'devcon.exe') remove 'Root\MttVDD' 2>&1
$out | Where-Object { "$_".Trim() } | ForEach-Object { Info "  devcon: $_" }
$pkgs = @(Get-WindowsDriver -Online -ErrorAction SilentlyContinue | Where-Object { $_.OriginalFileName -like '*mttvdd.inf*' })
foreach ($p in $pkgs) { Step "Removed driver package $($p.Driver)" { & pnputil.exe /delete-driver $p.Driver /uninstall /force | Out-Null } }
Step 'Removed C:\VirtualDisplayDriver' { Remove-Item 'C:\VirtualDisplayDriver' -Recurse -Force -ErrorAction SilentlyContinue }
if (@(Get-PnpDevice -Class Display -ErrorAction SilentlyContinue | Where-Object { $_.FriendlyName -like '*Virtual Display Driver*' -and $_.Present }).Count) { Warn 'The virtual screen is still listed. Restart the NUC to finish.' }
else { Ok 'Virtual Display Driver removed.' }
