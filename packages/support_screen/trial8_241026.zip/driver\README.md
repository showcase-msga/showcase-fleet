# Virtual Display Driver, as bundled in Showcase Fleet (trial 5, 24 Oct 2026)

The signed, ready-built driver behind the support screen. Not built by us: Windows only installs a driver with a trusted signature, so the project's own signed build is used, never a build from its source code.

| File | What | Signed by | sha256 |
|---|---|---|---|
| `MttVDD.dll` | The driver (user-mode, Indirect Display Driver) | SignPath Foundation | `c9ca837f57a98fbd43bc416a7f535a95843626e7759eaf85cf0cd7ce334dbb05` |
| `MttVDD.inf` | Its install instructions (hardware ID `Root\MttVDD`) | (covered by the .cat) | `550d211fe481e74dfe3f9d724ed78be48b3a9113405965d683d9373e8d672f5d` |
| `mttvdd.cat` | Signed catalogue covering the two above | SignPath Foundation | `08a0093fc9b2e32b287a6f8a77ca4de0a31830d29fc33d2b13a918dc859468f6` |
| `devcon.exe` | Microsoft's device console, which creates the virtual device | Microsoft Corporation | `77e87e7c4e23d6b9a4f5d86d15ed9ec61a16a242fb299c390af6f179225bfa05` |
| `vdd_settings.xml` | Driver settings, ours: one virtual monitor, **1920x1080 at 60 Hz only** (Jordan, 24 Oct: "Realistically, it would just be 1920 by 1080"); copied to `C:\VirtualDisplayDriver\`. Trial 5 shipped the release's default file (800x600 first; the program still switched it to 1920x1080) | not signed (settings) | `1b3a7941d109a1fb44381c61f76fa6eb87c93328a52c87ed0d939d3ce87fc7cf` (trial 5: `edb2501d...8020`) |

1. **Source:** Virtual Display Driver release 25.7.23 (23 Jul 2025), from `VDD.Control.25.7.23.zip` on https://github.com/VirtualDrivers/Virtual-Display-Driver/releases (folders `SignedDrivers\x86\VDD` and `Dependencies`). Driver version 11.30.4.434. Licence: MIT.
2. **Proven** on JC-Desktop, 24 Oct (installed with VDD Control; CRD showed the virtual screen on its own).
3. **How Fleet installs it** (`../install.ps1`): checks each signature, trusts only the driver's signing certificate (SignPath Foundation) as a Trusted Publisher so Windows installs it without asking on screen, copies `vdd_settings.xml`, then `devcon install MttVDD.inf Root\MttVDD`.
4. **Updating:** replace these files from a newer release, update this table, and bump the module's trial number. Never edit the .inf, .dll or .cat: the signature breaks.
