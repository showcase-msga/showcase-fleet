# support_screen: status (trial 4). Returns a hashtable; reads only.
$task = Get-ScheduledTask -TaskName 'showcase_fleet_support_screen' -ErrorAction SilentlyContinue
if (-not $task) { return @{ installed = $false } }
$dir = Join-Path $env:ProgramData 'showcase_fleet\support_screen'
$version = "$(Get-Content (Join-Path $dir 'version.txt') -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
$running = [bool](Get-Process ShowcaseSupportScreen -ErrorAction SilentlyContinue)
$detail = if ($running) { 'Running.' } else { 'Not running right now: it starts at sign-in and every 5 minutes.' }
$problem = -not $running
try {
  $s = Get-Content (Join-Path $dir 'state.json') -Raw | ConvertFrom-Json
  if (-not $s.supportScreen) { $problem = $true; $detail += ' No support screen found.' }
  elseif (-not $s.supportIsMain) { $problem = $true; $detail += ' The support screen is NOT the main display.' }
  else { $detail += ' Support screen is the main display.' }
  $detail += " Showcase: $($s.showcase)."
} catch { }
@{ installed = $true; version = $version; problem = $problem; detail = $detail }
