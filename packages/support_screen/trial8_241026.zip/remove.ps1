# support_screen: remove (trial 7). The real screen becomes the main display again; the driver stays.
# Trial 7: the restore runs as the display user (admin never runs a program from a folder they can change), and if
# it fails nothing is removed: with the hidden screen still main, Showcase would open there at every start.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$task = 'showcase_fleet_support_screen'
$dir  = Join-Path $env:ProgramData 'showcase_fleet\support_screen'
$exe  = Join-Path $dir 'ShowcaseSupportScreen.exe'

Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue | Stop-ScheduledTask
Get-Process ShowcaseSupportScreen -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 1

# put the real screen back as the main display, and the taskbar setting as it was
if (Test-Path $exe) {
  $code = Invoke-AsDisplayUser $exe 'restore' 30
  if ($code -ne 0) {
    Start-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
    Fail "The real screen couldn't be made the main display (code $code), so nothing was removed. Check the TV or LED is on and connected, then remove again."
    return
  }
  Ok 'The real screen is the main display again'
} else { Warn 'The program was already gone; set the main display by hand in Settings > System > Display if needed.' }

Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue

if (Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue) { Warn "The task is still there. Delete '$task' in Task Scheduler by hand." }
else { Ok 'Support screen removed. The Virtual Display Driver is still installed: "Remove the driver too" takes it off.' }
