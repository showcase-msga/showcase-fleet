// Showcase Fleet module: support_screen (trial 8, 24 Oct 2026; the program itself is unchanged since trial 7). Compiled to ShowcaseSupportScreen.exe by install.ps1.
// Keeps the hidden support screen (the Virtual Display Driver's screen, which no cable shows) as Windows' main
// display, so new windows, the taskbar, notifications and remote-session notices land there, and keeps
// Showcase on the real screen. It has no window of its own. Runs as the display user from the
// "showcase_fleet_support_screen" task, and leaves everything alone while Fleet or Ctrl+Alt+Q has paused Showcase.
//   ShowcaseSupportScreen.exe           watch: check every 5 seconds and whenever a display changes
//   ShowcaseSupportScreen.exe check     write the state file only; changes nothing
//   ShowcaseSupportScreen.exe arrange   arrange once now, even while paused (install); exit 0 if the support screen is main
//   ShowcaseSupportScreen.exe restore   make the first real screen the main display again (remove); exit 1 if it couldn't
// Trial 7: Showcase is known only by its browser's command line (its profile), never by size or title; restore
// reports failure; the state file is replaced whole, and only when something changed; per-monitor DPI aware.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace ShowcaseSupportScreen
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct DISPLAY_DEVICE
    {
        public int cb;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
        public int StateFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct DEVMODE
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
        public short dmSpecVersion, dmDriverVersion, dmSize, dmDriverExtra;
        public int dmFields, dmPositionX, dmPositionY, dmDisplayOrientation, dmDisplayFixedOutput;
        public short dmColor, dmDuplex, dmYResolution, dmTTOption, dmCollate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
        public short dmLogPixels;
        public int dmBitsPerPel, dmPelsWidth, dmPelsHeight, dmDisplayFlags, dmDisplayFrequency;
        public int dmICMMethod, dmICMIntent, dmMediaType, dmDitherType, dmReserved1, dmReserved2, dmPanningWidth, dmPanningHeight;
    }

    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct MONITORINFOEX
    {
        public int cbSize; public RECT rcMonitor; public RECT rcWork; public int dwFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string szDevice;
    }

    public class Disp { public string Name, Adapter, MonitorId; public bool Primary, Virtual; public int X, Y, W, H; }

    static class Native
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto)] public static extern bool EnumDisplayDevices(string device, uint num, ref DISPLAY_DEVICE dd, uint flags);
        [DllImport("user32.dll", CharSet = CharSet.Auto)] public static extern bool EnumDisplaySettings(string device, int mode, ref DEVMODE dm);
        [DllImport("user32.dll", CharSet = CharSet.Auto)] public static extern int ChangeDisplaySettingsEx(string device, ref DEVMODE dm, IntPtr hwnd, uint flags, IntPtr lParam);
        [DllImport("user32.dll", CharSet = CharSet.Auto)] public static extern int ChangeDisplaySettingsEx(string device, IntPtr dm, IntPtr hwnd, uint flags, IntPtr lParam);
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
        [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
        [DllImport("user32.dll", CharSet = CharSet.Auto)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder sb, int max);
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
        [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
        [DllImport("user32.dll")] public static extern IntPtr MonitorFromWindow(IntPtr hWnd, uint flags);
        [DllImport("user32.dll", CharSet = CharSet.Auto)] public static extern bool GetMonitorInfo(IntPtr mon, ref MONITORINFOEX mi);
        [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
        [DllImport("user32.dll", CharSet = CharSet.Auto)] public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint msg, UIntPtr w, string l, uint flags, uint timeout, out UIntPtr result);
        [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    }

    public static class Program
    {
        const uint CDS_UPDATEREGISTRY = 0x1, CDS_SET_PRIMARY = 0x10, CDS_NORESET = 0x10000000;
        const int DM_POSITION = 0x20, DM_PELSWIDTH = 0x80000, DM_PELSHEIGHT = 0x100000;
        const uint SWP_NOZORDER = 0x4, SWP_NOACTIVATE = 0x10, SWP_FRAMECHANGED = 0x20;
        const int SupportWidth = 1920, SupportHeight = 1080;

        static string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "showcase_fleet\\support_screen");
        static string logPath = Path.Combine(dataDir, "support_screen.log");
        static string statePath = Path.Combine(dataDir, "state.json");
        static string pausePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "ShowcasePause.txt");
        static string taskbarBefore = Path.Combine(dataDir, "taskbar_before.txt");
        static string lastNote = "", lastState = "";
        static DateTime nextArrangeAllowed = DateTime.MinValue, lastStateWrite = DateTime.MinValue;
        static int arrangeFailures = 0, moveAttempts = 0;
        static bool ignorePause = false;

        // Showcase's browser: the Showcase Chrome profile, or the window name the launchers give it. Fleet's own windows never.
        static Regex showcaseLine = new Regex("--user-data-dir=\"?[^\"]*\\\\User Data\\\\showcase\"?(\\s|$)|--window-name=\"?showcase\"?(\\s|$)", RegexOptions.IgnoreCase);
        static Regex fleetLine = new Regex("showcase_fleet_(manager_window|screen_\\d)", RegexOptions.IgnoreCase);

        [STAThread]
        public static void Main(string[] args)
        {
            // real pixels on every screen, whatever each one's scaling (falls back on Windows before 1703)
            try { if (!Native.SetProcessDpiAwarenessContext(new IntPtr(-4))) Native.SetProcessDPIAware(); }
            catch { try { Native.SetProcessDPIAware(); } catch { } }
            string mode = args.Length > 0 ? args[0].ToLowerInvariant() : "watch";
            try { Directory.CreateDirectory(dataDir); } catch { }
            if (mode == "check") { Check(false); return; }
            if (mode == "restore") { Environment.Exit(Restore() ? 0 : 1); return; }
            if (mode == "arrange")
            {
                ignorePause = true;
                Log("Arranging now (install)");
                TaskbarOnMainOnly();
                Check(true);
                Disp s = null; foreach (Disp d in GetDisplays()) if (d.Virtual) s = d;
                Environment.Exit(s != null && s.Primary && s.W == SupportWidth && s.H == SupportHeight ? 0 : 1);
                return;
            }

            bool first;
            using (Mutex m = new Mutex(true, "Local\\ShowcaseSupportScreen", out first))
            {
                if (!first) return;   // already running
                Log("Started (trial8_241026)");
                TaskbarOnMainOnly();
                System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
                timer.Interval = 5000;
                timer.Tick += delegate { Safe(delegate { Check(true); }); };
                timer.Start();
                Microsoft.Win32.SystemEvents.DisplaySettingsChanged += delegate { nextArrangeAllowed = DateTime.Now.AddSeconds(2); };
                Safe(delegate { Check(true); });
                Application.Run(new ApplicationContext());
            }
        }

        delegate void Action0();
        static void Safe(Action0 a) { try { a(); } catch (Exception e) { Note("Error: " + e.Message); } }

        // ------------------------------------------------------------------ displays

        public static List<Disp> GetDisplays()
        {
            List<Disp> list = new List<Disp>();
            for (uint i = 0; ; i++)
            {
                DISPLAY_DEVICE d = new DISPLAY_DEVICE(); d.cb = Marshal.SizeOf(d);
                if (!Native.EnumDisplayDevices(null, i, ref d, 0)) break;
                if ((d.StateFlags & 0x1) == 0) continue;   // not part of the desktop
                DISPLAY_DEVICE m = new DISPLAY_DEVICE(); m.cb = Marshal.SizeOf(m);
                string monitorId = Native.EnumDisplayDevices(d.DeviceName, 0, ref m, 0) ? (m.DeviceID ?? "") : "";
                DEVMODE dm = new DEVMODE(); dm.dmSize = (short)Marshal.SizeOf(dm);
                if (!Native.EnumDisplaySettings(d.DeviceName, -1, ref dm)) continue;
                Disp x = new Disp();
                x.Name = d.DeviceName; x.Adapter = d.DeviceString ?? ""; x.MonitorId = monitorId;
                x.Primary = (d.StateFlags & 0x4) != 0;
                x.Virtual = x.Adapter.IndexOf("Virtual Display Driver", StringComparison.OrdinalIgnoreCase) >= 0
                         || monitorId.IndexOf("MTT1337", StringComparison.OrdinalIgnoreCase) >= 0;
                x.X = dm.dmPositionX; x.Y = dm.dmPositionY; x.W = dm.dmPelsWidth; x.H = dm.dmPelsHeight;
                list.Add(x);
            }
            return list;
        }

        // main display at 0,0; every other display to its right, in their current left-to-right order, tops level
        static bool Arrange(List<Disp> all, Disp main, bool supportSize)
        {
            List<Disp> others = new List<Disp>();
            foreach (Disp d in all) if (d != main) others.Add(d);
            others.Sort(delegate (Disp a, Disp b) { return a.X.CompareTo(b.X); });

            bool ok = true;
            int mainW = main.W;
            DEVMODE dm = Current(main.Name);
            dm.dmPositionX = 0; dm.dmPositionY = 0; dm.dmFields = DM_POSITION;
            if (supportSize && main.Virtual && (main.W != SupportWidth || main.H != SupportHeight))
            {
                dm.dmPelsWidth = SupportWidth; dm.dmPelsHeight = SupportHeight; dm.dmFields |= DM_PELSWIDTH | DM_PELSHEIGHT; mainW = SupportWidth;
            }
            ok &= Native.ChangeDisplaySettingsEx(main.Name, ref dm, IntPtr.Zero, CDS_SET_PRIMARY | CDS_UPDATEREGISTRY | CDS_NORESET, IntPtr.Zero) == 0;
            int x = mainW;
            foreach (Disp d in others)
            {
                DEVMODE o = Current(d.Name);
                o.dmPositionX = x; o.dmPositionY = 0; o.dmFields = DM_POSITION;
                ok &= Native.ChangeDisplaySettingsEx(d.Name, ref o, IntPtr.Zero, CDS_UPDATEREGISTRY | CDS_NORESET, IntPtr.Zero) == 0;
                x += d.W;
            }
            ok &= Native.ChangeDisplaySettingsEx(null, IntPtr.Zero, IntPtr.Zero, 0, IntPtr.Zero) == 0;
            return ok;
        }

        static DEVMODE Current(string name)
        {
            DEVMODE dm = new DEVMODE(); dm.dmSize = (short)Marshal.SizeOf(dm);
            Native.EnumDisplaySettings(name, -1, ref dm);
            return dm;
        }

        // ------------------------------------------------------------------ the Showcase window

        class Win { public IntPtr Hwnd; public uint Pid; public string Title; public string Monitor; }

        // the top window of Showcase's browser, known by its command line; a tech's own Chrome or Edge, however big
        // or whatever its title, is never moved
        static Win FindShowcase()
        {
            Win found = null;
            Dictionary<uint, bool> isShowcase = new Dictionary<uint, bool>();
            Native.EnumWindows(delegate (IntPtr h, IntPtr l)
            {
                if (!Native.IsWindowVisible(h) || Native.IsIconic(h)) return true;
                uint pid; Native.GetWindowThreadProcessId(h, out pid);
                bool yes;
                if (!isShowcase.TryGetValue(pid, out yes))
                {
                    string proc;
                    try { proc = Process.GetProcessById((int)pid).ProcessName.ToLowerInvariant(); } catch { proc = ""; }
                    string line = (proc == "chrome" || proc == "msedge") ? CommandLine(pid) : null;
                    yes = line != null && showcaseLine.IsMatch(line) && !fleetLine.IsMatch(line);
                    isShowcase[pid] = yes;
                }
                if (!yes) return true;
                StringBuilder sb = new StringBuilder(512); Native.GetWindowText(h, sb, 512);
                found = new Win(); found.Hwnd = h; found.Pid = pid; found.Title = sb.ToString(); found.Monitor = MonitorOf(h);
                return false;
            }, IntPtr.Zero);
            return found;
        }

        static string ProfileOf(string line)
        {
            if (line == null) return "";
            Match pm = Regex.Match(line, "--user-data-dir=\"?([^\"]+?)\"?(\\s--|\\s|$)");
            return pm.Success ? pm.Groups[1].Value.Trim().TrimEnd('\\') : "";
        }

        static string MonitorOf(IntPtr h)
        {
            IntPtr mon = Native.MonitorFromWindow(h, 2);
            MONITORINFOEX mi = new MONITORINFOEX(); mi.cbSize = Marshal.SizeOf(mi);
            return Native.GetMonitorInfo(mon, ref mi) ? mi.szDevice : "";
        }

        // move it with the window API; if Chrome won't move in kiosk, reopen it on the real screen instead
        static void MoveToReal(Win w, Disp real)
        {
            moveAttempts++;
            if (moveAttempts <= 2)
            {
                Native.SetWindowPos(w.Hwnd, IntPtr.Zero, real.X, real.Y, real.W, real.H, SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
                Note("Showcase was on the support screen; moved it to the real screen (" + real.Name + ")");
                return;
            }
            string line = CommandLine(w.Pid);
            if (string.IsNullOrEmpty(line) || line.IndexOf("chrome", StringComparison.OrdinalIgnoreCase) < 0)
            {
                Note("Showcase is stuck on the support screen and couldn't be reopened (no command line); restart the NUC");
                return;
            }
            // close only Showcase's own browser (its profile), never every Chrome
            string profile = ProfileOf(line);
            if (profile == "")
            {
                Note("Showcase is stuck on the support screen and has no profile of its own to reopen safely; restart the NUC");
                return;
            }
            string exe, rest;
            SplitCommandLine(line, out exe, out rest);
            rest = Regex.Replace(rest, "\\s--window-(position|size)=\\S+", "");
            rest += " --window-position=" + real.X + "," + real.Y + " --window-size=" + real.W + "," + real.H;
            string procName = "chrome";
            try { procName = Process.GetProcessById((int)w.Pid).ProcessName; } catch { }
            foreach (Process p in Process.GetProcessesByName(procName))
            {
                if (string.Equals(ProfileOf(CommandLine((uint)p.Id)), profile, StringComparison.OrdinalIgnoreCase)) { try { p.Kill(); } catch { } }
            }
            Thread.Sleep(2000);
            Process.Start(new ProcessStartInfo(exe, rest.Trim()) { UseShellExecute = false });
            moveAttempts = 0;
            Note("Showcase wouldn't move, so it was reopened on the real screen (" + real.Name + ")");
        }

        static string CommandLine(uint pid)
        {
            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT CommandLine FROM Win32_Process WHERE ProcessId=" + pid))
                    foreach (ManagementObject o in s.Get()) return (string)o["CommandLine"];
            }
            catch { }
            return null;
        }

        static void SplitCommandLine(string line, out string exe, out string rest)
        {
            line = line.Trim();
            if (line.StartsWith("\"")) { int end = line.IndexOf('"', 1); exe = line.Substring(1, end - 1); rest = line.Substring(end + 1); }
            else { int sp = line.IndexOf(' '); exe = sp < 0 ? line : line.Substring(0, sp); rest = sp < 0 ? "" : line.Substring(sp); }
        }

        // ------------------------------------------------------------------ the check

        static void Check(bool act)
        {
            List<Disp> all = GetDisplays();
            Disp support = null; List<Disp> real = new List<Disp>();
            foreach (Disp d in all) { if (d.Virtual) { if (support == null) support = d; } else real.Add(d); }
            real.Sort(delegate (Disp a, Disp b) { return a.X.CompareTo(b.X); });
            bool paused = Paused() && !ignorePause;
            string showcase = "not found";
            Win w = FindShowcase();

            if (support == null) Note("No support screen: the Virtual Display Driver isn't installed or is switched off. Nothing to do.");
            else if (real.Count == 0) Note("No real screen connected (the TV or LED is off or unplugged). Waiting.");
            else if (act && !paused && DateTime.Now >= nextArrangeAllowed)
            {
                if (!support.Primary || support.W != SupportWidth || support.H != SupportHeight)
                {
                    bool ok = Arrange(all, support, true);
                    arrangeFailures = ok ? 0 : arrangeFailures + 1;
                    Note(ok ? "Made the support screen the main display (real screens to its right)" : "Windows refused to make the support screen the main display (" + arrangeFailures + ")");
                    nextArrangeAllowed = DateTime.Now.AddSeconds(arrangeFailures >= 3 ? 300 : 10);
                    all = GetDisplays(); w = FindShowcase();
                }
                if (w != null)
                {
                    Disp on = null; foreach (Disp d in all) if (d.Name == w.Monitor) on = d;
                    if (on != null && on.Virtual) MoveToReal(w, real[0]); else moveAttempts = 0;
                }
            }
            if (w != null)
            {
                bool onSupport = support != null && w.Monitor == support.Name;
                showcase = onSupport ? "on the support screen" : "on the real screen";
            }
            WriteState(all, support, real, showcase, paused);
        }

        // false when the real screen couldn't be made the main display (none connected, or Windows refused):
        // remove then keeps everything, because Showcase would otherwise open on the hidden screen at every start
        static bool Restore()
        {
            TaskbarBack();
            List<Disp> all = GetDisplays();
            Disp main = null;
            foreach (Disp d in all) if (!d.Virtual && (main == null || d.X < main.X)) main = d;
            if (main == null) { Log("Restore: no real screen connected, nothing changed"); return false; }
            bool ok = Arrange(all, main, false);
            Log(ok ? "Restore: " + main.Name + " is the main display again" : "Restore: Windows refused the change");
            return ok;
        }

        static bool Paused()
        {
            try { if (File.Exists(pausePath)) return new DateTime(long.Parse(File.ReadAllText(pausePath).Trim())) > DateTime.Now; } catch { }
            return false;
        }

        // the taskbar only on the main display, so it never sits on the TV
        static void TaskbarOnMainOnly()
        {
            try
            {
                using (Microsoft.Win32.RegistryKey k = Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced"))
                {
                    object v = k.GetValue("MMTaskbarEnabled");
                    if (v == null || Convert.ToInt32(v) != 0)
                    {
                        // remembered once, so restore can put back exactly what was there
                        if (!File.Exists(taskbarBefore)) File.WriteAllText(taskbarBefore, v == null ? "none" : Convert.ToInt32(v).ToString());
                        k.SetValue("MMTaskbarEnabled", 0, Microsoft.Win32.RegistryValueKind.DWord);
                        TraySettingsChanged();
                        Log("Taskbar set to the main display only");
                    }
                }
            }
            catch (Exception e) { Log("Couldn't set the taskbar: " + e.Message); }
        }

        static void TaskbarBack()
        {
            if (!File.Exists(taskbarBefore)) return;
            try
            {
                string was = File.ReadAllText(taskbarBefore).Trim();
                using (Microsoft.Win32.RegistryKey k = Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced"))
                {
                    if (was == "none") k.DeleteValue("MMTaskbarEnabled", false);
                    else k.SetValue("MMTaskbarEnabled", int.Parse(was), Microsoft.Win32.RegistryValueKind.DWord);
                }
                TraySettingsChanged();
                File.Delete(taskbarBefore);
                Log("Taskbar setting put back");
            }
            catch (Exception e) { Log("Couldn't put the taskbar setting back: " + e.Message); }
        }

        static void TraySettingsChanged()
        {
            UIntPtr r;
            Native.SendMessageTimeout(new IntPtr(0xffff), 0x1A, UIntPtr.Zero, "TraySettings", 0x2, 1000, out r);
        }

        // ------------------------------------------------------------------ log and state

        static void Note(string m) { if (m != lastNote) { lastNote = m; Log(m); } }

        static void Log(string m)
        {
            try
            {
                if (File.Exists(logPath) && new FileInfo(logPath).Length > 1024 * 1024)
                {
                    string[] lines = File.ReadAllLines(logPath);
                    int keep = Math.Min(2000, lines.Length);
                    string[] tail = new string[keep]; Array.Copy(lines, lines.Length - keep, tail, 0, keep);
                    File.WriteAllLines(logPath, tail);
                }
                File.AppendAllText(logPath, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + m + Environment.NewLine);
            }
            catch { }
        }

        static string J(string s) { return "\"" + (s ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"") + "\""; }

        // Kiosk and Pin read this file many times a second, so it's replaced whole (never seen half-written), and only
        // when something changed (or once a minute, so "as at" stays fresh)
        static void WriteState(List<Disp> all, Disp support, List<Disp> real, string showcase, bool paused)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("\"supportScreen\":").Append(support == null ? "null" : J(support.Name + " " + support.W + "x" + support.H));
            sb.Append(",\"supportIsMain\":").Append(support != null && support.Primary ? "true" : "false");
            sb.Append(",\"realScreens\":[");
            for (int i = 0; i < real.Count; i++) { if (i > 0) sb.Append(","); sb.Append(J(real[i].Name + " " + real[i].W + "x" + real[i].H + (real[i].Primary ? " (main)" : ""))); }
            sb.Append("],\"showcase\":").Append(J(showcase));
            sb.Append(",\"paused\":").Append(paused ? "true" : "false");
            sb.Append(",\"last\":").Append(J(lastNote));
            string body = sb.ToString();
            if (body == lastState && DateTime.Now - lastStateWrite < TimeSpan.FromSeconds(60)) return;
            string json = "{\"at\":" + J(DateTime.Now.ToString("ddd d MMM, h:mm:ss tt")) + "," + body + "}";
            string tmp = statePath + "." + Process.GetCurrentProcess().Id + ".tmp";
            try
            {
                File.WriteAllText(tmp, json);
                if (File.Exists(statePath)) File.Replace(tmp, statePath, null); else File.Move(tmp, statePath);
                lastState = body; lastStateWrite = DateTime.Now;
            }
            catch { try { File.Delete(tmp); } catch { } }   // a reader had it open: tried again next check
        }
    }
}
