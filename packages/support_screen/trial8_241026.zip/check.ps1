# support_screen: "Check the screens now" (trial 4). Reads only: what the program last saw.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$dir = Join-Path $env:ProgramData 'showcase_fleet\support_screen'
$state = Join-Path $dir 'state.json'
if (-not (Test-Path $state)) { Warn 'Nothing written yet. Install the module, or wait a few seconds after sign-in.'; return }
$s = Get-Content $state -Raw | ConvertFrom-Json
Info "As at $($s.at):"
if ($s.supportScreen) { Info "  Support screen: $($s.supportScreen)$(if ($s.supportIsMain) { ', the main display' } else { ', NOT the main display' })" } else { Warn '  No support screen found (driver off or not installed)' }
Info "  Real screen(s): $(if (@($s.realScreens).Count) { @($s.realScreens) -join ', ' } else { 'none connected' })"
Info "  Showcase: $($s.showcase)"
if ($s.paused) { Info '  Paused: Fleet is open or Ctrl+Alt+Q was pressed, so it is leaving things alone.' }
if ($s.last) { Info "  Last change: $($s.last)" }
Info "Running: $(if (Get-Process ShowcaseSupportScreen -ErrorAction SilentlyContinue) { 'yes' } else { 'no' })"
