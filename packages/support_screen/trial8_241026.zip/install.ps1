# support_screen: install or update (trial 8, 24 Oct 2026)
# Installs the Virtual Display Driver itself, from the signed files in .\driver (see its README).
# Trial 7: our driver settings (1920x1080 only) go in on every install, not just when the driver is new.
# Trial 8: counts the virtual screens properly (trial 7 read one as none and installed a second), and takes off any
# extra virtual screen, keeping one.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$Version = 'trial8_241026'
$Driver  = Join-Path $PSScriptRoot 'driver'
$VddSettings = 'C:\VirtualDisplayDriver\vdd_settings.xml'

# every virtual screen. Call it as @(Get-Vdd): Windows PowerShell hands back one device on its own, with no .Count
function Get-Vdd { @(Get-PnpDevice -Class Display -PresentOnly -ErrorAction SilentlyContinue | Where-Object { $_.FriendlyName -like '*Virtual Display Driver*' }) }

# puts our settings file in place; true if it changed (the driver only reads it when the screen starts)
function Write-VddSettings {
  $ours = Join-Path $Driver 'vdd_settings.xml'
  if ((Test-Path $VddSettings) -and (Get-FileHash $VddSettings).Hash -eq (Get-FileHash $ours).Hash) { return $false }
  New-Item -ItemType Directory -Force -Path (Split-Path $VddSettings) | Out-Null
  Copy-Item $ours $VddSettings -Force
  $true
}

$vdd = @(Get-Vdd)
# trial 7 could put the driver on twice (two virtual screens): keep the first, take the others off, with the
# support screen program stopped while the displays change
if ($vdd.Count -gt 1) {
  Get-ScheduledTask -TaskName 'showcase_fleet_support_screen' -ErrorAction SilentlyContinue | Stop-ScheduledTask
  Get-Process ShowcaseSupportScreen -ErrorAction SilentlyContinue | Stop-Process -Force
  $keep = $vdd | Sort-Object InstanceId | Select-Object -First 1
  $ErrorActionPreference = 'Continue'
  foreach ($d in @($vdd | Where-Object { $_.InstanceId -ne $keep.InstanceId })) {
    $null = & pnputil.exe /remove-device $d.InstanceId 2>&1
    Ok "Took off an extra virtual screen ($($d.InstanceId)); keeping $($keep.InstanceId)"
  }
  $ErrorActionPreference = 'Stop'
  Start-Sleep -Seconds 3
  $vdd = @(Get-Vdd)
}
if (-not $vdd.Count) {
  Info 'Installing the Virtual Display Driver (signed, release 25.7.23)...'
  # 1. only install what's signed by who we expect
  $expect = @{ 'MttVDD.dll' = 'SignPath Foundation'; 'mttvdd.cat' = 'SignPath Foundation'; 'devcon.exe' = 'Microsoft Corporation' }
  foreach ($f in $expect.Keys) {
    $sig = Get-AuthenticodeSignature (Join-Path $Driver $f)
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch [regex]::Escape($expect[$f])) { Fail "$f is not signed by $($expect[$f]) (status $($sig.Status)). Not installing."; return }
  }
  Ok 'Driver files signed as expected'
  # 2. trust the driver's signing certificate as a publisher only while it installs, so Windows doesn't ask on screen
  $signer = (Get-AuthenticodeSignature (Join-Path $Driver 'mttvdd.cat')).SignerCertificate
  $store = New-Object Security.Cryptography.X509Certificates.X509Store('TrustedPublisher', 'LocalMachine')
  $store.Open('ReadWrite')
  $hadTrust = $store.Certificates.Find('FindByThumbprint', $signer.Thumbprint, $false).Count -gt 0
  if (-not $hadTrust) { $store.Add($signer) }
  $store.Close()
  # 3. its settings: one virtual monitor, 1920x1080 only
  Step 'Driver settings in C:\VirtualDisplayDriver' { Write-VddSettings | Out-Null }
  # 4. create the virtual device with the driver
  # a native tool's stderr would stop the script under 'Stop', so let devcon report in its own way
  $ErrorActionPreference = 'Continue'
  $out = & (Join-Path $Driver 'devcon.exe') install (Join-Path $Driver 'MttVDD.inf') 'Root\MttVDD' 2>&1
  $code = $LASTEXITCODE
  $ErrorActionPreference = 'Stop'
  $out | Where-Object { "$_".Trim() } | ForEach-Object { Info "  devcon: $_" }
  # the driver is in Windows' driver store now, so the trust isn't needed; leave one that was there before us
  if (-not $hadTrust) {
    $store.Open('ReadWrite'); try { $store.Remove($signer) } catch { } finally { $store.Close() }
  }
  if ($code -gt 1) { Fail "devcon could not install the driver (code $code)."; return }
  if ($code -eq 1) { Warn 'Windows says a restart is needed to finish the driver install.' }
  $until = (Get-Date).AddSeconds(30)
  while ((Get-Date) -lt $until -and -not (Get-Vdd | Where-Object Status -eq 'OK')) { Start-Sleep -Seconds 2 }
  $vdd = @(Get-Vdd)
}
elseif (Write-VddSettings) {
  # a driver put on before (VDD Control, or trial 5 or 6) keeps the stock file, which starts at 800x600:
  # ours is in now, and the virtual screen restarts so it reads it (the TV doesn't change)
  Ok 'Driver settings updated: the support screen is 1920x1080 only'
  $ErrorActionPreference = 'Continue'
  foreach ($d in $vdd) { $null = & pnputil.exe /restart-device $d.InstanceId 2>&1 }
  $ErrorActionPreference = 'Stop'
  Start-Sleep -Seconds 3
  $until = (Get-Date).AddSeconds(20)
  while ((Get-Date) -lt $until -and -not (Get-Vdd | Where-Object Status -eq 'OK')) { Start-Sleep -Seconds 2 }
  $vdd = @(Get-Vdd)
  Ok 'Restarted the support screen with the new settings'
}
if (-not $vdd.Count) { Fail 'The Virtual Display Driver did not appear. Check Device Manager > Display adapters.'; return }
if (@($vdd | Where-Object Status -eq 'OK').Count -eq 0) { Fail "The Virtual Display Driver is there but not working (status: $(@($vdd)[0].Status)). A restart may finish it; then install this again."; return }
Ok 'Virtual Display Driver installed and working'
if ($vdd.Count -gt 1) { Warn "There are still $($vdd.Count) virtual screens; there should be one. Restart the NUC, then install this again." }

# it rearranges the displays of the signed-in session, so it runs as whoever is signed in on the display
$user = Get-DisplayUser
$dir  = Join-Path $env:ProgramData 'showcase_fleet\support_screen'
$exe  = Join-Path $dir 'ShowcaseSupportScreen.exe'
$task = 'showcase_fleet_support_screen'

Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue | Stop-ScheduledTask
Get-Process ShowcaseSupportScreen -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 1
Protect-FleetData
New-Item -ItemType Directory -Force -Path $dir | Out-Null
# it writes its log and state as the signed-in user (Users group by SID, any Windows language). Because the user can
# change this folder, admin never runs the program from it: only the display user does (its task, arrange, restore).
& icacls.exe $dir /grant '*S-1-5-32-545:(OI)(CI)M' | Out-Null

Step 'Built the support screen program' {
  Remove-Item $exe -Force -ErrorAction SilentlyContinue
  Add-Type -TypeDefinition (Get-Content (Join-Path $PSScriptRoot 'support_screen.cs') -Raw) -ReferencedAssemblies System.Windows.Forms, System.Management -OutputAssembly $exe -OutputType WindowsApplication
}
if (-not (Test-Path $exe)) { Fail 'The support screen program could not be built.'; return }

$action    = New-ScheduledTaskAction -Execute $exe -WorkingDirectory $dir
$atLogon   = New-ScheduledTaskTrigger -AtLogOn -User $user
# every 5 minutes: brings it back if it ever stops; does nothing while it's running
$revive    = New-ScheduledTaskTrigger -Once -At (Get-Date).Date -RepetitionInterval (New-TimeSpan -Minutes 5)
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
$settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -Force -TaskName $task -Description "Showcase Fleet: support screen $Version" -Action $action -Trigger @($atLogon, $revive) -Principal $principal -Settings $settings | Out-Null
Set-Content (Join-Path $dir 'version.txt') $Version

# Fleet's pause (while this window is open) stays on, so Kiosk and Pin leave this window alone; the screens are
# arranged once now regardless (the hidden screen becomes main, at 1920x1080), and the watcher takes over after
Info 'Arranging the screens (about 10 seconds)...'
$code = Invoke-AsDisplayUser $exe 'arrange' 30
if ($code -eq 0) { Ok 'The support screen is the main display, at 1920x1080' }
else { Warn "The screens didn't arrange (code $code). The program tries again by itself once Fleet is closed." }
Start-ScheduledTask -TaskName $task
Start-Sleep -Seconds 2
$state = Join-Path $dir 'state.json'
if (Get-Process ShowcaseSupportScreen -ErrorAction SilentlyContinue) { Ok "Running as $user, checking every 5 seconds (it waits while Fleet is open)" } else { Warn 'Installed, but it is not running. Check the log.' }
try {
  $s = Get-Content $state -Raw | ConvertFrom-Json
  if ($s.supportIsMain) { Ok "The support screen ($($s.supportScreen)) is the main display" } else { Warn "The support screen is not the main display yet: $($s.last)" }
  Info "Real screen(s): $(@($s.realScreens) -join ', ')"
  Info "Showcase: $($s.showcase)"
} catch { Warn 'No state written yet. Press "Check the screens now" in a minute.' }
Info 'Next: reconnect Chrome Remote Desktop and pick the hidden screen in its side panel. Close this Fleet window and reopen it from the desktop shortcut: from now on it opens on the hidden screen.'
