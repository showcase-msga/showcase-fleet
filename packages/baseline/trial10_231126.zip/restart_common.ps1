# Showcase Fleet module: baseline, the daily restart (trial 9, 10 Nov 2026; trial 10, 23 Nov 2026: 4:30 am, skipped when
# not needed, and Fleet now sets aside every task that restarts, shuts down or hibernates the NUC).
# Shared by settings.ps1 (check and set it) and put_back_restart.ps1 (undo it). Dot-sourced after common.ps1.
$RestartAt       = '04:30'      # Overnight Timetable.md (Jordan, 23 Nov 2026: clear of Bluesound's 4:00 am)
$RestartLabel    = '4:30 am'
$RestartTaskName = 'showcase_fleet_daily_restart'
$SetAsideFile    = Join-Path $env:ProgramData 'showcase_fleet\baseline\set_aside_restarts.json'

# a task that restarts, shuts down or hibernates the PC, outside Windows' own tasks: in its command line, or in the
# script it runs (a nightly routine kept in a .bat or .ps1). Fleet replaces them all with its one restart (Jordan,
# 23 Nov 2026: Fleet replaces Jotham's nightly hibernate-and-restart routine on every NUC it goes on).
$PowerPattern = 'shutdown(\.exe)?"?\s.*[/-][rsh]\b|Restart-Computer|Stop-Computer|SetSuspendState|psshutdown'
function Get-TaskScriptText($action) {
  $cmd = "$($action.Execute) $($action.Arguments)"
  foreach ($m in [regex]::Matches($cmd, '"([^"]+\.(?:bat|cmd|ps1|vbs))"|(\S+\.(?:bat|cmd|ps1|vbs))', 'IgnoreCase')) {
    $p = [Environment]::ExpandEnvironmentVariables($(if ($m.Groups[1].Success) { $m.Groups[1].Value } else { $m.Groups[2].Value }))
    if ($action.WorkingDirectory -and -not [IO.Path]::IsPathRooted($p)) { $p = Join-Path ([Environment]::ExpandEnvironmentVariables($action.WorkingDirectory)) $p }
    try { if ((Test-Path -LiteralPath $p -PathType Leaf) -and (Get-Item -LiteralPath $p).Length -lt 1MB) { Get-Content -LiteralPath $p -Raw -ErrorAction Stop } } catch { }
  }
}
function Get-RestartTasks {
  @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object {
      $_.TaskPath -notlike '\Microsoft\*' -and $_.TaskName -ne $RestartTaskName -and
      ($_.Actions | Where-Object { "$($_.Execute) $($_.Arguments)" -match $PowerPattern -or "$(Get-TaskScriptText $_)" -match $PowerPattern }) })
}

# "Daily Restart 3:00 AM", or only the time
function Format-RestartTask($t, [switch]$TimeOnly) {
  $tr = $t.Triggers | Select-Object -First 1
  $when = ''
  if ($tr -and $tr.StartBoundary) { try { $when = ('{0:h:mm tt}' -f [datetime]$tr.StartBoundary).ToLower() } catch { } }
  if ($TimeOnly) { if ($when) { return $when } else { return 'an unknown time' } }
  "$($t.TaskName) $when".Trim()
}

# the restart tasks Baseline switched off, so "Put back the old restart" can switch them on again
function Get-SetAsideRestarts {
  if (-not (Test-Path $SetAsideFile)) { return @() }
  try { $j = Get-Content $SetAsideFile -Raw | ConvertFrom-Json } catch { return @() }
  @($j | ForEach-Object { $_ })   # PowerShell 5.1 hands a JSON array back as one object; this unrolls it
}
function Save-SetAsideRestarts($list) {
  $dir = Split-Path $SetAsideFile
  if (-not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force | Out-Null }
  ConvertTo-Json -InputObject @($list) -Depth 3 | Set-Content -Path $SetAsideFile -Encoding UTF8
}

# one restart a day as SYSTEM, through restart_if_needed.ps1: it skips the restart if the NUC already started after
# 3am tonight or Windows is still installing an update, else restarts with no countdown (nothing on the display).
# The script is copied next to the log, so the task never depends on the folder Fleet was opened from.
function Register-FleetRestart {
  $script = Join-Path (Get-ModuleData 'baseline') 'restart_if_needed.ps1'
  Copy-Item (Join-Path $PSScriptRoot 'restart_if_needed.ps1') $script -Force -ErrorAction Stop
  $action    = New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" `
    -Argument "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$script`""
  $trigger   = New-ScheduledTaskTrigger -Daily -At $RestartAt
  # local time with no offset: a UTC start (what -At gives) moves the restart an hour when daylight saving ends
  $trigger.StartBoundary = (Get-Date $RestartAt).ToString('yyyy-MM-ddTHH:mm:ss')
  $principal = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  # no StartWhenAvailable: a NUC that was off at the restart time must not restart late, in opening hours
  $settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 5)
  Register-ScheduledTask -TaskName $RestartTaskName -TaskPath '\' -Action $action -Trigger $trigger -Principal $principal `
    -Settings $settings -Description "Showcase Fleet Baseline: restarts the NUC at $RestartLabel every day." -Force -ErrorAction Stop | Out-Null
}
