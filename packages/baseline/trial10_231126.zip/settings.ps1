# Showcase Fleet module: baseline (trial 9, 10 Nov 2026). Our recommended NUC settings.
# Checks each one against what we recommend and, when asked, applies the ticked ones
# (-Apply fast_startup,delivery_optimisation,...). Every change is a registry value, a powercfg
# setting or a SYSTEM scheduled task, so nothing shows on the display. Changes go to
# C:\ProgramData\showcase_fleet\baseline\baseline.log, and the last check to last_check.json, which the
# Fleet window shows. Later the agent keeps these set for good; for now it's by hand.
param([string]$Apply = '')
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
. (Join-Path $PSScriptRoot 'restart_common.ps1')
$ErrorActionPreference = 'Continue'
$Version = 'trial10_231126'
$Data = Get-ModuleData 'baseline'
$Log  = Join-Path $Data 'baseline.log'

function Write-BaselineLog($m) { try { Add-Content -Path $Log -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m" -Encoding UTF8; Limit-Log $Log } catch { } }
function Get-Reg($path, $name) { (Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue).$name }

# "Current AC Power Setting Index: 0x00000000" (mains power; a NUC has no battery)
function Get-PowerAc($sub, $setting) {
  $line = & powercfg.exe /q SCHEME_CURRENT $sub $setting 2>$null | Where-Object { $_ -match 'Current AC Power Setting Index:\s*0x([0-9a-f]+)' } | Select-Object -First 1
  if ($line -and $line -match '0x([0-9a-f]+)') { [Convert]::ToInt32($Matches[1], 16) } else { $null }
}
function Format-Minutes($seconds) { if ($seconds -eq 0) { 'Never' } elseif ($null -eq $seconds) { 'Unknown' } else { "After $([math]::Round($seconds / 60)) min" } }

$PowerKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power'
$DoKey    = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'

# each: what we recommend, how to read what it is now, and (if we can set it) how to set it
$Settings = @(
  @{ id = 'fast_startup'; name = 'Fast Startup'; recommended = 'Off'
     about = "With Fast Startup on, a shutdown is really hibernation, so scheduled restarts don't give a clean start (Dacre, Camberwell)."
     check = { $v = Get-Reg $PowerKey 'HiberbootEnabled'; @{ ok = ($v -eq 0); now = $(if ($v -eq 0) { 'Off' } elseif ($null -eq $v) { 'On (Windows default)' } else { 'On' }) } }
     apply = { Set-RegDword $PowerKey 'HiberbootEnabled' 0 } }

  @{ id = 'hibernation'; name = 'Hibernation'; recommended = 'Off'
     about = "Stops Fast Startup coming back on (it did at Camberwell). Leave it unticked on NUCs that run Jotham's nightly hibernate script, which needs hibernation."
     check = { $v = Get-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' 'HibernateEnabled'; @{ ok = ($v -eq 0); now = $(if ($v -eq 0) { 'Off' } else { 'On' }) } }
     apply = { & powercfg.exe /hibernate off; if ($LASTEXITCODE -ne 0) { throw "powercfg code $LASTEXITCODE" } } }

  @{ id = 'delivery_optimisation'; name = 'Delivery Optimisation peering'; recommended = 'Off (policy)'
     about = "Stops the NUC sharing Windows updates with other PCs and the internet, which can saturate a suite's 4G. Set as a machine policy, the only way it sticks."
     check = { $v = Get-Reg $DoKey 'DODownloadMode'; @{ ok = ($v -eq 0); now = $(if ($v -eq 0) { 'Off (policy)' } elseif ($null -eq $v) { 'On (no policy)' } else { "Policy mode $v" }) } }
     apply = {
       if (-not (Test-Path $DoKey)) { New-Item -Path $DoKey -Force | Out-Null }   # new key only; never -Force on one that exists
       New-ItemProperty -Path $DoKey -Name DODownloadMode -PropertyType DWord -Value 0 -Force | Out-Null
       if ((Get-Service DoSvc -ErrorAction SilentlyContinue).Status -eq 'Running') { Restart-Service DoSvc -Force -ErrorAction SilentlyContinue }
     } }

  @{ id = 'never_sleep'; name = 'Sleep and hibernate on mains'; recommended = 'Never'
     about = 'The NUC never goes to sleep or hibernates by itself.'
     check = { $s = Get-PowerAc 'SUB_SLEEP' 'STANDBYIDLE'; $h = Get-PowerAc 'SUB_SLEEP' 'HIBERNATEIDLE'
               @{ ok = ($s -eq 0 -and ($h -eq 0 -or $null -eq $h)); now = "Sleep: $(Format-Minutes $s). Hibernate: $(Format-Minutes $h)" } }
     apply = { & powercfg.exe /change standby-timeout-ac 0; & powercfg.exe /change hibernate-timeout-ac 0 } }

  @{ id = 'screen_on'; name = 'Screen turns off'; recommended = 'Never'
     about = 'Windows never blanks the display by itself. Showcase Blackout, where it is used, still blacks the screen at night.'
     check = { $v = Get-PowerAc 'SUB_VIDEO' 'VIDEOIDLE'; @{ ok = ($v -eq 0); now = Format-Minutes $v } }
     apply = { & powercfg.exe /change monitor-timeout-ac 0 } }

  @{ id = 'adapters_awake'; name = 'Network adapters powered down to save power'; recommended = 'Never'
     about = 'Windows never switches a network adapter off, and Wi-Fi runs at maximum performance.'
     check = {
       $pm = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object { Get-NetAdapterPowerManagement -Name $_.Name -ErrorAction SilentlyContinue })
       $on = @($pm | Where-Object { "$($_.AllowComputerToTurnOffDevice)" -eq 'Enabled' } | ForEach-Object { $_.Name })
       @{ ok = ($pm.Count -gt 0 -and $on.Count -eq 0)
          now = $(if (-not $pm.Count -and -not (Test-Admin)) { 'Needs admin to read' } elseif (-not $pm.Count) { 'No adapters read' } elseif ($on.Count) { "Allowed: $($on -join ', ')" } else { 'Never' }) } }
     apply = {
       & powercfg.exe /setacvalueindex SCHEME_CURRENT 19cbb8fa-5279-450e-9fac-8a3d5fedd0c1 12bbebe6-58d6-4636-95bb-3217ef867c1a 0
       & powercfg.exe /setactive SCHEME_CURRENT
       Get-NetAdapter -Physical | ForEach-Object { Disable-NetAdapterPowerManagement -Name $_.Name -NoRestart -ErrorAction SilentlyContinue }
     } }

  @{ id = 'auto_login'; name = 'Auto-login'; recommended = 'On'
     about = 'After a restart the NUC signs in by itself, so Showcase comes back. Set by hand: it needs the account password.'
     check = { $w = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -ErrorAction SilentlyContinue
               @{ ok = ("$($w.AutoAdminLogon)" -eq '1'); now = $(if ("$($w.AutoAdminLogon)" -eq '1') { "On, as $($w.DefaultUserName)" } else { 'Off: waits at the sign-in screen' }) } } }

  @{ id = 'activated'; name = 'Windows activated'; recommended = 'Yes'
     about = "An unactivated NUC shows the 'Activate Windows' watermark over Showcase."
     check = { $l = Get-CimInstance SoftwareLicensingProduct -Filter "PartialProductKey IS NOT NULL AND Name LIKE 'Windows%'" -ErrorAction SilentlyContinue | Select-Object -First 1
               @{ ok = ($l.LicenseStatus -eq 1); now = $(if ($l.LicenseStatus -eq 1) { 'Yes' } else { "No (status $($l.LicenseStatus))" }) } } }

  @{ id = 'windows_update'; name = 'Windows Update'; recommended = 'On, nights only (Quiet)'
     about = 'Some old setups switched Windows Update off. The Quiet module turns it back on and keeps updates to the night.'
     check = { $s = Get-Service wuauserv -ErrorAction SilentlyContinue
               @{ ok = ($s -and "$($s.StartType)" -ne 'Disabled'); now = $(if (-not $s) { 'Not found' } else { "Service $($s.StartType), $($s.Status)" }) } } }

  @{ id = 'daily_restart'; name = 'Daily restart'; recommended = "Fleet's, at $RestartLabel"
     about = "One restart a day at $RestartLabel, as SYSTEM, with nothing on the display. Any other restart task on this NUC is set aside (switched off and listed in the log), so it never restarts twice; 'Put back the old restart' undoes it. If the NUC is off at $RestartLabel it doesn't restart late."
     check = {
       $ours   = Get-ScheduledTask -TaskName $RestartTaskName -TaskPath '\' -ErrorAction SilentlyContinue
       $others = @(Get-RestartTasks | Where-Object { $_.TaskName -ne $RestartTaskName -and $_.State -ne 'Disabled' } | ForEach-Object { Format-RestartTask $_ })
       $oursOn = [bool]($ours -and $ours.State -ne 'Disabled')
       $now = @()
       if ($oursOn) { $now += "Fleet's at $(Format-RestartTask $ours -TimeOnly)" } elseif ($ours) { $now += "Fleet's, switched off" }
       if ($others.Count) { $now += "Other: $($others -join '; ')" }
       @{ ok = ($oursOn -and -not $others.Count); now = $(if ($now.Count) { $now -join '. ' } else { 'None found' }) } }
     apply = {
       # set the others aside first, so the NUC never has two restarts at once
       $saved = @(Get-SetAsideRestarts)
       foreach ($t in @(Get-RestartTasks | Where-Object { $_.TaskName -ne $RestartTaskName -and $_.State -ne 'Disabled' })) {
         Disable-ScheduledTask -TaskName $t.TaskName -TaskPath $t.TaskPath -ErrorAction Stop | Out-Null
         if (-not ($saved | Where-Object { $_.name -eq $t.TaskName -and $_.path -eq $t.TaskPath })) {
           $saved += [pscustomobject]@{ name = $t.TaskName; path = $t.TaskPath; was = (Format-RestartTask $t); at = (Get-Date).ToString('s') }
         }
         Write-BaselineLog "Set aside restart task $($t.TaskPath)$($t.TaskName) ($(Format-RestartTask $t))"
       }
       Save-SetAsideRestarts $saved
       Register-FleetRestart
       Write-BaselineLog "Fleet daily restart at $RestartLabel ($RestartTaskName)"
     } }
)

# ---- apply the ticked ones
$want = @($Apply -split '[,\s]+' | Where-Object { $_ })
# 'all' = every setting Baseline can set (the agent's nightly install, 23 Nov 2026)
if ($want -contains 'all') { $want = @($Settings | Where-Object { $_.apply } | ForEach-Object { $_.id }) }
if ($want.Count) {
  if (-not (Test-Admin)) { Fail 'Changing settings needs admin. Open Fleet from its desktop shortcut, which asks for it.' }
  else {
    foreach ($id in $want) {
      $s = $Settings | Where-Object { $_.id -eq $id }
      if (-not $s) { Warn "Unknown setting '$id', skipped."; continue }
      if (-not $s.apply) { Warn "$($s.name) is set by hand, skipped."; continue }
      try { & $s.apply | Out-Null; Ok "$($s.name): set to $($s.recommended)"; Write-BaselineLog "OK   $id" }
      catch { Fail "$($s.name): $($_.Exception.Message)"; Write-BaselineLog "FAIL $id - $($_.Exception.Message)" }
    }
  }
}

# ---- check every setting against what we recommend
$rows = foreach ($s in $Settings) {
  try { $r = & $s.check } catch { $r = @{ ok = $false; now = "Could not read: $($_.Exception.Message)" } }
  [ordered]@{ id = $s.id; name = $s.name; about = $s.about; recommended = $s.recommended; now = "$($r.now)"; ok = [bool]$r.ok; canApply = [bool]$s.apply }
}
$done = @($rows | Where-Object { $_.ok }).Count
$result = [ordered]@{ version = $Version; at = (Get-Date).ToString('ddd d MMM, h:mm tt'); done = $done; total = @($rows).Count; settings = @($rows) }
try { $result | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $Data 'last_check.json') -Encoding UTF8 } catch { }
Info "$done of $(@($rows).Count) settings as recommended on $env:COMPUTERNAME."
Send-Json $result
