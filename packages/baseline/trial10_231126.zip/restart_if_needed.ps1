# Showcase Fleet module: baseline, the daily restart itself (trial 10, 23 Nov 2026). Run by the SYSTEM task
# showcase_fleet_daily_restart at 4:30 am (Overnight Timetable.md), from a copy in C:\ProgramData\showcase_fleet\baseline,
# which only SYSTEM and admins can change. Skips the restart when it isn't needed or isn't safe:
#   1. the NUC already started up after 3:00 am tonight (Quiet's Windows Update restart did the job);
#   2. Windows is still installing an update (it restarts the NUC itself when it's done).
# Otherwise restarts with no countdown, so nothing shows on the display. Every decision goes in baseline.log.
$ErrorActionPreference = 'Continue'
$Log = Join-Path $PSScriptRoot 'baseline.log'
function Write-Log($m) { try { Add-Content -Path $Log -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m" -Encoding UTF8 } catch { } }

$boot = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
$threeAm = (Get-Date).Date.AddHours(3)
if ($boot -gt $threeAm) {
  Write-Log "Daily restart skipped: the NUC already started at $($boot.ToString('h:mm tt')) tonight."
  return
}
# TiWorker (Windows Modules Installer Worker) only runs while Windows is installing or finishing an update
if (Get-Process -Name TiWorker -ErrorAction SilentlyContinue) {
  Write-Log 'Daily restart skipped: Windows is installing an update and restarts the NUC itself when it is done.'
  return
}
Write-Log 'Daily restart: restarting now.'
& "$env:SystemRoot\System32\shutdown.exe" /r /f /t 0 /d p:0:0
