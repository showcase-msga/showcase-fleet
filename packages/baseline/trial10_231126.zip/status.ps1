# baseline: status (trial 9, unchanged since trial 3). Reads the last check only, so the window stays quick; Check runs a fresh one.
$file = Join-Path $env:ProgramData 'showcase_fleet\baseline\last_check.json'
if (-not (Test-Path $file)) { return @{ installed = $false; detail = 'Not checked on this NUC yet. Open the row and press Check.' } }
try { $c = Get-Content $file -Raw | ConvertFrom-Json } catch { return @{ installed = $false; detail = 'The last check could not be read. Check again.' } }
@{ installed = ($c.done -eq $c.total); version = "$($c.version)"; done = [int]$c.done; total = [int]$c.total; at = "$($c.at)"
   detail = "$($c.done) of $($c.total) as recommended at the last check, $($c.at)." }
