# Showcase Fleet module: baseline, "Put back the old restart" (trial 9, 10 Nov 2026; trial 10, 23 Nov: also puts back
# shutdown and hibernate tasks, such as a nightly hibernate routine, which Baseline now sets aside too).
# Removes Fleet's daily restart, then switches back on every restart task Baseline set aside, as it was.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
. (Join-Path $PSScriptRoot 'restart_common.ps1')
$Log = Join-Path (Get-ModuleData 'baseline') 'baseline.log'
function Write-BaselineLog($m) { try { Add-Content -Path $Log -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m" -Encoding UTF8; Limit-Log $Log } catch { } }

if (-not (Test-Admin)) { Fail 'This needs admin. Open Fleet from its desktop shortcut, which asks for it.'; return }

# ours first, so the NUC never has two restarts at once
if (Get-ScheduledTask -TaskName $RestartTaskName -TaskPath '\' -ErrorAction SilentlyContinue) {
  try {
    Unregister-ScheduledTask -TaskName $RestartTaskName -TaskPath '\' -Confirm:$false -ErrorAction Stop
    Ok "Fleet's $RestartLabel restart removed."; Write-BaselineLog 'Fleet daily restart removed'
  } catch { Fail "Fleet's restart could not be removed: $($_.Exception.Message)"; return }
} else { Info "Fleet's daily restart isn't on this NUC." }

$saved = @(Get-SetAsideRestarts)
$kept = @()
foreach ($s in $saved) {
  if (-not (Get-ScheduledTask -TaskName $s.name -TaskPath $s.path -ErrorAction SilentlyContinue)) {
    Warn "$($s.name) is no longer on this NUC, so there's nothing to switch back on."; continue
  }
  try {
    Enable-ScheduledTask -TaskName $s.name -TaskPath $s.path -ErrorAction Stop | Out-Null
    Ok "Switched back on: $($s.was)"; Write-BaselineLog "Put back restart task $($s.path)$($s.name)"
  } catch { Warn "Could not switch $($s.name) back on: $($_.Exception.Message)"; $kept += $s }
}
if (-not $saved.Count) { Info 'No restart tasks were set aside on this NUC.' }
if ($kept.Count) { Save-SetAsideRestarts $kept; Warn 'The ones that failed stay listed; run this again.' }
else { Remove-Item $SetAsideFile -Force -ErrorAction SilentlyContinue }
Info 'Press Check to see the daily restart row again.'
