# showcase_bluesound_restart_job___VERSION__
# The scheduled job. Installed by the Showcase Fleet Manager module bluesound_restart.
# Runs as SYSTEM from the showcase_bluesound_restart___VERSION__ task, so nothing ever shows on the display.
# A player that is playing is left alone, unless -Force ("Restart the player now" in Fleet Manager) is used.
# -DryRun finds the players and logs them without restarting anything.
param([switch]$DryRun, [switch]$Force)

$Version = '__VERSION__'
$Pinned = @(__PINNED__)
$log = Join-Path $PSScriptRoot 'showcase_bluesound_restart.log'

function Write-Log($m) {
  $line = '{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $m
  Add-Content -Path $log -Value $line -Encoding UTF8
  Write-Output $line
}

# a Bluesound player answers on port 11000 with a <SyncStatus> document
function Get-PlayerName($ip) {
  try {
    $r = Invoke-WebRequest -Uri "http://$($ip):11000/SyncStatus" -UseBasicParsing -TimeoutSec 4
    if ($r.Content -notmatch '<SyncStatus') { return $null }
    $n = ([xml]$r.Content).SyncStatus.name
    if ($n) { return $n } else { return 'Bluesound' }
  } catch { return $null }
}

# play, stream, pause, stop or connecting; empty if it can't tell
function Get-PlayerState($ip) {
  try {
    $r = Invoke-WebRequest -Uri "http://$($ip):11000/Status" -UseBasicParsing -TimeoutSec 4
    return "$(([xml]$r.Content).status.state)".Trim()
  } catch { return '' }
}

# every /24 the NUC sits on, every address, port 11000, all at once
function Find-Players {
  $found = @()
  $prefixes = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
    ForEach-Object { ($_.IPAddress -split '\.')[0..2] -join '.' } | Sort-Object -Unique
  foreach ($p in $prefixes) {
    $probes = foreach ($i in 1..254) {
      $c = New-Object System.Net.Sockets.TcpClient
      [pscustomobject]@{ Ip = "$p.$i"; Client = $c; Connect = $c.ConnectAsync("$p.$i", 11000) }
    }
    Start-Sleep -Milliseconds 1500
    foreach ($x in $probes) {
      $open = $x.Connect.Status -eq 'RanToCompletion' -and $x.Client.Connected
      $x.Client.Dispose()
      if ($open -and (Get-PlayerName $x.Ip)) { $found += $x.Ip }
    }
  }
  $found
}

try {
  $players = @($Pinned | Where-Object { Get-PlayerName $_ })
  $missing = @($Pinned | Where-Object { $players -notcontains $_ })
  if ($missing.Count) { Write-Log ("Pinned player not answering: {0}" -f ($missing -join ', ')) }
  if (-not $players.Count) { $players = @(Find-Players) }
  if (-not $players.Count) { Write-Log "No Bluesound player found on this network. Nothing restarted. (v$Version)"; exit 1 }

  $restarted = @()
  foreach ($ip in $players) {
    $name = Get-PlayerName $ip
    if ($DryRun) { Write-Log "Found $ip ($name). Test run, not restarted. (v$Version)"; continue }
    $state = Get-PlayerState $ip
    if (-not $Force -and $state -in 'play', 'stream') { Write-Log "Skipped $ip ($name): it is playing, so it was left alone. (v$Version)"; continue }
    try {
      Invoke-WebRequest -Uri "http://$ip/reboot" -Method Post -Body @{ yes = '1' } -UseBasicParsing -TimeoutSec 15 | Out-Null
      Write-Log "Restart sent to $ip ($name) (v$Version)"
      $restarted += $ip
    } catch {
      Write-Log "Restart FAILED for $ip ($name): $($_.Exception.Message)"
    }
  }

  if ($restarted.Count) {
    Write-Output 'Waiting 2 minutes for it to come back...'
    Start-Sleep -Seconds 120
    foreach ($ip in $restarted) {
      if (Get-PlayerName $ip) { Write-Log "$ip is back" } else { Write-Log "$ip is NOT answering 2 minutes after the restart. Check it." }
    }
  }
} catch {
  Write-Log "Error: $($_.Exception.Message)"
}

# keep the log short
$lines = @(Get-Content $log -ErrorAction SilentlyContinue)
if ($lines.Count -gt 1000) { $lines | Select-Object -Last 500 | Set-Content $log -Encoding UTF8 }
