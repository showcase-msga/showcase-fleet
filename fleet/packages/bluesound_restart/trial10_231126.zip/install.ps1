# bluesound_restart: install or update (trial10_231126: 4:00 to 4:15 am only, and local time so daylight saving can't move it)
param([string[]]$RestartDays = @('Monday', 'Friday'), [string]$RestartAt = '04:00', [string[]]$PlayerIps = @())
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
. (Join-Path $PSScriptRoot 'shared.ps1')

$at = [TimeSpan]::Zero
if (-not [TimeSpan]::TryParse($RestartAt, [ref]$at)) { throw 'The time must be 24-hour, like 04:00.' }
$RestartDays = @($RestartDays | Where-Object { $_ })
if (-not $RestartDays.Count) { throw 'Pick at least one day.' }
foreach ($d in $RestartDays) { if (-not [Enum]::IsDefined([DayOfWeek], [string]$d)) { throw "'$d' is not a day." } }
$PlayerIps = @($PlayerIps | ForEach-Object { "$_".Trim() } | Where-Object { $_ })
foreach ($ip in $PlayerIps) { if ($ip -notmatch '^\d{1,3}(\.\d{1,3}){3}$') { throw "'$ip' is not an IP address." } }

New-Item -ItemType Directory -Force -Path $Dir | Out-Null

# take out every older version, including the first build from before the naming convention;
# the first build's log is carried across
Get-RestartTasks | ForEach-Object { Unregister-ScheduledTask -TaskName $_.TaskName -Confirm:$false }
$old = Join-Path $env:ProgramData 'ShowcaseBluesound'
if (Test-Path (Join-Path $old 'bluesound.log')) { Get-Content (Join-Path $old 'bluesound.log') | Add-Content -Path $Log -Encoding UTF8 }
if (Test-Path $old) { Remove-Item $old -Recurse -Force }
Get-ChildItem $Dir -Filter 'showcase_bluesound_restart_job_*.ps1' | Remove-Item -Force

New-JobFile $Job $PlayerIps

$action    = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Job`""
if ($at -lt [TimeSpan]'04:00' -or $at -gt [TimeSpan]'04:15') { throw 'The time must be between 4:00 and 4:15 am (Overnight Timetable).' }
$trigger   = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $RestartDays -At ([datetime]::Today + $at)
# local time with no offset: a UTC start (what -At gives) moves the restart an hour when daylight saving changes
$trigger.StartBoundary = ([datetime]::Today + $at).ToString('yyyy-MM-ddTHH:mm:ss')
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $Task -Description "Showcase Fleet Manager: bluesound_restart $Version" -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null

Ok "Installed v$Version. Restarts every $($RestartDays -join ' and ') at $($at.ToString('hh\:mm')), unless it's playing."
Info "NUC clock now: $(Get-Date -Format 'ddd d MMM HH:mm')"
Info 'Looking for players now (nothing is restarted):'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Job -DryRun | ForEach-Object { Info $_ }
Info 'Use "Restart the player now" to test a real restart.'
