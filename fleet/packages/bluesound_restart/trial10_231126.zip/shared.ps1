# bluesound_restart: names and helpers used by install, remove, status and the actions.
$Version = 'trial10_231126'
$Dir  = Join-Path $env:ProgramData 'showcase_bluesound_restart'   # no version, so the log survives updates
$Log  = Join-Path $Dir 'showcase_bluesound_restart.log'
$Task = "showcase_bluesound_restart_$Version"
$Job  = Join-Path $Dir "showcase_bluesound_restart_job_$Version.ps1"

# every version ever installed, including the first build from before the naming convention
function Get-RestartTasks {
  @(Get-ScheduledTask -TaskName 'Showcase Bluesound Restart', 'showcase_bluesound_restart_*' -ErrorAction SilentlyContinue)
}

# writes the scheduled job from the template, with the pinned players and the version filled in
function New-JobFile($path, [string[]]$pinned) {
  $list = (@($pinned) | Where-Object { $_ } | ForEach-Object { "'$_'" }) -join ','
  $code = (Get-Content (Join-Path $PSScriptRoot 'job_template.ps1') -Raw).Replace('__PINNED__', $list).Replace('__VERSION__', $Version)
  Set-Content -Path $path -Value $code -Encoding UTF8
}
