# bluesound_restart: remove (141026). The player is no longer restarted.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
. (Join-Path $PSScriptRoot 'shared.ps1')

Get-RestartTasks | ForEach-Object {
  Stop-ScheduledTask -TaskName $_.TaskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $_.TaskName -Confirm:$false
}
foreach ($d in @($Dir, (Join-Path $env:ProgramData 'ShowcaseBluesound'))) { if (Test-Path $d) { Remove-Item $d -Recurse -Force } }
if (Get-RestartTasks) { Warn 'A restart task is still there. Delete it in Task Scheduler by hand.' }
else { Ok 'Removed. The Bluesound player is no longer restarted.' }
