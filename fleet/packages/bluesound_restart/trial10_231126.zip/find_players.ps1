# bluesound_restart: find the Bluesound players on this network without restarting anything (141026).
# Works whether or not the module is installed.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
. (Join-Path $PSScriptRoot 'shared.ps1')

$tmp = Join-Path $env:TEMP "showcase_fleet_find_players_$Version"
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
$file = Join-Path $tmp 'find.ps1'
New-JobFile $file @()
Info 'Looking for Bluesound players on every network this NUC is on (port 11000)...'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $file -DryRun | ForEach-Object { Info $_ }
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
