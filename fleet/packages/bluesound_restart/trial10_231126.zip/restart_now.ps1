# bluesound_restart: restart the player now, even if it is playing (141026)
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
. (Join-Path $PSScriptRoot 'shared.ps1')

$installed = Get-RestartTasks | Select-Object -First 1
if (-not $installed) { throw 'Not installed on this NUC. Install it first.' }
# an older version's job file has a different name; use whichever the task runs
$file = ([regex]::Match("$($installed.Actions[0].Arguments)", '-File\s+"([^"]+)"')).Groups[1].Value
if (-not $file -or -not (Test-Path $file)) { throw 'The installed job file is missing. Install again.' }
Info 'Restarting the Bluesound player now. The music stops for about a minute.'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $file -Force | ForEach-Object { Info $_ }
Info '"Restart sent" followed by "is back" means it worked.'
