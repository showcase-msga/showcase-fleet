# bluesound_restart: status. Returns a hashtable; reads only.
. (Join-Path $PSScriptRoot 'shared.ps1')
$t = Get-RestartTasks | Select-Object -First 1
if (-not $t) { return @{ installed = $false } }

$version = if ($t.TaskName -match '_(\d{6})$') { $Matches[1] } else { 'standalone' }
$tr = $t.Triggers | Select-Object -First 1
$time = '{0:HH:mm}' -f [datetime]$tr.StartBoundary
$mask = $tr.CimInstanceProperties['DaysOfWeek'].Value
$names = 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
$days = @(0..6 | Where-Object { $mask -band (1 -shl $_) } | ForEach-Object { $names[$_] })

$pinned = @()
$file = ([regex]::Match("$($t.Actions[0].Arguments)", '-File\s+"([^"]+)"')).Groups[1].Value
if ($file -and (Test-Path $file)) {
  $line = Select-String -Path $file -Pattern '^\$Pinned = @\((.*)\)' | Select-Object -First 1
  if ($line) { $pinned = @([regex]::Matches($line.Matches[0].Groups[1].Value, "'([^']+)'") | ForEach-Object { $_.Groups[1].Value }) }
}

$last = Get-Content $Log -Tail 1 -ErrorAction SilentlyContinue
@{
  installed = $true; version = $version
  settings  = @{ RestartDays = $days; RestartAt = $time; PlayerIps = $pinned }
  detail    = "Every $(($days | ForEach-Object { $_.Substring(0, 3) }) -join ' and ') at $time$(if ($pinned) { ', players ' + ($pinned -join ', ') } else { ', any player on the network' }).$(if ($last) { ' Last: ' + $last })"
}
