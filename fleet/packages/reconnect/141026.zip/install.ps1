# reconnect: install or update (141026)
param([ValidateSet('no', 'yes')][string]$BounceCable = 'no')
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')

$task = 'showcase_fleet_reconnect'
$data = Get-ModuleData 'reconnect'

Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue | Stop-ScheduledTask
Start-Sleep -Seconds 1
Copy-Item (Join-Path $PSScriptRoot 'reconnect.ps1') (Join-Path $data 'reconnect.ps1') -Force
@{ version = '141026'; BounceCable = $BounceCable } | ConvertTo-Json | Set-Content (Join-Path $data 'config.json') -Encoding UTF8

$action    = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$(Join-Path $data 'reconnect.ps1')`""
$atStart   = New-ScheduledTaskTrigger -AtStartup
# every 5 minutes: brings it back if it ever stops, does nothing while it is running
$revive    = New-ScheduledTaskTrigger -Once -At (Get-Date).Date -RepetitionInterval (New-TimeSpan -Minutes 5)
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -Force -TaskName $task -Description 'Showcase Fleet Manager: reconnect 141026' -Action $action -Trigger @($atStart, $revive) -Principal $principal -Settings $settings | Out-Null
Start-ScheduledTask -TaskName $task
Start-Sleep -Seconds 3

if ((Get-ScheduledTask -TaskName $task).State -eq 'Running') { Ok 'Reconnect is running in the background.' }
else { Warn 'Installed, but it is not running yet. It starts within 5 minutes; check the log.' }
Info "Cable adapter restart: $(if ($BounceCable -eq 'yes') { 'on' } else { 'off (Wi-Fi only)' })."
