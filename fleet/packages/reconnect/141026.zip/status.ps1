# reconnect: status. Returns a hashtable; reads only.
$task = Get-ScheduledTask -TaskName 'showcase_fleet_reconnect' -ErrorAction SilentlyContinue
if (-not $task) { return @{ installed = $false } }
$data = Join-Path $env:ProgramData 'showcase_fleet\reconnect'
$cfg = $null
try { $cfg = Get-Content (Join-Path $data 'config.json') -Raw | ConvertFrom-Json } catch { }
$running = $task.State -eq 'Running'
$last = Get-Content (Join-Path $data 'reconnect.log') -Tail 1 -ErrorAction SilentlyContinue
$drops = @(Select-String -Path (Join-Path $data 'reconnect.log') -Pattern 'Offline:' -ErrorAction SilentlyContinue |
  Where-Object { $_.Line -ge (Get-Date).AddDays(-7).ToString('yyyy-MM-dd') }).Count
@{
  installed = $true; version = $(if ($cfg) { $cfg.version } else { '?' }); problem = -not $running
  settings  = @{ BounceCable = $(if ($cfg) { $cfg.BounceCable } else { 'no' }) }
  detail    = "$(if ($running) { 'Watching.' } else { 'Not running right now; it restarts within 5 minutes.' }) $drops drops in the last 7 days.$(if ($last) { ' Last: ' + $last })"
}
