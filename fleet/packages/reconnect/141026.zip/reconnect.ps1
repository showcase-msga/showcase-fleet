# Showcase Fleet Manager module: reconnect (141026). The watchdog itself.
# Runs as SYSTEM from the showcase_fleet_reconnect task: at start-up, and every 5 minutes in case it
# stopped (the task ignores a second copy while one is running). Nothing shows on the display.
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$Version = '141026'
$log = Join-Path $PSScriptRoot 'reconnect.log'
$state = Join-Path $PSScriptRoot 'state.json'
$cfg = Get-Content (Join-Path $PSScriptRoot 'config.json') -Raw | ConvertFrom-Json
$bounceCable = "$($cfg.BounceCable)" -eq 'yes'

function Log($m) {
  Add-Content -Path $log -Value ('{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $m) -Encoding UTF8
  if ((Get-Item $log).Length -gt 1MB) {
    Get-Content $log -Tail 2000 | Set-Content "$log.tmp" -Encoding UTF8
    Move-Item "$log.tmp" $log -Force
  }
}

# online = any of these answers on port 443 within 3 seconds; Showcase first
function Test-Online {
  foreach ($h in 'app.showcase.space', '1.1.1.1', '8.8.8.8') {
    $c = New-Object Net.Sockets.TcpClient
    try { if ($c.ConnectAsync($h, 443).Wait(3000) -and $c.Connected) { return $true } } catch { } finally { $c.Dispose() }
  }
  $false
}

function Get-Wifi {
  Get-NetAdapter -Physical -ErrorAction SilentlyContinue |
    Where-Object { $_.PhysicalMediaType -match '802\.11|Wireless' -or $_.InterfaceDescription -match 'Wi-?Fi|Wireless' } |
    Select-Object -First 1
}
function Get-Cable {
  Get-NetAdapter -Physical -ErrorAction SilentlyContinue |
    Where-Object { $_.PhysicalMediaType -eq '802.3' -and $_.InterfaceDescription -notmatch 'Wi-?Fi|Wireless|Bluetooth' }
}

# the Wi-Fi profile in use while online, so it can be reconnected to when it drops
function Save-WifiProfile {
  $lines = & netsh.exe wlan show interfaces 2>$null
  $p = $lines | Select-String -Pattern '^\s*Profile\s*:\s*(.+)$' | Select-Object -First 1
  if ($p) { @{ wifiProfile = $p.Matches[0].Groups[1].Value.Trim() } | ConvertTo-Json | Set-Content $state -Encoding UTF8 }
}
function Get-WifiProfile {
  try { (Get-Content $state -Raw | ConvertFrom-Json).wifiProfile } catch { $null }
}

function Wait-Online([int]$seconds) {
  $until = (Get-Date).AddSeconds($seconds)
  while ((Get-Date) -lt $until) { if (Test-Online) { return $true }; Start-Sleep -Seconds 5 }
  $false
}

function Repair {
  $wifi = Get-Wifi
  $profileName = Get-WifiProfile
  if ($wifi -and $profileName) {
    Log "Step 1: reconnecting Wi-Fi '$profileName' on $($wifi.Name)"
    & netsh.exe wlan connect name="$profileName" interface="$($wifi.Name)" | Out-Null
    if (Wait-Online 30) { return 'reconnecting the Wi-Fi' }
  }
  Log 'Step 2: renewing the network address'
  & ipconfig.exe /renew | Out-Null
  if (Wait-Online 30) { return 'renewing the network address' }
  $targets = @()
  if ($wifi) { $targets += $wifi }
  if ($bounceCable) { $targets += @(Get-Cable) }
  if ($targets.Count) {
    Log "Step 3: restarting $(($targets | ForEach-Object { $_.Name }) -join ' and ')"
    $targets | ForEach-Object { Restart-NetAdapter -Name $_.Name -Confirm:$false -ErrorAction SilentlyContinue }
    if (Wait-Online 60) { return 'restarting the network adapter' }
  }
  $null
}

Log "Started v$Version (cable adapter restart $(if ($bounceCable) { 'on' } else { 'off' }))"
$misses = 0
$downSince = $null
$lastSaved = Get-Date '2000-01-01'
while ($true) {
  if (Test-Online) {
    if ($downSince) {
      Log ("Back online after {0:N0} minutes" -f ((Get-Date) - $downSince).TotalMinutes)
      $downSince = $null
    }
    $misses = 0
    if (((Get-Date) - $lastSaved).TotalMinutes -ge 10) { Save-WifiProfile; $lastSaved = Get-Date }
    Start-Sleep -Seconds 30
    continue
  }
  $misses++
  if ($misses -lt 2) { Start-Sleep -Seconds 15; continue }
  if (-not $downSince) { $downSince = Get-Date; Log 'Offline: two checks in a row failed' }
  $fixedBy = Repair
  if ($fixedBy) {
    Log ("Back online after {0:N0} minutes, by {1}" -f ((Get-Date) - $downSince).TotalMinutes, $fixedBy)
    $downSince = $null; $misses = 0
    Start-Sleep -Seconds 30
  } else {
    Log 'Still offline after all three steps. Trying again in 5 minutes.'
    Start-Sleep -Seconds 300
  }
}
