# reconnect: remove (141026)
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')

$task = 'showcase_fleet_reconnect'
Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue | Stop-ScheduledTask
Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
$data = Join-Path $FleetData 'reconnect'
Remove-Item $data -Recurse -Force -ErrorAction SilentlyContinue
if (Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue) { Warn "The task is still there. Delete '$task' in Task Scheduler by hand." }
else { Ok 'Reconnect removed.' }
