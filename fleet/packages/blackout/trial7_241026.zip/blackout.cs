// Showcase Fleet Manager module: blackout. Compiled to ShowcaseBlackout.exe by install.ps1.
// Same code as AD/01 Operations/Showcase Blackout (5 Oct 2026), so an existing install is replaced cleanly.
// Trial 7 (24 Oct 2026): one black window per real screen, never over Fleet's hidden support screen (the Virtual
// Display Driver's), so support can still work on it over remote access at night; per-monitor DPI aware.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace ShowcaseBlackout
{
    public static class Schedule
    {
        // true when the screen should be black; handles hours that cross midnight
        public static bool IsOff(TimeSpan now, TimeSpan offAt, TimeSpan onAt)
        {
            if (offAt == onAt) return false;
            if (offAt > onAt) return now >= offAt || now < onAt;
            return now >= offAt && now < onAt;
        }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct DISPLAY_DEVICE
    {
        public int cb;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
        public int StateFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
    }

    // the screens a cable shows: every screen except the Virtual Display Driver's (Fleet's hidden support screen),
    // known the way the support screen program knows it, by its adapter name or its monitor's id
    public static class Screens
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto)] static extern bool EnumDisplayDevices(string device, uint num, ref DISPLAY_DEVICE dd, uint flags);

        public static List<Rectangle> Real()
        {
            HashSet<string> hidden = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (uint i = 0; ; i++)
            {
                DISPLAY_DEVICE d = new DISPLAY_DEVICE(); d.cb = Marshal.SizeOf(d);
                if (!EnumDisplayDevices(null, i, ref d, 0)) break;
                DISPLAY_DEVICE m = new DISPLAY_DEVICE(); m.cb = Marshal.SizeOf(m);
                string monitorId = EnumDisplayDevices(d.DeviceName, 0, ref m, 0) ? (m.DeviceID ?? "") : "";
                if ((d.DeviceString ?? "").IndexOf("Virtual Display Driver", StringComparison.OrdinalIgnoreCase) >= 0
                    || monitorId.IndexOf("MTT1337", StringComparison.OrdinalIgnoreCase) >= 0) hidden.Add(d.DeviceName);
            }
            List<Rectangle> real = new List<Rectangle>();
            foreach (Screen s in Screen.AllScreens) if (!hidden.Contains(s.DeviceName)) real.Add(s.Bounds);
            return real;
        }
    }

    // one black, borderless, always-on-top window; never takes focus, never in Alt+Tab, no mouse pointer
    public class Black : Form
    {
        public Black(Cursor blank)
        {
            FormBorderStyle = FormBorderStyle.None;
            BackColor = Color.Black;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            TopMost = true;
            Cursor = blank;
        }

        protected override bool ShowWithoutActivation { get { return true; } }
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x80 | 0x08000000; // WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE
                return cp;
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; return; }
            base.OnFormClosing(e);
        }
    }

    // never shown itself: holds the hotkey and the timer, and puts a black window over each real screen
    public class Overlay : Form
    {
        [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint mods, uint vk);
        [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);

        const int WM_HOTKEY = 0x0312, HOTKEY_ID = 1;
        const uint MOD_ALT = 1, MOD_CONTROL = 2, MOD_SHIFT = 4, MOD_NOREPEAT = 0x4000;
        const uint SWP_NOSIZE = 0x1, SWP_NOMOVE = 0x2, SWP_NOACTIVATE = 0x10, SWP_SHOWWINDOW = 0x40;
        static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);

        readonly TimeSpan offAt, onAt;
        readonly string logPath;
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        readonly List<Black> blacks = new List<Black>();
        readonly Cursor blank = BlankCursor();
        bool lastScheduled, flipped, black;

        public Overlay(TimeSpan offAt, TimeSpan onAt, string logPath)
        {
            this.offAt = offAt;
            this.onAt = onAt;
            this.logPath = logPath;

            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;

            // the LED processor can drop and come back at a different size; follow it
            Microsoft.Win32.SystemEvents.DisplaySettingsChanged += delegate { if (black) Cover(); };

            IntPtr handle = Handle; // the hotkey needs a window handle; this window is never shown
            if (RegisterHotKey(handle, HOTKEY_ID, MOD_CONTROL | MOD_ALT | MOD_SHIFT | MOD_NOREPEAT, (uint)Keys.B))
                Log("Started, black " + Hhmm(offAt) + " to " + Hhmm(onAt) + ", hotkey Ctrl+Alt+Shift+B ready");
            else
                Log("Started, black " + Hhmm(offAt) + " to " + Hhmm(onAt) + ", but Ctrl+Alt+Shift+B is taken by another program, so no override");

            lastScheduled = Schedule.IsOff(DateTime.Now.TimeOfDay, offAt, onAt);
            Tick();
            timer.Interval = 30000;
            timer.Tick += delegate { Tick(); };
            timer.Start();
        }

        protected override void SetVisibleCore(bool value) { base.SetVisibleCore(false); }

        void Tick()
        {
            bool scheduled = Schedule.IsOff(DateTime.Now.TimeOfDay, offAt, onAt);
            if (scheduled != lastScheduled)
            {
                lastScheduled = scheduled;
                flipped = false; // an override only lasts until the next scheduled change
            }
            Apply(scheduled ^ flipped);
        }

        void Apply(bool wantBlack)
        {
            if (wantBlack)
            {
                int n = Cover();
                if (!black) Log("Screen black (" + n + " screen" + (n == 1 ? "" : "s") + ")");
            }
            else if (black)
            {
                foreach (Black b in blacks) b.Hide();
                Log("Screen showing");
            }
            black = wantBlack;
        }

        // a black window over each real screen, sized to it; spares hidden. Re-asserted on top on every tick in case
        // something else went on top. Returns how many screens are covered.
        int Cover()
        {
            List<Rectangle> real = Screens.Real();
            while (blacks.Count < real.Count) blacks.Add(new Black(blank));
            for (int i = 0; i < blacks.Count; i++)
            {
                Black b = blacks[i];
                if (i >= real.Count) { if (b.Visible) b.Hide(); continue; }
                if (b.Bounds != real[i]) b.Bounds = real[i];
                if (!b.Visible) b.Show();
                SetWindowPos(b.Handle, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
            }
            return real.Count;
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID)
            {
                flipped = !flipped;
                Tick();
                Log("Hotkey: " + (black ? "black" : "showing") + " until " + Hhmm(lastScheduled ? onAt : offAt));
                return;
            }
            base.WndProc(ref m);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; return; }
            base.OnFormClosing(e);
        }

        static Cursor BlankCursor()
        {
            using (Bitmap bmp = new Bitmap(32, 32)) return new Cursor(bmp.GetHicon());
        }

        static string Hhmm(TimeSpan t) { return t.ToString(@"hh\:mm"); }

        void Log(string msg) { Program.Write(logPath, msg); }
    }

    public static class Program
    {
        public const string Version = "trial7_241026";

        [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr value);

        public static void Write(string path, string msg)
        {
            try { File.AppendAllText(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + msg + Environment.NewLine); }
            catch { }
        }

        // per-monitor DPI aware (v2), so each black window is the real pixel size of its screen, whatever the
        // screen's scaling; older Windows falls back to system aware
        static void DpiAware()
        {
            try { if (SetProcessDpiAwarenessContext(new IntPtr(-4))) return; } catch { }
            try { SetProcessDPIAware(); } catch { }
        }

        [STAThread]
        public static void Main(string[] args)
        {
            DpiAware();
            string log = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "blackout.log");
            TimeSpan offAt, onAt;
            if (args.Length != 2 || !TimeSpan.TryParse(args[0], out offAt) || !TimeSpan.TryParse(args[1], out onAt))
            {
                Write(log, "Bad arguments, expected: ShowcaseBlackout.exe 18:30 08:00");
                return;
            }

            bool first;
            using (Mutex mutex = new Mutex(true, @"Local\ShowcaseBlackout", out first))
            {
                if (!first) return; // already running; the 5-minute task trigger lands here

                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.ThreadException += delegate(object s, ThreadExceptionEventArgs e) { Write(log, "Error: " + e.Exception.Message); };
                AppDomain.CurrentDomain.UnhandledException += delegate(object s, UnhandledExceptionEventArgs e) { Write(log, "Crashed: " + e.ExceptionObject); };

                Overlay overlay = new Overlay(offAt, onAt, log);
                Application.Run();
                GC.KeepAlive(overlay);
            }
        }
    }
}
