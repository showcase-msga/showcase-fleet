# blackout: status. Returns a hashtable; reads only.
$task = Get-ScheduledTask -TaskName 'Showcase Blackout' -ErrorAction SilentlyContinue
if (-not $task) { return @{ installed = $false } }
$dir = Join-Path $env:ProgramData 'ShowcaseBlackout'
$version = "$(Get-Content (Join-Path $dir 'version.txt') -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
if (-not $version) { $version = 'standalone' }   # installed with the 5 Oct script, before Fleet Manager
$times = "$($task.Actions[0].Arguments)".Trim() -split '\s+'
$running = [bool](Get-Process ShowcaseBlackout -ErrorAction SilentlyContinue)
$settings = @{}
if ($times.Count -eq 2) { $settings = @{ OffAt = $times[0]; OnAt = $times[1] } }
@{
  installed = $true; version = $version; problem = -not $running; settings = $settings
  detail = "Black $($times -join ' to '), every day. $(if ($running) { 'Running.' } else { 'Not running right now: it starts at sign-in and every 5 minutes.' })"
}
