# blackout: install or update (trial 7, 24 Oct 2026). Trial 7: the black screen covers only the real screens,
# never Fleet's hidden support screen.
param([string]$OffAt = '18:30', [string]$OnAt = '08:00')
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')

$off = [TimeSpan]::Zero; $on = [TimeSpan]::Zero
if (-not [TimeSpan]::TryParse($OffAt, [ref]$off) -or -not [TimeSpan]::TryParse($OnAt, [ref]$on)) { throw 'Times must be 24-hour, like 18:30 and 08:00.' }
if ($off -eq $on) { throw 'The two times are the same, so the screen would never go black.' }
$OffAt = $off.ToString('hh\:mm'); $OnAt = $on.ToString('hh\:mm')

# the black screen has to run as whoever is signed in on the display, or it cannot draw on it
$user = Get-DisplayUser

# same folder and task as the standalone Showcase Blackout, so an older install is replaced, not doubled
$dir  = Join-Path $env:ProgramData 'ShowcaseBlackout'
$exe  = Join-Path $dir 'ShowcaseBlackout.exe'
$task = 'Showcase Blackout'

Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue | Stop-ScheduledTask
Get-Process ShowcaseBlackout -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 1
New-Item -ItemType Directory -Force -Path $dir | Out-Null
# it writes its log as the signed-in user (Users group by SID, so any Windows language works)
& icacls.exe $dir /grant '*S-1-5-32-545:(OI)(CI)M' | Out-Null

Step 'Built the black screen program' {
  Remove-Item $exe -Force -ErrorAction SilentlyContinue
  Add-Type -TypeDefinition (Get-Content (Join-Path $PSScriptRoot 'blackout.cs') -Raw) -ReferencedAssemblies System.Windows.Forms, System.Drawing -OutputAssembly $exe -OutputType WindowsApplication
}
if (-not (Test-Path $exe)) { throw 'The black screen program could not be built.' }

$action    = New-ScheduledTaskAction -Execute $exe -Argument "$OffAt $OnAt" -WorkingDirectory $dir
$atLogon   = New-ScheduledTaskTrigger -AtLogOn -User $user
# every 5 minutes: brings it back if it ever closes, does nothing while it is running
$revive    = New-ScheduledTaskTrigger -Once -At (Get-Date).Date -RepetitionInterval (New-TimeSpan -Minutes 5)
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
$settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -Force -TaskName $task -Description 'Showcase Fleet: blackout trial7_241026' -Action $action -Trigger @($atLogon, $revive) -Principal $principal -Settings $settings | Out-Null
Start-ScheduledTask -TaskName $task
Start-Sleep -Seconds 3
Set-Content (Join-Path $dir 'version.txt') 'trial7_241026'

$now = Get-Date
$t = $now.TimeOfDay
$isOff = if ($off -gt $on) { $t -ge $off -or $t -lt $on } else { $t -ge $off -and $t -lt $on }
if (Get-Process ShowcaseBlackout -ErrorAction SilentlyContinue) { Ok 'The blackout is running.' }
else { Warn "Installed, but it is not running. Check the log." }
Info "NUC clock: $($now.ToString('ddd d MMM, HH:mm')) ($((Get-TimeZone).Id)). Check this is the site's local time."
Info "Black $OffAt to $OnAt, every day. Right now it should be $(if ($isOff) { 'BLACK' } else { 'showing Showcase' })."
Info "Running as $user. Ctrl+Alt+Shift+B flips it until the next scheduled change."
