# blackout: remove (141026). Takes the black screen off for good.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')

$task = 'Showcase Blackout'
$dir  = Join-Path $env:ProgramData 'ShowcaseBlackout'
Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue | Stop-ScheduledTask
Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
Get-Process ShowcaseBlackout -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2
Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue

if (Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue) { Warn "The task is still there. Delete '$task' in Task Scheduler by hand." }
elseif (Test-Path $dir) { Warn "The task is gone, but $dir could not be deleted. Restart the NUC, then remove again." }
else { Ok 'Blackout removed. The screen stays on all the time again.' }
