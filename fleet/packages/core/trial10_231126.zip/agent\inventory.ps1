# Showcase Fleet agent: what's on this NUC (23 Nov 2026). Reads only; changes nothing. Sent to the dashboard when
# Fleet is installed, once a day after, and when the console asks. Built on the NUC info tool, plus what decides
# a safe install: every task that restarts, shuts down or hibernates the NUC (including a nightly routine kept in a
# script), what starts with Windows, and what Fleet itself has here.
. (Join-Path $PSScriptRoot '..\app\common.ps1')
$ErrorActionPreference = 'Continue'
$out = [ordered]@{}

# ---- the NUC info tool's groups, as { group: { item: value } }
try {
  $lines = & (Join-Path $PSScriptRoot '..\tools\nuc_info\run.ps1') 2>$null
  $json = @($lines | Where-Object { "$_" -like '@@JSON *' }) | Select-Object -Last 1
  if ($json) {
    foreach ($g in ("$json".Substring(7) | ConvertFrom-Json).groups) {
      $items = [ordered]@{}
      foreach ($pair in $g.items) { $items["$($pair[0])"] = "$($pair[1])" }
      $out[$g.name] = $items
    }
  }
} catch { $out['NUC info'] = "Could not read: $($_.Exception.Message)" }

# ---- night-time tasks: anything that restarts, shuts down or hibernates the NUC (Baseline sets these aside)
$pattern = 'shutdown(\.exe)?"?\s.*[/-][rsh]\b|Restart-Computer|Stop-Computer|SetSuspendState|psshutdown'
function Get-ScriptText($a) {
  foreach ($m in [regex]::Matches("$($a.Execute) $($a.Arguments)", '"([^"]+\.(?:bat|cmd|ps1|vbs))"|(\S+\.(?:bat|cmd|ps1|vbs))', 'IgnoreCase')) {
    $p = [Environment]::ExpandEnvironmentVariables($(if ($m.Groups[1].Success) { $m.Groups[1].Value } else { $m.Groups[2].Value }))
    try { if ((Test-Path -LiteralPath $p -PathType Leaf) -and (Get-Item -LiteralPath $p).Length -lt 1MB) { Get-Content -LiteralPath $p -Raw } } catch { }
  }
}
$night = [ordered]@{}
foreach ($t in @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -notlike '\Microsoft\*' })) {
  $hit = $t.Actions | Where-Object { "$($_.Execute) $($_.Arguments)" -match $pattern -or "$(Get-ScriptText $_)" -match $pattern }
  if (-not $hit -and $t.TaskName -notlike 'showcase*') { continue }
  $when = @($t.Triggers | ForEach-Object {
    if ($_.StartBoundary) { try { ([datetime]$_.StartBoundary).ToString('h:mm tt') } catch { $_.StartBoundary } } else { $_.CimClass.CimClassName -replace 'MSFT_Task|Trigger', '' }
  }) -join ', '
  $what = if ($hit) { 'restarts, shuts down or hibernates' } else { 'Showcase task' }
  $night["$($t.TaskPath)$($t.TaskName)"] = "$what; $($t.State); $when; $(($t.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)".Trim() }) -join ' | ')"
}
$out['Scheduled tasks (restart, shutdown, hibernate, Showcase)'] = $(if ($night.Count) { $night } else { 'None' })

# ---- what starts with Windows (startup folders and Run keys)
$start = [ordered]@{}
$dirs = @("$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp")
try { $u = Get-UserStartupDir; if ($u) { $dirs += $u } } catch { }
foreach ($d in $dirs) { Get-ChildItem -LiteralPath $d -File -ErrorAction SilentlyContinue | ForEach-Object { $start[$_.Name] = $_.FullName } }
foreach ($k in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run') {
  $p = Get-ItemProperty $k -ErrorAction SilentlyContinue
  if ($p) { foreach ($n in $p.PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' }) { $start["$($n.Name) (Run key)"] = "$($n.Value)" } }
}
$out['Starts with Windows'] = $(if ($start.Count) { $start } else { 'Nothing' })

# ---- Fleet itself
$fleet = [ordered]@{}
$fleet['Fleet version'] = "$(Get-Content (Join-Path $PSScriptRoot '..\app\version.txt') -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
foreach ($m in Get-ChildItem (Join-Path $PSScriptRoot '..\modules') -Directory -ErrorAction SilentlyContinue) {
  try { $j = Get-Content (Join-Path $m.FullName 'module.json') -Raw -Encoding UTF8 | ConvertFrom-Json; $fleet["Module $($j.id)"] = "$($j.version) (files here)" } catch { }
}
$c = Get-NucConfig
$fleet['nucId in nuc.config'] = "$($c.NucId)"
$fleet['Showcase URL in nuc.config'] = $(if ($c.ShowcaseUrl) { Hide-UrlKeys $c.ShowcaseUrl } else { 'not set' })
$out['Showcase Fleet'] = $fleet

Send-Json ([ordered]@{ at = (Get-Date).ToString('s'); groups = $out })
