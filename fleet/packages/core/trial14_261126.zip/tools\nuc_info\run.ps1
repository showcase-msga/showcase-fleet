# Tool: NUC info (141026; trial 14, 26 Nov 2026: auto-login proved from the last start, and the real screens when the
# agent runs it as SYSTEM). Reads only.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$ErrorActionPreference = 'Continue'

$groups = New-Object Collections.ArrayList
function New-Group($name) { $g = [ordered]@{ name = $name; items = New-Object Collections.ArrayList }; [void]$groups.Add($g); $g }
function Add-Item($g, $k, $v) { if ($null -eq $v -or "$v" -eq '') { $v = '-' }; [void]$g.items.Add(@("$k", "$v")) }
function Try-Get([scriptblock]$s) { try { & $s } catch { "could not read ($($_.Exception.Message))" } }

$cs   = Get-CimInstance Win32_ComputerSystem
$os   = Get-CimInstance Win32_OperatingSystem
$bios = Get-CimInstance Win32_BIOS
$cv   = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'

# ---- this NUC
$g = New-Group 'This NUC'
Add-Item $g 'Computer name' $env:COMPUTERNAME
Add-Item $g 'Model' "$($cs.Manufacturer) $($cs.Model)".Trim()
Add-Item $g 'Serial number' $bios.SerialNumber
Add-Item $g 'Signed in on the display' $cs.UserName
$up = (Get-Date) - $os.LastBootUpTime
Add-Item $g 'Last started' ("{0:ddd d MMM, h:mm tt} ({1}d {2}h ago)" -f $os.LastBootUpTime, $up.Days, $up.Hours)
Add-Item $g 'Clock' ("{0:ddd d MMM, h:mm tt}, {1}" -f (Get-Date), (Get-TimeZone).Id)

# ---- Windows
$g = New-Group 'Windows'
Add-Item $g 'Edition' "$($os.Caption) $($cv.DisplayVersion) (build $($cv.CurrentBuild).$($cv.UBR))"
Add-Item $g 'Activated' (Try-Get {
  $l = Get-CimInstance SoftwareLicensingProduct -Filter "PartialProductKey IS NOT NULL AND Name LIKE 'Windows%'" | Select-Object -First 1
  if ($l.LicenseStatus -eq 1) { 'Yes' } else { "No (status $($l.LicenseStatus)). The 'Activate Windows' watermark shows on screen." }
})
$au = Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -ErrorAction SilentlyContinue
$wuStart = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\wuauserv' -ErrorAction SilentlyContinue).Start
Add-Item $g 'Windows Update' $(
  if ($wuStart -eq 4) { 'Switched off (service disabled). No patches.' }
  elseif ($au.NoAutoUpdate -eq 1) { 'Switched off by policy. No patches.' }
  elseif ($au.AUOptions -eq 4 -and $null -ne $au.ScheduledInstallTime) { "Night only, at $($au.ScheduledInstallTime):00 (Quiet)" }
  else { 'Windows default: it can restart and pop up during the day' })
Add-Item $g 'Last update installed' (Try-Get { $h = Get-HotFix | Where-Object InstalledOn | Sort-Object InstalledOn -Descending | Select-Object -First 1; "$($h.HotFixID), $('{0:d MMM yyyy}' -f $h.InstalledOn)" })

# ---- hardware
$g = New-Group 'Hardware'
Add-Item $g 'Processor' ((Get-CimInstance Win32_Processor | Select-Object -First 1).Name -replace '\s+', ' ')
Add-Item $g 'Memory' ("{0:N0} GB" -f ($cs.TotalPhysicalMemory / 1GB))
$c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$freePct = [Math]::Round(100 * $c.FreeSpace / $c.Size)
Add-Item $g 'Disk C:' ("{0:N0} GB free of {1:N0} GB ({2}%){3}" -f ($c.FreeSpace / 1GB), ($c.Size / 1GB), $freePct, $(if ($freePct -lt 15) { ': LOW' }))
Add-Item $g 'Graphics' ((Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name }) -join '; ')

# ---- displays
$g = New-Group 'Displays'
if ([Diagnostics.Process]::GetCurrentProcess().SessionId -ne 0) {
  # opened by a tech on the NUC: the screens as Windows lays them out
  Add-Type -AssemblyName System.Windows.Forms
  $i = 0
  foreach ($s in [System.Windows.Forms.Screen]::AllScreens) {
    $i++
    Add-Item $g "Display $i$(if ($s.Primary) { ' (main)' })" "$($s.Bounds.Width) x $($s.Bounds.Height) at $($s.Bounds.X),$($s.Bounds.Y)"
  }
  $rate = (Get-CimInstance Win32_VideoController | Where-Object CurrentRefreshRate | ForEach-Object { "$($_.CurrentRefreshRate) Hz" }) -join ', '
  Add-Item $g 'Refresh rate' $rate
} else {
  # trial 14 (26 Nov 2026): the agent runs this as SYSTEM, which sees no screens (the inventory read 1024 x 768 on
  # every NUC). So: each graphics card's current mode, the screens plugged in, and the display user's scaling.
  foreach ($v in @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Where-Object CurrentHorizontalResolution)) {
    Add-Item $g "$($v.Name) (its first screen)" "$($v.CurrentHorizontalResolution) x $($v.CurrentVerticalResolution), $($v.CurrentRefreshRate) Hz"
  }
  Add-Item $g 'Screens plugged in' (Try-Get { (@(Get-CimInstance -Namespace root\wmi WmiMonitorID -ErrorAction Stop | Where-Object Active | ForEach-Object {
    $n = -join [char[]]@($_.UserFriendlyName | Where-Object { $_ }); if ($n) { $n } else { 'unnamed' } }) -join '; ') })
  # AppliedDPI: the scaling Windows applied at sign-in to its main display (the support screen, where it is main)
  Add-Item $g "Scaling (Windows' main display, at sign-in)" (Try-Get {
    $sid = (New-Object Security.Principal.NTAccount($cs.UserName)).Translate([Security.Principal.SecurityIdentifier]).Value
    $dpi = (Get-ItemProperty "Registry::HKEY_USERS\$sid\Control Panel\Desktop\WindowMetrics" -Name AppliedDPI -ErrorAction Stop).AppliedDPI
    "$([math]::Round($dpi * 100 / 96))%"
  })
}

# ---- network
$g = New-Group 'Network'
Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object { $_.NetAdapter.Status -eq 'Up' } | ForEach-Object {
  Add-Item $g $_.InterfaceAlias "$(($_.IPv4Address | Select-Object -First 1).IPAddress), gateway $(($_.IPv4DefaultGateway | Select-Object -First 1).NextHop), MAC $($_.NetAdapter.MacAddress), $($_.NetAdapter.LinkSpeed)"
}
$ssid = (& netsh.exe wlan show interfaces 2>$null | Select-String -Pattern '^\s*SSID\s*:\s*(.+)$' | Select-Object -First 1)
if ($ssid) { Add-Item $g 'Wi-Fi network' $ssid.Matches[0].Groups[1].Value.Trim() }

# ---- Showcase set-up
$g = New-Group 'Showcase set-up'
# trial 14: AutoAdminLogon, or proof from the last start (common.ps1); it read Off on NUCs that sign in by themselves
Add-Item $g 'Auto-login' (Try-Get { (Get-AutoLoginState).now })
$hb = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -ErrorAction SilentlyContinue).HiberbootEnabled
Add-Item $g 'Fast Startup' $(if ($hb -eq 0) { 'Off' } else { 'ON: scheduled restarts may not complete (Dacre, Camberwell)' })
function Get-PowerAc($sub, $setting) {
  $out = & powercfg.exe /query SCHEME_CURRENT $sub $setting 2>$null
  $m = $out | Select-String -Pattern 'Current AC Power Setting Index:\s*0x([0-9a-fA-F]+)' | Select-Object -First 1
  if ($m) { [Convert]::ToInt32($m.Matches[0].Groups[1].Value, 16) }
}
$sleep = Get-PowerAc SUB_SLEEP STANDBYIDLE
$screen = Get-PowerAc SUB_VIDEO VIDEOIDLE
Add-Item $g 'Sleep' $(if ($sleep -eq 0) { 'Never' } elseif ($null -ne $sleep) { "After $([Math]::Round($sleep / 60)) minutes: Showcase stops" } else { '-' })
Add-Item $g 'Screen off' $(if ($screen -eq 0) { 'Never' } elseif ($null -ne $screen) { "After $([Math]::Round($screen / 60)) minutes" } else { '-' })
$chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
Add-Item $g 'Chrome' $(if ($chrome) { (Get-Item $chrome).VersionInfo.ProductVersion } else { 'Not found' })

# what opens Showcase at sign-in
$startup = @("$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp")
$prof = (Get-CimInstance Win32_UserProfile | Where-Object { $_.Loaded -and -not $_.Special -and $_.SID -like 'S-1-5-21-*' } | Select-Object -First 1).LocalPath
if ($prof) { $startup += "$prof\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" }
$items = @($startup | Where-Object { Test-Path $_ } | ForEach-Object { Get-ChildItem $_ -File | Where-Object Name -ne 'desktop.ini' | ForEach-Object Name })
Add-Item $g 'Startup folder' $(if ($items) { $items -join ', ' } else { 'Empty' })

# every Showcase scheduled task, Fleet Manager's own included
$tasks = @(Get-ScheduledTask -TaskName 'Showcase*', 'showcase_*' -ErrorAction SilentlyContinue)
Add-Item $g 'Showcase tasks' $(if ($tasks) { ($tasks | ForEach-Object { "$($_.TaskName) ($($_.State))" }) -join '; ' } else { 'None' })

# scheduled restarts, however they were set up (the daily restart is decided, but how it gets on a NUC is not documented)
$restarts = @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object {
  $_.State -ne 'Disabled' -and $_.TaskPath -notlike '\Microsoft\*' -and
  ($_.Actions | Where-Object { "$($_.Execute) $($_.Arguments)" -match 'shutdown(\.exe)?\s.*[/-]r\b|Restart-Computer' })
} | ForEach-Object {
  $t = $_.Triggers | Select-Object -First 1
  $when = if ($t.StartBoundary) { '{0:h:mm tt}' -f [datetime]$t.StartBoundary } else { '' }
  "$($_.TaskName) $when".Trim()
})
Add-Item $g 'Scheduled restarts' $(if ($restarts) { $restarts -join '; ' } else { 'None found' })

# ---- remote access and monitoring
$g = New-Group 'Remote access and monitoring'
Add-Item $g 'Chrome Remote Desktop' $(if (Get-Service chromoting -ErrorAction SilentlyContinue) { "Installed ($((Get-Service chromoting).Status))" } else { 'Not installed' })
Add-Item $g 'TeamViewer' $(if (Get-Service TeamViewer -ErrorAction SilentlyContinue) { "Installed ($((Get-Service TeamViewer).Status))" } else { 'Not installed' })
Add-Item $g 'NUC Monitor' $(if (Test-Path "$env:ProgramData\showcase-monitor") { 'Installed' } else { 'Not installed' })

Ok 'Read this NUC.'
Send-Json @{ at = (Get-Date).ToString('h:mm tt'); groups = $groups }
