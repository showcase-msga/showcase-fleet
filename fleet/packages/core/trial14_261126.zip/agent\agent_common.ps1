# Showcase Fleet agent: the parts shared by the agent and the installer (23 Nov 2026).
# Dot-source it:  . (Join-Path $PSScriptRoot 'agent_common.ps1')
#
# On a NUC:
#   C:\ProgramData\showcase_fleet\window\   what the Fleet window runs: app, tools, agent, modules\<id> (the agent keeps it current)
#   C:\ProgramData\showcase_fleet\agent\    token, pinned public key, state, log (SYSTEM and administrators only)
#   C:\ProgramData\showcase_fleet\store\    unpacked packages: the current and previous version of each, for rollback
# Trust: the API only says which version; the file and its sha256 come from the catalogue signed with Jordan's key,
# checked against the key pinned at install. Nothing unsigned, or with the wrong sha256, is ever unpacked.

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
. (Join-Path $PSScriptRoot 'agent_signing.ps1')
Add-Type -AssemblyName System.Security
Add-Type -AssemblyName System.IO.Compression.FileSystem

# SHOWCASE_FLEET_TEST_HOME points the agent at a test folder instead (Jordan's PC only, for proving it end to end
# without touching the Fleet install there); never set on a NUC
$FleetHome = if ($env:SHOWCASE_FLEET_TEST_HOME) { $env:SHOWCASE_FLEET_TEST_HOME } else { Join-Path $env:ProgramData 'showcase_fleet' }
$FleetTree = Join-Path $FleetHome 'window'
$AgentDir  = Join-Path $FleetHome 'agent'
$StoreDir  = Join-Path $FleetHome 'store'
$TokenFile = Join-Path $AgentDir 'token.dat'
$KeyFile   = Join-Path $AgentDir 'fleet_public_key.xml'
$StateFile = Join-Path $AgentDir 'state.json'
$AgentLog  = Join-Path $AgentDir 'agent.log'
$Utf8      = New-Object Text.UTF8Encoding $false

function Write-AgentLog([string]$m) {
  try {
    if (-not (Test-Path $AgentDir)) { return }
    Add-Content -Path $AgentLog -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m" -Encoding UTF8
    if ((Get-Item $AgentLog).Length -gt 1MB) { Get-Content $AgentLog -Tail 3000 | Set-Content "$AgentLog.tmp" -Encoding UTF8; Move-Item "$AgentLog.tmp" $AgentLog -Force }
  } catch { }
}

# the agent's own folder: SYSTEM and administrators only (the token and the pinned key live here)
function Initialize-AgentDir {
  foreach ($d in $FleetHome, $AgentDir, $StoreDir) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
  if ($env:SHOWCASE_FLEET_TEST_HOME) { return }   # a test run on Jordan's PC isn't elevated: leave the test folder open
  & icacls.exe $AgentDir /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' /Q | Out-Null
}

# one pass at a time (a 15-minute check-in never runs over the 1am install)
function Enter-AgentLock([int]$WaitSeconds = 600) {
  $script:AgentMutex = New-Object Threading.Mutex($false, 'Global\showcase_fleet_agent')
  try { return $script:AgentMutex.WaitOne([TimeSpan]::FromSeconds($WaitSeconds)) } catch [Threading.AbandonedMutexException] { return $true }
}
function Exit-AgentLock { try { $script:AgentMutex.ReleaseMutex() } catch { } }

# ---------------------------------------------------------------- identity

# the machine, not the Windows install alone: cloned NUCs share a MachineGuid, so the BIOS and board serials go in too
function Get-Fingerprint {
  $guid = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid -ErrorAction SilentlyContinue).MachineGuid
  $bios = (Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue).SerialNumber
  $board = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue).SerialNumber
  $sha = [Security.Cryptography.SHA256]::Create()
  try { -join ($sha.ComputeHash($Utf8.GetBytes("$guid|$bios|$board")) | ForEach-Object { $_.ToString('x2') }) } finally { $sha.Dispose() }
}

# trial 14 (26 Nov 2026): the NUC's serial number and network MACs, sent with every report as small fields of their
# own, for Roadie's per-unit records. The inventory is dropped whole when it's too big to keep; these never are.
# The installer has its own copy of this (it runs before Fleet's files are on the NUC): keep the two the same.
function Get-HardwareIds {
  $junk = '^(0*|none|default string|to be filled by o\.e\.m\.|system serial number|not specified|not applicable|n/a|123456789)$'
  $serial = "$((Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue).SerialNumber)".Trim()
  if ($serial -match $junk) { $serial = "$((Get-CimInstance Win32_ComputerSystemProduct -ErrorAction SilentlyContinue).IdentifyingNumber)".Trim() }
  if ($serial -match $junk) { $serial = '' }
  # the burned-in address (Windows can randomise a Wi-Fi adapter's current one); Bluetooth left out
  $macs = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { "$($_.PhysicalMediaType) $($_.InterfaceDescription)" -notmatch 'Bluetooth' } |
    Sort-Object ifIndex | ForEach-Object {
      [ordered]@{ name = "$($_.Name)"; mac = $(if ("$($_.PermanentAddress)" -match '^[0-9A-Fa-f]{12}$') { "$($_.PermanentAddress)" } else { "$($_.MacAddress)" })
                  wired = ("$($_.PhysicalMediaType)" -eq '802.3'); up = ("$($_.Status)" -eq 'Up') }
    })
  # the main MAC: the wired adapter (the one on the label, and Wake on LAN's), else the first
  $main = @(@($macs | Where-Object { $_.wired }) + $macs) | Select-Object -First 1
  @{ serial = $serial; mac = $(if ($main) { $main.mac } else { '' }); macs = @($macs | Select-Object -First 8) }
}

function Save-Token([string]$token) {
  $bytes = [Security.Cryptography.ProtectedData]::Protect($Utf8.GetBytes($token), $null, 'LocalMachine')
  [IO.File]::WriteAllBytes($TokenFile, $bytes)
}
function Get-Token {
  if (-not (Test-Path $TokenFile)) { throw 'This NUC is not enrolled (no token). Install it again with a new install link.' }
  $Utf8.GetString([Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($TokenFile), $null, 'LocalMachine'))
}

# ---------------------------------------------------------------- state

function Get-AgentState {
  if (Test-Path $StateFile) { try { return (Get-Content $StateFile -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { Write-AgentLog "state.json unreadable, starting fresh: $($_.Exception.Message)" } }
  [pscustomobject]@{}
}
function Save-AgentState($state) {
  [IO.File]::WriteAllText("$StateFile.tmp", ($state | ConvertTo-Json -Depth 12), $Utf8)
  Move-Item "$StateFile.tmp" $StateFile -Force
}
# sets a property on a state object whether or not it exists yet
function Set-Prop($obj, [string]$name, $value) {
  if ($obj.PSObject.Properties[$name]) { $obj.$name = $value } else { $obj | Add-Member -NotePropertyName $name -NotePropertyValue $value }
}
function Get-Prop($obj, [string]$name) { if ($obj -and $obj.PSObject.Properties[$name]) { $obj.$name } else { $null } }

# ---------------------------------------------------------------- the API

function Invoke-FleetApi([string]$Api, [string]$Op, $Body, [switch]$NoToken) {
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  $b = @{}; if ($Body) { foreach ($k in $Body.Keys) { $b[$k] = $Body[$k] } }
  $b.fingerprint = Get-Fingerprint
  $b.hostname = $env:COMPUTERNAME
  $headers = @{}
  if (-not $NoToken) { $headers.Authorization = "Bearer $(Get-Token)" }
  $json = $b | ConvertTo-Json -Depth 12 -Compress
  try {
    Invoke-RestMethod -Uri "$($Api.TrimEnd('/'))/v1/$Op" -Method Post -Headers $headers -ContentType 'application/json; charset=utf-8' `
      -Body $Utf8.GetBytes($json) -TimeoutSec 90 -UseBasicParsing
  } catch {
    $msg = $_.Exception.Message
    try { $e = $_.ErrorDetails.Message | ConvertFrom-Json; if ($e.error) { $msg = $e.error } } catch { }   # PowerShell 5.1 keeps the body here
    throw "Fleet $Op failed: $msg"
  }
}

# ---------------------------------------------------------------- the signed catalogue and packages

# reads the signed catalogue; refuses a bad signature or an older one than already seen. If it says the API or the
# package address has moved, the state follows (this is how Fleet moves hosts without touching any NUC).
function Get-Catalogue($state) {
  $key = Get-FleetPublicKey $KeyFile
  $url = Get-Prop $state 'catalogueUrl'
  if (-not $url) { throw 'No catalogue address in state.json. Install this NUC again.' }
  $seen = [long](Get-Prop $state 'catalogueSeq')
  $cat = Read-FleetSignedJson $url $key $seen
  Set-Prop $state 'catalogueSeq' ([long]$cat.sequence)
  if ($cat.api -and $cat.api -ne (Get-Prop $state 'api')) { Write-AgentLog "API address now $($cat.api)"; Set-Prop $state 'api' $cat.api }
  if ($cat.packagesBase) {
    $next = "$($cat.packagesBase.TrimEnd('/'))/catalogue.json"
    if ($next -ne $url) { Write-AgentLog "Catalogue address now $next"; Set-Prop $state 'catalogueUrl' $next }
  }
  $cat
}

# a package's folder in the store, downloaded and checked against the signed catalogue if it isn't there already
function Get-Package($cat, [string]$Name, [string]$Version) {
  $p = Get-Prop $cat.packages $Name
  $e = Get-Prop $p $Version
  if (-not $e) { throw "$Name $Version is not in the signed catalogue." }
  if ($Version -notmatch '^[A-Za-z0-9_.-]{1,40}$') { throw "Bad version name: $Version" }
  $dir = Join-Path $StoreDir "$Name\$Version"
  $mark = Join-Path $dir '.sha256'
  if ((Test-Path $mark) -and ((Get-Content $mark -Raw).Trim() -eq $e.sha256)) { return $dir }

  $tmp = Join-Path $StoreDir "_download_$Name.zip"
  Save-FleetFile "$($cat.packagesBase.TrimEnd('/'))/$($e.path)" $tmp
  if (-not (Test-FleetFileHash $tmp $e.sha256)) { Remove-Item $tmp -Force -ErrorAction SilentlyContinue; throw "$Name $Version failed its sha256 check: not installed." }
  if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  [IO.Compression.ZipFile]::ExtractToDirectory($tmp, $dir)
  Remove-Item $tmp -Force
  $bad = @(Get-FleetScriptErrors $dir)
  if ($bad.Count) { Remove-Item $dir -Recurse -Force; throw "$Name $Version has scripts that don't parse: $($bad[0])" }
  Set-Content $mark $e.sha256 -Encoding ASCII
  Write-AgentLog "Downloaded and checked $Name $Version"
  $dir
}

# keeps only the versions still needed (current and previous) of one package
function Limit-Store([string]$Name, [string[]]$Keep) {
  $d = Join-Path $StoreDir $Name
  if (-not (Test-Path $d)) { return }
  Get-ChildItem $d -Directory | Where-Object { $Keep -notcontains $_.Name } | ForEach-Object { Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
}

# copies a package into the tree the window runs, replacing what was there (robocopy /MIR: removed files go too)
function Copy-IntoTree([string]$From, [string]$To, [string[]]$KeepDirs = @()) {
  New-Item -ItemType Directory -Force -Path $To | Out-Null
  $xd = @($KeepDirs | ForEach-Object { '/XD'; (Join-Path $To $_) })
  & robocopy.exe $From $To /MIR /IS /IT /XF .sha256 @xd /NFL /NDL /NJH /NJS /NP /R:2 /W:2 | Out-Null
  if ($LASTEXITCODE -ge 8) { throw "Copy into $To failed (robocopy $LASTEXITCODE)." }
  # robocopy skips a file whose size and time match even when its contents differ (two versions built a second apart,
  # proved on JC-Desktop 23 Nov 2026), so every file is checked by its hash and any that differ are copied again
  $root = (Resolve-Path $From).Path.TrimEnd('\')
  foreach ($f in Get-ChildItem $root -Recurse -File | Where-Object { $_.Name -ne '.sha256' }) {
    $dst = Join-Path $To $f.FullName.Substring($root.Length).TrimStart('\')
    if (-not (Test-Path -LiteralPath $dst) -or (Get-FileHash -LiteralPath $f.FullName).Hash -ne (Get-FileHash -LiteralPath $dst).Hash) {
      New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
      Copy-Item -LiteralPath $f.FullName -Destination $dst -Force
    }
  }
}

# ---------------------------------------------------------------- running a module's own scripts

# runs one of a module's scripts in its own PowerShell, as the Fleet window does, with a time limit; returns
# @{ ok; output } where ok means it finished and printed no [FAIL] line
function Invoke-ModuleScript([string]$File, [hashtable]$Params = @{}, [int]$TimeoutSeconds = 900) {
  $job = Start-Job -ScriptBlock {
    param($File, $Params)
    Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
    $ProgressPreference = 'SilentlyContinue'
    try { & $File @Params *>&1 | ForEach-Object { if ($_ -is [System.Management.Automation.ErrorRecord]) { "[FAIL] $($_.Exception.Message)" } else { "$_" } } }
    catch { "[FAIL] $($_.Exception.Message)" }
  } -ArgumentList $File, $Params
  $done = Wait-Job $job -Timeout $TimeoutSeconds
  $lines = @(Receive-Job $job -ErrorAction SilentlyContinue | ForEach-Object { "$_" })
  if (-not $done) { Stop-Job $job; $lines += "[FAIL] Still running after $TimeoutSeconds seconds; stopped." }
  Remove-Job $job -Force -ErrorAction SilentlyContinue
  @{ ok = -not ($lines | Where-Object { $_ -like '[[]FAIL]*' }); output = ($lines -join "`n") }
}

# a module's status.ps1 (read-only): installed, version, problem, detail
function Get-ModuleStatus([string]$Id) {
  $f = Join-Path $FleetTree "modules\$Id\status.ps1"
  if (-not (Test-Path $f)) { return @{ installed = $false; detail = 'No status script.' } }
  $job = Start-Job -ScriptBlock { param($f) Set-ExecutionPolicy -Scope Process Bypass -Force; & $f | ConvertTo-Json -Depth 5 -Compress } -ArgumentList $f
  $ok = Wait-Job $job -Timeout 60
  $out = if ($ok) { "$(Receive-Job $job -ErrorAction SilentlyContinue | Select-Object -Last 1)" } else { '' }
  Remove-Job $job -Force -ErrorAction SilentlyContinue
  if (-not $out) { return @{ installed = $false; problem = $true; detail = 'The status check did not answer.' } }
  try { $s = $out | ConvertFrom-Json } catch { return @{ installed = $false; problem = $true; detail = 'The status check returned something unreadable.' } }
  @{ installed = [bool]$s.installed; version = "$($s.version)"; problem = [bool]$s.problem; detail = "$($s.detail)" }
}

function Get-ModuleDef([string]$Id) {
  $f = Join-Path $FleetTree "modules\$Id\module.json"
  if (-not (Test-Path $f)) { return $null }
  Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json
}

# only the settings a module declares are passed on to its script (same rule as the Fleet window)
function ConvertTo-ModuleParams($def, $given) {
  $h = @{}
  if (-not $given) { return $h }
  foreach ($d in @($def.settings)) {
    if (-not $d) { continue }
    $v = Get-Prop $given $d.key
    if ($null -ne $v -and "$v" -ne '') { $h[$d.key] = $v }
  }
  $h
}
