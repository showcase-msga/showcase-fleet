# Showcase Fleet agent (23 Nov 2026; trial 14, 26 Nov 2026: every report carries the serial number and MACs).
# Runs as SYSTEM from three scheduled tasks, silent throughout:
#   -Mode checkin   every 15 minutes (and at start-up): report in, get what this NUC should run, run console commands
#   -Mode install   1:00 am (+ up to 30 min): install, update or remove modules as the dashboard says
#   -Mode check     2:00 am: each module changed last night checks itself; on a failure retry, then roll back
#   -Mode setup     at install (and when the timetable changes): register the three tasks
# Times come from the API (Overnight Timetable.md). Nothing runs on a paused level or a held NUC, nothing unsigned is
# ever installed (agent_common.ps1), and a module installed by hand before Fleet enrolled is never removed by it.
param([ValidateSet('checkin', 'install', 'check', 'setup')][string]$Mode = 'checkin')
. (Join-Path $PSScriptRoot 'agent_common.ps1')
. (Join-Path $PSScriptRoot '..\app\common.ps1')   # Get-NucConfig / Save-NucConfig
$ErrorActionPreference = 'Stop'
$CoreVersion = "$(Get-Content (Join-Path $PSScriptRoot '..\app\version.txt') -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
$script:InInstall = $false

# ---------------------------------------------------------------- tasks

$Tasks = @{
  checkin = 'showcase_fleet_agent_checkin'
  install = 'showcase_fleet_agent_install'
  check   = 'showcase_fleet_agent_check'
}

function Register-AgentTasks($nightly) {
  $installAt = if ($nightly -and $nightly.install) { "$($nightly.install)" } else { '01:00' }
  $checkAt   = if ($nightly -and $nightly.check) { "$($nightly.check)" } else { '02:00' }
  if ($env:SHOWCASE_FLEET_TEST_HOME) { Write-AgentLog "Test run: tasks not registered ($installAt, $checkAt)"; return "$installAt|$checkAt" }
  $ps = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
  $file = Join-Path $FleetTree 'agent\fleet_agent.ps1'
  $principal = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $act = { param($m) New-ScheduledTaskAction -Execute $ps -Argument "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$file`" -Mode $m" }

  # check-in: every 15 minutes, and 2 minutes after start-up; a missed one may run late (it changes nothing)
  $t1 = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 15)
  $t2 = New-ScheduledTaskTrigger -AtStartup; $t2.Delay = 'PT2M'
  $s = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 30)
  Register-ScheduledTask -TaskName $Tasks.checkin -TaskPath '\' -Action (& $act 'checkin') -Trigger @($t1, $t2) -Principal $principal -Settings $s `
    -Description 'Showcase Fleet: report to the dashboard and get changes, every 15 minutes.' -Force | Out-Null

  # the nightly passes: local time with no offset (daylight saving can't move them), and never late: a NUC that was
  # off at 1am must not install at 9am in opening hours
  foreach ($p in @(@{ m = 'install'; at = $installAt; desc = 'install, update or remove modules'; limit = 120; delay = 'PT30M' },
                   @{ m = 'check'; at = $checkAt; desc = 'check last night''s changes, retry or roll back'; limit = 90; delay = $null })) {
    $t = New-ScheduledTaskTrigger -Daily -At $p.at
    $t.StartBoundary = (Get-Date $p.at).ToString('yyyy-MM-ddTHH:mm:ss')
    if ($p.delay) { $t.RandomDelay = $p.delay }
    $s = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes $p.limit)
    Register-ScheduledTask -TaskName $Tasks[$p.m] -TaskPath '\' -Action (& $act $p.m) -Trigger $t -Principal $principal -Settings $s `
      -Description "Showcase Fleet: $($p.desc), at $($p.at)." -Force | Out-Null
  }
  Write-AgentLog "Tasks registered: check-in every 15 min, install $installAt, check $checkAt"
  "$installAt|$checkAt"
}

# ---------------------------------------------------------------- what's on this NUC now

# every module's status.ps1, in one background PowerShell (quick enough for every check-in)
function Get-AllModuleStatus {
  $dirs = @(Get-ChildItem (Join-Path $FleetTree 'modules') -Directory -ErrorAction SilentlyContinue | Where-Object { Test-Path (Join-Path $_.FullName 'status.ps1') } | ForEach-Object { $_.FullName })
  if (-not $dirs.Count) { return @{} }
  $job = Start-Job -ScriptBlock {
    param($list)
    Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
    $o = @{}
    foreach ($d in $list) {
      $id = Split-Path $d -Leaf
      try {
        $s = @(& (Join-Path $d 'status.ps1') 2>$null) | Where-Object { $_ -is [hashtable] } | Select-Object -Last 1
        $o[$id] = if ($s) { $s } else { @{ installed = $false } }
      } catch { $o[$id] = @{ installed = $false; problem = $true; detail = "Status check failed: $($_.Exception.Message)" } }
    }
    $o | ConvertTo-Json -Depth 5 -Compress
  } -ArgumentList (, $dirs)
  $ok = Wait-Job $job -Timeout 180
  $out = if ($ok) { "$(Receive-Job $job -ErrorAction SilentlyContinue | Select-Object -Last 1)" } else { '' }
  Remove-Job $job -Force -ErrorAction SilentlyContinue
  $h = @{}
  if ($out) { try { $j = $out | ConvertFrom-Json; foreach ($p in $j.PSObject.Properties) { $h[$p.Name] = $p.Value } } catch { } }
  $h
}

function Get-Installed($state) {
  $i = Get-Prop $state 'installed'
  if (-not $i) { $i = [pscustomobject]@{ modules = [pscustomobject]@{} }; Set-Prop $state 'installed' $i }
  if (-not (Get-Prop $i 'modules')) { Set-Prop $i 'modules' ([pscustomobject]@{}) }
  $i
}

function Get-Report($state) {
  $st = Get-AllModuleStatus
  $inst = (Get-Installed $state).modules
  $modules = @{}; $problems = @()
  foreach ($id in $st.Keys) {
    $s = $st[$id]
    $mine = Get-Prop $inst $id
    if (-not $s.installed -and -not $mine) { continue }
    $status = if (-not $s.installed) { 'not installed' } elseif ($s.problem) { 'problem' } else { 'ok' }
    $ver = if ($mine) { "$($mine.version)" } else { "$($s.version)" }
    $modules[$id] = @{ version = $ver; status = $status; detail = "$($s.detail)" }
    if ($s.problem) { $problems += "$id`: $($s.detail)" }
    if ($mine -and -not $s.installed) { $problems += "$id should be installed but isn't." }
  }
  $os = Get-CimInstance Win32_OperatingSystem
  $r = @{
    fleetVersion = $CoreVersion
    modules = $modules
    problems = @($problems)
    lastNight = (Get-Prop $state 'lastNight')
    windows = "$($os.Caption) $($os.BuildNumber)"
    uptimeHours = [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalHours, 1)
  }
  # trial 14: serial number and MACs, small fields of their own (agent_common.ps1); never holds up the report
  try { $hw = Get-HardwareIds; foreach ($k in $hw.Keys) { $r[$k] = $hw[$k] } } catch { Write-AgentLog "Serial and MACs: $($_.Exception.Message)" }
  $r
}

function Get-Inventory {
  $r = Invoke-ModuleScript (Join-Path $FleetTree 'agent\inventory.ps1') @{} 180
  $line = ($r.output -split "`n") | Where-Object { $_ -like '@@JSON *' } | Select-Object -Last 1
  if (-not $line) { throw "The inventory didn't come back: $($r.output)" }
  $line.Substring(7) | ConvertFrom-Json
}

# ---------------------------------------------------------------- check-in

function Invoke-Checkin($state) {
  $body = Get-Report $state
  $invAt = Get-Prop $state 'inventoryAt'
  $sendInv = -not $invAt -or ((Get-Date) - [datetime]$invAt).TotalHours -ge 24
  if ($sendInv) { try { $body.inventory = Get-Inventory } catch { Write-AgentLog "Inventory: $($_.Exception.Message)"; $sendInv = $false } }

  $r = Invoke-FleetApi $state.api 'checkin' $body
  if ($sendInv) { Set-Prop $state 'inventoryAt' (Get-Date).ToString('s') }
  foreach ($k in 'nuc', 'nucId', 'level', 'hold', 'paused', 'desired', 'nightly') { Set-Prop $state $k $r.$k }
  Set-Prop $state 'lastCheckin' (Get-Date).ToString('s')

  # the Showcase URL lives in nuc.config, which the launchers read; it's applied when the launcher next installs
  $c = Get-NucConfig
  $dirty = $false
  if ($r.nucId -and $c.NucId -ne $r.nucId) { $c.NucId = $r.nucId; $dirty = $true }
  if ($r.showcaseUrl -and $c.ShowcaseUrl -ne $r.showcaseUrl) { $c.ShowcaseUrl = $r.showcaseUrl; $dirty = $true; Write-AgentLog 'Showcase URL updated from the dashboard.' }
  if ($dirty) { Save-NucConfig $c }

  # the timetable comes from the API: re-register the nightly tasks if it changed
  $times = "$($r.nightly.install)|$($r.nightly.check)"
  if ($r.nightly -and $times -ne (Get-Prop $state 'nightlyRegistered')) {
    try { Set-Prop $state 'nightlyRegistered' (Register-AgentTasks $r.nightly) } catch { Write-AgentLog "Re-registering the nightly tasks: $($_.Exception.Message)" }
  }
  Save-AgentState $state

  foreach ($c in @($r.commands)) { if ($c) { Invoke-FleetCommand $state $c } }
}

# ---------------------------------------------------------------- the 1am install pass

function Get-SettingsHash($settings) {
  $pairs = @(); if ($settings) { foreach ($p in ($settings.PSObject.Properties | Sort-Object Name)) { $pairs += "$($p.Name)=$(@($p.Value) -join ',')" } }
  $sha = [Security.Cryptography.SHA256]::Create()
  try { -join ($sha.ComputeHash($Utf8.GetBytes(($pairs -join ';'))) | ForEach-Object { $_.ToString('x2') }) } finally { $sha.Dispose() }
}

# installs (or reinstalls with new settings) a module already copied into the tree
function Install-ModuleNow([string]$Id, $Settings) {
  $def = Get-ModuleDef $Id
  if (-not $def) { throw "$Id has no module.json." }
  $dir = Join-Path $FleetTree "modules\$Id"
  if ($def.kind -eq 'settings') { return Invoke-ModuleScript (Join-Path $dir $def.settingsScript) @{ $def.applyParam = 'all' } }
  Invoke-ModuleScript (Join-Path $dir 'install.ps1') (ConvertTo-ModuleParams $def $Settings)
}

# -Force (the console's Apply changes now) also retries a version that was rolled back; the nightly pass doesn't, so a
# bad version isn't installed and rolled back again every night until a newer one is published
function Invoke-InstallPass($state, [string]$Why, [switch]$Force) {
  $script:InInstall = $true
  try { Invoke-InstallPassInner $state $Why -Force:$Force } finally { $script:InInstall = $false }
}

function Invoke-InstallPassInner($state, [string]$Why, [switch]$Force) {
  try { Invoke-Checkin $state } catch { Write-AgentLog "Check-in before installing: $($_.Exception.Message) (using the last answer)" }
  $d = Get-Prop $state 'desired'
  if (-not $d) { Write-AgentLog 'Nothing to install: no answer from the dashboard yet.'; return @() }
  if ($state.hold -or $state.paused) {
    $why2 = if ($state.hold) { 'this NUC is held' } else { 'its level is paused' }
    Write-AgentLog "Install pass skipped: $why2."
    Set-Prop $state 'lastNight' @{ at = (Get-Date).ToString('s'); result = 'skipped'; detail = $why2 }
    Save-AgentState $state; return @()
  }
  Write-AgentLog "Install pass ($Why)"
  $cat = Get-Catalogue $state
  $inst = Get-Installed $state
  $changed = @(); $notes = @()

  # Fleet core (the window, tools and this agent); modules\ is left alone
  if ($d.core -and $d.core -ne $CoreVersion) {
    try {
      $dir = Get-Package $cat 'core' $d.core
      Copy-IntoTree $dir $FleetTree @('modules')
      Set-Prop $inst 'core' @{ version = $d.core; previous = $CoreVersion; at = (Get-Date).ToString('s') }
      $changed += 'core'; $notes += "Fleet $CoreVersion to $($d.core)"
      Write-AgentLog "Fleet core $CoreVersion to $($d.core)"
    } catch { $notes += "Fleet core: $($_.Exception.Message)"; Write-AgentLog "Core: $($_.Exception.Message)" }
  }

  foreach ($p in $d.modules.PSObject.Properties) {
    $id = $p.Name; $want = $p.Value; $mine = Get-Prop $inst.modules $id
    if ($id -notmatch '^[a-z0-9_]{1,60}$') { continue }
    if ($want.on) {
      if (-not $want.version) { $notes += "$id is ticked, but its level has no version of it."; continue }
      $hash = Get-SettingsHash $want.settings
      if ($mine -and $mine.version -eq $want.version -and $mine.settingsHash -eq $hash) { continue }
      if ($mine -and (Get-Prop $mine 'rolledBackFrom') -eq $want.version -and -not $Force) {
        $notes += "$id $($want.version) failed its check and was rolled back; not tried again until a newer version, or Apply changes now."
        continue
      }
      try {
        $pkg = Get-Package $cat $id $want.version
        $prev = if ($mine -and $mine.version -ne $want.version) { $mine.version } elseif ($mine) { $mine.previous } else { $null }
        Copy-IntoTree $pkg (Join-Path $FleetTree "modules\$id")
        $r = Install-ModuleNow $id $want.settings
        Set-Prop $inst.modules $id @{ version = $want.version; settingsHash = $hash; previous = $prev; at = (Get-Date).ToString('s') }
        $changed += $id
        $notes += "$id $($want.version) installed$(if (-not $r.ok) { ' with warnings' })"
        Write-AgentLog "Installed $id $($want.version)`n$($r.output)"
      } catch { $notes += "$id`: $($_.Exception.Message)"; Write-AgentLog "Install $id`: $($_.Exception.Message)" }
    } elseif ($mine) {
      # unticked, and Fleet put it there: take it off (a module installed by hand before enrolment is left alone)
      $rm = Join-Path $FleetTree "modules\$id\remove.ps1"
      if (Test-Path $rm) {
        $r = Invoke-ModuleScript $rm @{}
        Write-AgentLog "Removed $id`n$($r.output)"
        $notes += "$id removed$(if (-not $r.ok) { ' with warnings' })"
      } else { $notes += "$id unticked; it has no remove step, so its settings stay." }
      $inst.modules.PSObject.Properties.Remove($id)
      $changed += $id
    }
  }
  Set-Prop $state 'pendingCheck' @($changed | Where-Object { $_ -ne 'core' -and (Get-Prop $inst.modules $_) })
  Set-Prop $state 'lastInstall' @{ at = (Get-Date).ToString('s'); why = $Why; notes = @($notes) }
  Save-AgentState $state
  $notes
}

# ---------------------------------------------------------------- the 2am check pass

function Test-ModuleHealthy([string]$Id) {
  $def = Get-ModuleDef $Id
  if (-not $def) { return @{ ok = $false; detail = 'Its files are missing.' } }
  if ($def.kind -eq 'settings') {
    # Baseline-style: a fresh check, then every setting Fleet can set must be as recommended (hand-set ones aside)
    Invoke-ModuleScript (Join-Path $FleetTree "modules\$Id\$($def.settingsScript)") @{} 300 | Out-Null
    $f = Join-Path $FleetHome "$Id\last_check.json"
    try { $c = Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json } catch { return @{ ok = $false; detail = 'Its check left no result.' } }
    # trial 13: only critical settings fail the module (a check from before trial 13 has no 'critical': all count).
    # A non-critical one that isn't right (Baseline's adapters, which some drivers won't take) is a warning, and the
    # rest of the module stands: one stubborn setting must never hold back the daily restart and the others.
    $off  = @($c.settings | Where-Object { $_.canApply -and -not $_.ok })
    $hard = @($off | Where-Object { $null -eq $_.critical -or $_.critical } | ForEach-Object { $_.name })
    $soft = @($off | Where-Object { $_.critical -eq $false } | ForEach-Object { $_.name })
    return @{ ok = ($hard.Count -eq 0)
              detail = $(if ($hard.Count) { "Not as recommended: $($hard -join ', ')" } elseif ($soft.Count) { "the rest as recommended; not taken on this NUC: $($soft -join ', ')" } else { 'As recommended.' }) }
  }
  $all = Get-AllModuleStatus
  $s = $all[$Id]
  if (-not $s) { return @{ ok = $false; detail = 'No status.' } }
  $verOk = (-not "$($s.version)") -or "$($s.version)" -in @('?', 'standalone') -or "$($def.version)" -like "*$($s.version)"
  @{ ok = ([bool]$s.installed -and -not [bool]$s.problem -and $verOk); detail = "$($s.detail)$(if (-not $verOk) { " (reports version $($s.version), expected $($def.version))" })" }
}

function Invoke-CheckPass($state) {
  $inst = Get-Installed $state
  $ids = @(Get-Prop $state 'pendingCheck' | Where-Object { $_ })
  if (-not $ids.Count) { Write-AgentLog 'Check pass: nothing changed last night.'; return @() }
  $results = @(); $worst = 'ok'
  foreach ($id in $ids) {
    $mine = Get-Prop $inst.modules $id
    $t = Test-ModuleHealthy $id
    if (-not $t.ok) {
      Write-AgentLog "Check $id failed ($($t.detail)); trying once more."
      try { Install-ModuleNow $id (Get-Prop (Get-Prop $state.desired.modules $id) 'settings') | Out-Null } catch { }
      $t = Test-ModuleHealthy $id
    }
    if ($t.ok) { $results += "$id OK$(if ($t.detail -like 'the rest*') { " ($($t.detail))" })"; continue }
    # trial 13: a settings module (Baseline) is never rolled back. Its settings stay as set whichever version is on, so
    # going back only re-applies the older version's way of setting them (trial 11's adapter step switched Wake on LAN off).
    $def = Get-ModuleDef $id
    if ($def -and $def.kind -eq 'settings') {
      $results += "$id $($mine.version) failed its check ($($t.detail)); its other settings stay as set (settings modules aren't rolled back)"
      $worst = 'failed'; continue
    }
    # still failing: back to the last good version, before the suite opens
    $prev = if ($mine) { $mine.previous } else { $null }
    $prevDir = if ($prev) { Join-Path $StoreDir "$id\$prev" } else { $null }
    if ($prevDir -and (Test-Path $prevDir)) {
      try {
        Copy-IntoTree $prevDir (Join-Path $FleetTree "modules\$id")
        Install-ModuleNow $id (Get-Prop (Get-Prop $state.desired.modules $id) 'settings') | Out-Null
        Set-Prop $inst.modules $id @{ version = $prev; settingsHash = ''; previous = $null; at = (Get-Date).ToString('s'); rolledBackFrom = $mine.version }
        $results += "$id $($mine.version) failed its check ($($t.detail)); rolled back to $prev"
        if ($worst -eq 'ok') { $worst = 'rolled back' }
        Write-AgentLog "Rolled back $id to $prev"
      } catch { $results += "$id failed and the roll-back failed too: $($_.Exception.Message)"; $worst = 'failed' }
    } else { $results += "$id failed its check ($($t.detail)), and there's no earlier version to go back to"; $worst = 'failed' }
  }
  Set-Prop $state 'lastNight' @{ at = (Get-Date).ToString('s'); result = $worst; detail = ($results -join '. ') }
  Set-Prop $state 'pendingCheck' @()
  foreach ($p in $inst.modules.PSObject.Properties) { Limit-Store $p.Name @("$($p.Value.version)", "$($p.Value.previous)") }
  Save-AgentState $state
  $results
}

# ---------------------------------------------------------------- console commands (a fixed list)

function Send-Result($state, $c, [bool]$ok, [string]$output, $inventory = $null) {
  $b = @{ id = $c.id; ok = $ok; output = $(if ($output.Length -gt 38000) { $output.Substring($output.Length - 38000) } else { $output }) }
  if ($inventory) { $b.inventory = $inventory }
  try { Invoke-FleetApi $state.api 'result' $b | Out-Null } catch { Write-AgentLog "Result for $($c.type): $($_.Exception.Message)" }
}

function Invoke-FleetCommand($state, $c) {
  Write-AgentLog "Command $($c.type) $(($c.args | ConvertTo-Json -Compress))"
  try {
    switch ($c.type) {
      'restart_chrome' {
        $launcher = @('startup_kiosk', 'showcase_startup_bat') | Where-Object { (Get-AllModuleStatus)[$_].installed } | Select-Object -First 1
        if (-not $launcher) { Send-Result $state $c $false 'No Fleet launcher on this NUC, so Fleet does not know how to reopen Showcase here.'; return }
        $r = Invoke-ModuleScript (Join-Path $FleetTree "modules\$launcher\restart.ps1") @{} 120
        Send-Result $state $c $r.ok $r.output
      }
      'restart_nuc' {
        Send-Result $state $c $true 'Restarting now.'
        Write-AgentLog 'Restarting (console).'
        & "$env:SystemRoot\System32\shutdown.exe" /r /f /t 5 /d p:0:0
      }
      'apply_now' {
        if ($script:InInstall) { Send-Result $state $c $true 'Already installing.'; return }
        $notes = Invoke-InstallPass $state 'Apply now, from the console' -Force
        $checks = Invoke-CheckPass $state
        Send-Result $state $c $true ((@($notes) + @($checks)) -join "`n")
      }
      'send_inventory' {
        $inv = Get-Inventory
        Set-Prop $state 'inventoryAt' (Get-Date).ToString('s'); Save-AgentState $state
        Send-Result $state $c $true 'Sent.' $inv
      }
      'send_log' {
        $def = Get-ModuleDef "$($c.args.module)"
        if (-not $def -or -not $def.log) { Send-Result $state $c $false 'That module keeps no log on this NUC.'; return }
        $f = Join-Path $env:ProgramData $def.log
        if (-not (Test-Path $f)) { Send-Result $state $c $false "No log yet at $f."; return }
        Send-Result $state $c $true ((Get-Content $f -Tail 400 -ErrorAction Stop) -join "`n")
      }
      'action' {
        $def = Get-ModuleDef "$($c.args.module)"
        $a = if ($def) { @($def.actions) | Where-Object { $_ -and $_.id -eq "$($c.args.action)" } | Select-Object -First 1 } else { $null }
        if (-not $a) { Send-Result $state $c $false 'That module or action is not on this NUC.'; return }
        $r = Invoke-ModuleScript (Join-Path $FleetTree "modules\$($def.id)\$($a.script)") @{} 600
        Send-Result $state $c $r.ok $r.output
      }
      default { Send-Result $state $c $false "Not a command this NUC knows: $($c.type)." }
    }
  } catch { Send-Result $state $c $false $_.Exception.Message }
}

# ---------------------------------------------------------------- main

Initialize-AgentDir
$wait = if ($Mode -eq 'checkin') { 60 } else { 1800 }
if (-not (Enter-AgentLock $wait)) { Write-AgentLog "Another Fleet pass is running; $Mode skipped."; return }
try {
  $state = Get-AgentState
  switch ($Mode) {
    'setup'   { Set-Prop $state 'nightlyRegistered' (Register-AgentTasks (Get-Prop $state 'nightly')); Save-AgentState $state }
    'checkin' { Invoke-Checkin $state }
    'install' { Invoke-InstallPass $state 'nightly' | Out-Null; try { Invoke-Checkin $state } catch { } }
    'check'   { Invoke-CheckPass $state | Out-Null; try { Invoke-Checkin $state } catch { } }
  }
} catch {
  Write-AgentLog "[$Mode] $($_.Exception.Message)"
  throw
} finally { Exit-AgentLock }
