# Showcase Fleet Manager: trust checks for the agent (221026)
# Dot-source it:  . (Join-Path $PSScriptRoot 'agent_signing.ps1')
#
# Everything the agent acts on comes with a detached signature: <file>.sig holds base64 of an
# RSA-SHA256 (PKCS#1 v1.5) signature over the file's exact bytes. The public key sits next to the
# agent as fleet_public_key.xml, put there at enrolment; the private key never leaves Jordan's PC.
# A bundle zip is trusted through its sha256, which is inside a signed channel file.
# Windows PowerShell 5.1 and .NET Framework 4.6.2 or later (every Windows 10/11 NUC has 4.8).

$FleetSigningVersion = '221026'

function Get-FleetPublicKey([string]$Path = (Join-Path $PSScriptRoot 'fleet_public_key.xml')) {
  if (-not (Test-Path $Path)) { throw "No public key at $Path. Re-run the enrol command." }
  $xml = [IO.File]::ReadAllText($Path)
  if ($xml -notmatch '<Modulus>' -or $xml -match '<D>') { throw "The key at $Path is not a public key." }
  $xml
}

# true only when $SignatureBase64 is a valid signature of $Bytes by the holder of the private key
function Test-FleetSignature([byte[]]$Bytes, [string]$SignatureBase64, [string]$PublicKeyXml) {
  if (-not $Bytes -or -not $SignatureBase64 -or -not $PublicKeyXml) { return $false }
  try { $sig = [Convert]::FromBase64String($SignatureBase64.Trim()) } catch { return $false }
  $rsa = New-Object System.Security.Cryptography.RSACng
  try {
    $rsa.FromXmlString($PublicKeyXml)
    $rsa.VerifyData($Bytes, $sig, [System.Security.Cryptography.HashAlgorithmName]::SHA256,
      [System.Security.Cryptography.RSASignaturePadding]::Pkcs1)
  } catch { $false } finally { $rsa.Dispose() }
}

# exact bytes from a URL or a local path; no caching, TLS 1.2
function Get-FleetBytes([string]$Source) {
  if ($Source -match '^https?://') {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $wc = New-Object System.Net.WebClient
    $wc.Headers['Cache-Control'] = 'no-cache'
    try { return , $wc.DownloadData($Source) } finally { $wc.Dispose() }
  }
  , [IO.File]::ReadAllBytes($Source)
}

function Save-FleetFile([string]$Source, [string]$Destination) {
  $bytes = Get-FleetBytes $Source
  [IO.File]::WriteAllBytes($Destination, $bytes)
}

# Reads a signed JSON file. Refuses a bad signature, and a sequence below $MinSequence (an older
# file served again). The same sequence is fine: that is the file it already has.
function Read-FleetSignedJson([string]$Source, [string]$PublicKeyXml, [long]$MinSequence = 0) {
  $bytes = Get-FleetBytes $Source
  $sigText = [Text.Encoding]::ASCII.GetString((Get-FleetBytes "$Source.sig"))
  if (-not (Test-FleetSignature $bytes $sigText $PublicKeyXml)) { throw "Signature check failed: $Source" }
  $text = [Text.Encoding]::UTF8.GetString($bytes).TrimStart([char]0xFEFF)
  $obj = $text | ConvertFrom-Json
  if ($null -eq $obj.sequence) { throw "No sequence number in $Source" }
  if ([long]$obj.sequence -lt $MinSequence) { throw "Older file refused: $Source is sequence $($obj.sequence), already seen $MinSequence" }
  $obj
}

function Get-FleetSha256([string]$Path) {
  (Get-FileHash -Path $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Test-FleetFileHash([string]$Path, [string]$Sha256) {
  (Test-Path $Path) -and $Sha256 -and ((Get-FleetSha256 $Path) -eq $Sha256.ToLowerInvariant())
}

# every .ps1 under $Folder parses; returns the files that do not
function Get-FleetScriptErrors([string]$Folder) {
  @(Get-ChildItem $Folder -Recurse -Filter *.ps1 -File | ForEach-Object {
    $tokens = $null; $errors = $null
    [System.Management.Automation.Language.Parser]::ParseFile($_.FullName, [ref]$tokens, [ref]$errors) | Out-Null
    if ($errors) { "$($_.FullName): $($errors[0].Message)" }
  })
}
