# Showcase Fleet trial 7 (24 Oct 2026): puts the Fleet window on this NUC like a program.
# Runs by itself when the window opens as admin from a copied folder (Jordan, 24 Oct: "Add to this
# NUC should be default"). Copies Fleet to C:\ProgramData\showcase_fleet\window, lets only SYSTEM and
# Administrators change it (everyone else can read and run it), and adds a "Showcase Fleet" shortcut
# to the Public desktop and the Start menu. Nothing shows on the display: the desktop sits behind Showcase.
# Trial 7: Fleet's whole ProgramData folder is locked the same way, and Fleet is pinned to the taskbar.
param([string]$Source = (Split-Path $PSScriptRoot -Parent))
. (Join-Path $PSScriptRoot 'common.ps1')

$Version = "$(Get-Content (Join-Path $Source 'app\version.txt') -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
$Dest    = Join-Path $FleetData 'window'
$Bat     = "showcase_fleet_manager_$Version.bat"
$LogFile = Join-Path $FleetData 'window.log'

function Write-WindowLog($m) {
  New-Item -ItemType Directory -Force -Path $FleetData | Out-Null
  Add-Content -Path $LogFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m" -Encoding UTF8
  Limit-Log $LogFile
}

Info "Showcase Fleet $($Version): putting the window on this NUC"
if (-not (Test-Admin)) { Fail 'Needs admin. Open Fleet with the .bat file, which asks for it.'; return }
if (-not $Version) { Fail "No version.txt in $Source\app."; return }
if (-not (Test-Path (Join-Path $Source $Bat))) { Fail "$Bat is missing from $Source."; return }
Step "Only SYSTEM and Administrators can change $FleetData" { Protect-FleetData }

$from = [IO.Path]::GetFullPath($Source).TrimEnd('\')
$to   = [IO.Path]::GetFullPath($Dest).TrimEnd('\')
if ($from -ieq $to) {
  Ok "Already running from $Dest"
} else {
  try {
    New-Item -ItemType Directory -Force -Path $Dest | Out-Null
    # trial 3 left files here that even administrators couldn't read or replace: take the folder back first
    & takeown.exe /F $Dest /R /D Y 2>&1 | Out-Null
    & icacls.exe $Dest /reset /T /C /Q 2>&1 | Out-Null
    # the build-only folders never go onto a NUC (the agent does, from trial 10). On a NUC enrolled in Fleet online, or
    # from a core package (no modules folder), the modules belong to the agent: the copy leaves them alone.
    $xd = @('central', 'spikes', '_dist', 'cloud')
    if (-not (Test-Path (Join-Path $from 'modules')) -or (Test-Path (Join-Path $FleetData 'agent\token.dat'))) { $xd += 'modules' }
    & robocopy.exe $from $to /MIR /XD @xd /NFL /NDL /NJH /NJS /NP /R:1 /W:1 | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "the copy failed (robocopy code $LASTEXITCODE)" }
    Ok "Copied Fleet $Version to $Dest"
  } catch { Fail "Copy: $($_.Exception.Message)"; Write-WindowLog "FAIL copy $Version from $from - $($_.Exception.Message)"; return }
  # only this version's launcher stays
  Get-ChildItem $Dest -Filter 'showcase_fleet_manager_*.bat' | Where-Object { $_.Name -ne $Bat } |
    ForEach-Object { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue }
}

Step 'Only SYSTEM and Administrators can change it' {
  # Set the folder, then make everything inside inherit from it. (Trial 3 used /grant:r with /T, which
  # left every file with no permissions at all, so the desktop shortcut couldn't open it.)
  & icacls.exe $Dest /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' /Q | Out-Null
  if ($LASTEXITCODE -ne 0) { throw "icacls code $LASTEXITCODE on the folder" }
  & icacls.exe (Join-Path $Dest '*') /reset /T /Q | Out-Null
  if ($LASTEXITCODE -ne 0) { throw "icacls code $LASTEXITCODE on its files" }
}

Step 'Shortcuts on the Public desktop and in the Start menu' { Set-FleetShortcuts $Dest $Version }

# Pinned to the taskbar (Jordan, 24 Oct). Windows 11 lets a program be pinned only through a taskbar layout policy,
# which it reads at the next sign-in. Left alone if the NUC already has a layout policy of its own; Windows 10's
# version of that policy also locks the Start menu, so not there.
$policy = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer'
$layout = Join-Path $FleetData 'taskbar_layout.xml'
$current = (Get-ItemProperty $policy -Name StartLayoutFile -ErrorAction SilentlyContinue).StartLayoutFile
if ([Environment]::OSVersion.Version.Build -lt 22000) { Info 'Taskbar: Windows 10 has no safe way to pin it; use the desktop or Start menu shortcut.' }
elseif ($current -and $current -ine $layout) { Warn "Taskbar: not pinned, this NUC already has a taskbar layout of its own ($current)." }
else {
  Step 'Pinned to the taskbar (it shows there after the next sign-in or restart)' {
    $xml = @(
      '<?xml version="1.0" encoding="utf-8"?>'
      '<LayoutModificationTemplate xmlns="http://schemas.microsoft.com/Start/2014/LayoutModification"'
      '    xmlns:defaultlayout="http://schemas.microsoft.com/Start/2014/FullDefaultLayout"'
      '    xmlns:start="http://schemas.microsoft.com/Start/2014/StartLayout"'
      '    xmlns:taskbar="http://schemas.microsoft.com/Start/2014/TaskbarLayout" Version="1">'
      '  <CustomTaskbarLayoutCollection PinListPlacement="Append">'
      '    <defaultlayout:TaskbarLayout>'
      '      <taskbar:TaskbarPinList>'
      '        <taskbar:DesktopApp DesktopApplicationLinkPath="%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Showcase Fleet.lnk" />'
      '      </taskbar:TaskbarPinList>'
      '    </defaultlayout:TaskbarLayout>'
      '  </CustomTaskbarLayoutCollection>'
      '</LayoutModificationTemplate>'
    )
    Set-Content -Path $layout -Value $xml -Encoding UTF8
    if (-not (Test-Path $policy)) { New-Item -Path $policy -Force | Out-Null }
    New-ItemProperty -Path $policy -Name StartLayoutFile -PropertyType ExpandString -Value $layout -Force | Out-Null
    New-ItemProperty -Path $policy -Name LockedStartLayout -PropertyType DWord -Value 1 -Force | Out-Null
  }
}

Set-Content -Path (Join-Path $Dest 'installed.json') -Encoding UTF8 -Value (@{ version = $Version; installed = (Get-Date).ToString('s'); from = $from } | ConvertTo-Json -Compress)
Write-WindowLog "OK installed $Version from $from"
Ok "Showcase Fleet $Version is on this NUC. Open it from the desktop, the Start menu or the taskbar from now on."
