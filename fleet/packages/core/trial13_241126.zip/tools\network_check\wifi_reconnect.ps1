# Tool action: reconnect the Wi-Fi now (141026)
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')

$wlan = & netsh.exe wlan show interfaces 2>$null
$iface = ($wlan | Select-String -Pattern '^\s*Name\s*:\s*(.+)$' | Select-Object -First 1)
if (-not $iface) { throw 'This NUC has no Wi-Fi adapter.' }
$iface = $iface.Matches[0].Groups[1].Value.Trim()
$profileName = ($wlan | Select-String -Pattern '^\s*Profile\s*:\s*(.+)$' | Select-Object -First 1)
if ($profileName) { $profileName = $profileName.Matches[0].Groups[1].Value.Trim() }
else {
  # not connected right now: use the network the Reconnect module last saw, if it is installed
  try { $profileName = (Get-Content (Join-Path $FleetData 'reconnect\state.json') -Raw | ConvertFrom-Json).wifiProfile } catch { }
}
if (-not $profileName) { throw 'Not connected to any Wi-Fi, and no saved network to go back to. Connect it by hand once.' }

Info "Reconnecting '$profileName' on $iface..."
& netsh.exe wlan disconnect interface="$iface" | Out-Null
Start-Sleep -Seconds 3
& netsh.exe wlan connect name="$profileName" interface="$iface" | Out-Null
$until = (Get-Date).AddSeconds(40)
while ((Get-Date) -lt $until) {
  Start-Sleep -Seconds 3
  $c = New-Object Net.Sockets.TcpClient
  try { if ($c.ConnectAsync('app.showcase.space', 443).Wait(3000) -and $c.Connected) { Ok "Back on '$profileName' and Showcase answers."; return } } catch { } finally { $c.Dispose() }
}
Warn "Reconnected to '$profileName', but Showcase is not answering yet. Run the network check."
