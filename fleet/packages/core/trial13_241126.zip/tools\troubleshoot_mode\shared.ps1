# Tool: troubleshooting mode (trial 7, 24 Oct 2026). Shared by status, open and back.
# Trial 7: Fleet's own windows are known by their profile folder; Showcase opens on the real screen when the
# support screen is installed.
# Troubleshooting mode = the same Showcase, same Chrome profile (so the remote pairing and the cache
# stay), but not in kiosk: a normal maximised window with DevTools open, so you can see what is or
# isn't loading. Showcase Pin and Kiosk are paused meanwhile so they don't put the kiosk back.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')

$TsData    = Join-Path $FleetData 'troubleshoot'
$SavedLine = Join-Path $TsData 'kiosk_command_line.txt'   # holds the Showcase URL and its keys: admins only
$PauseFile = Join-Path $env:ProgramData 'ShowcasePause.txt'

function Get-ChromeExe {
  @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe") |
    Where-Object { Test-Path $_ } | Select-Object -First 1
}

# the main Chrome process (not a renderer or helper) for a given switch, never our own Fleet windows
function Get-MainChrome([string]$must) {
  @(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -and $_.CommandLine -notmatch '--type=' -and $_.CommandLine -notmatch $FleetBrowserPattern -and $_.CommandLine -match $must
  })
}

# with the support screen installed, Windows' main display is the hidden one: Chrome switches for the first real screen
function Get-RealScreenPlace {
  try { $s = Get-Content (Join-Path $FleetData 'support_screen\state.json') -Raw | ConvertFrom-Json } catch { return '' }
  if (-not $s.supportScreen -or -not @($s.realScreens).Count) { return '' }
  $name = (@($s.realScreens)[0] -split ' ')[0]
  Add-Type -AssemblyName System.Windows.Forms
  $scr = [System.Windows.Forms.Screen]::AllScreens | Where-Object { $_.DeviceName -eq $name } | Select-Object -First 1
  if ($scr) { $b = $scr.Bounds; "--window-position=$($b.X),$($b.Y) --window-size=$($b.Width),$($b.Height)" } else { '' }
}

function Get-ProfileDir([string]$line) { if ($line -match '--user-data-dir="?([^"]+?)"?(\s--|$)') { $Matches[1] } }

# a URL for the output: host and path only, never the keys in the query string
function Hide-Keys([string]$s) { $s -replace '(https?://[^\s"?]+)\?[^\s"]*', '$1?(keys hidden)' }

# where Showcase opens on this NUC, if Chrome isn't running: Startup Kiosk's config, else a startup bat
function Find-ShowcaseUrl {
  $cfg = Join-Path $env:ProgramData 'ShowcaseKiosk\kiosk.config'
  if (Test-Path $cfg) { $u = (Select-String -Path $cfg -Pattern '^\s*Url=(.+)$' | Select-Object -First 1).Matches.Groups[1].Value; if ($u) { return $u.Trim() } }
  $user = (Get-DisplayUser) -replace '^.*\\', ''
  $startup = "C:\Users\$user\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"
  foreach ($f in @(Get-ChildItem $startup -Filter '*.bat' -ErrorAction SilentlyContinue)) {
    $m = Select-String -Path $f.FullName -Pattern 'https://app\.showcase\.space[^\s"]*' | Select-Object -First 1
    if ($m) { return $m.Matches[0].Value }
  }
  $null
}

# runs a command line as the person signed in on the display, in their session, not elevated
function Start-AsDisplayUser([string]$exe, [string]$arguments) {
  $user = Get-DisplayUser
  $task = 'showcase_fleet_troubleshoot_launch'
  $action = New-ScheduledTaskAction -Execute $exe -Argument $arguments
  $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
  Register-ScheduledTask -TaskName $task -Action $action -Principal $principal -Force | Out-Null
  try { Start-ScheduledTask -TaskName $task; Start-Sleep -Seconds 3 }
  finally { Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue }
}

function Stop-ChromeProfile([string]$profileDir) {
  $all = @(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine -like "*$profileDir*" })
  $all | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Start-Sleep -Seconds 2
  $all.Count
}

# the same pause Fleet and Ctrl+Alt+Q use (ticks of the time it ends)
function Set-ShowcasePause([int]$minutes) {
  if ($minutes -le 0) { Remove-Item $PauseFile -Force -ErrorAction SilentlyContinue; return }
  Set-Content -Path $PauseFile -Value "$((Get-Date).AddMinutes($minutes).Ticks)" -Encoding ASCII
  & icacls.exe $PauseFile /grant '*S-1-5-32-545:M' | Out-Null
}
