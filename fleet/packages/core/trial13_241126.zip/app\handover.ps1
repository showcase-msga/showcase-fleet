# Showcase Fleet trial 7 (24 Oct 2026): hands an open Fleet window over to the copy installed on this NUC.
# Started hidden (as admin) by a copied folder's window once Fleet is in ProgramData: waits for that window's server
# to stop, deletes the copied folder if it's one a tech unzipped onto a desktop or into Downloads (Jordan, 24 Oct:
# "Once I've installed it, it should delete the desktop folder"), then opens Fleet from ProgramData.
param([int]$OldPid, [string]$Source)
. (Join-Path $PSScriptRoot 'common.ps1')
$LogFile = Join-Path $FleetData 'window.log'
function Write-WindowLog($m) { Add-Content -Path $LogFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m" -Encoding UTF8 -ErrorAction SilentlyContinue }

if ($OldPid) { Wait-Process -Id $OldPid -Timeout 30 -ErrorAction SilentlyContinue }
$del = if ($Source) { Get-CopiedFleetFolder $Source } else { $null }
if ($del) {
  for ($i = 0; $i -lt 5 -and (Test-Path -LiteralPath $del); $i++) {
    Remove-Item -LiteralPath $del -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path -LiteralPath $del) { Start-Sleep -Seconds 2 }
  }
  Write-WindowLog $(if (Test-Path -LiteralPath $del) { "WARN couldn't delete the copied folder $del" } else { "OK deleted the copied folder $del" })
}
Start-Process powershell.exe -WindowStyle Hidden -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $PSScriptRoot 'server.ps1')`""
Write-WindowLog 'OK opened Fleet from the installed copy'
