# Tool: troubleshooting mode, open (trial 7). Takes Showcase out of kiosk on this NUC: closes the kiosk
# Chrome and reopens the same page, same profile, as a normal maximised window with DevTools open.
. (Join-Path $PSScriptRoot 'shared.ps1')
$ErrorActionPreference = 'Continue'
if (-not (Test-Admin)) { Fail 'Needs admin.'; return }

$chrome = Get-ChromeExe
if (-not $chrome) { Fail 'Chrome is not installed for all users on this NUC.'; return }
New-Item -ItemType Directory -Force -Path $TsData | Out-Null
& icacls.exe $TsData /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' /Q | Out-Null

$kiosk = Get-MainChrome '--kiosk' | Select-Object -First 1
if ($kiosk) {
  $line = $kiosk.CommandLine
  Set-Content -Path $SavedLine -Value $line -Encoding UTF8
  Ok "Found Showcase in kiosk: $(Hide-Keys $line)"
} elseif (Test-Path $SavedLine) {
  $line = (Get-Content $SavedLine -Raw).Trim()
  Warn 'Showcase is not in kiosk now; using the kiosk line saved last time.'
} else {
  $url = Find-ShowcaseUrl
  if (-not $url) { Fail "Couldn't find Showcase running or its URL (Startup Kiosk config, or a startup bat). Nothing changed."; return }
  $user = (Get-DisplayUser) -replace '^.*\\', ''
  $line = "`"$chrome`" --kiosk `"$url`" --user-data-dir=`"C:\Users\$user\AppData\Local\Google\Chrome\User Data\showcase`" --window-name=`"showcase`" --autoplay-policy=no-user-gesture-required --start-fullscreen"
  Set-Content -Path $SavedLine -Value $line -Encoding UTF8
  Warn "Showcase wasn't running; opening it from its URL: $(Hide-Keys $url)"
}

$profileDir = Get-ProfileDir $line
Set-ShowcasePause 60
Ok 'Showcase Pin and Kiosk paused for 60 minutes, so they leave the window alone'

# same switches without kiosk and full screen; a normal window with DevTools
$args2 = ($line -replace '^\s*"[^"]*chrome\.exe"\s*', '' -replace '^\s*\S*chrome\.exe\s*', '')
$args2 = $args2 -replace '--kiosk\b', '' -replace '--start-fullscreen\b', ''
$args2 = "$args2 --start-maximized --auto-open-devtools-for-tabs".Trim() -replace '\s{2,}', ' '
# on the real screen, not the hidden support screen (Startup Kiosk's line already says where; the others don't)
if ($args2 -notmatch '--window-position=') { $place = Get-RealScreenPlace; if ($place) { $args2 = "$args2 $place" } }

if ($profileDir) { $n = Stop-ChromeProfile $profileDir; Ok "Closed the kiosk Chrome ($n processes)" }
else { Warn 'No profile folder on the kiosk line; closing every Chrome.'; Get-Process chrome -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep -Seconds 2 }

try {
  Start-AsDisplayUser $chrome $args2
  Ok 'Showcase is open in troubleshooting mode: a normal window with DevTools (F12 toggles it).'
  Info 'Back to kiosk mode when you are done, or it stays like this until the pause runs out and the next restart.'
} catch { Fail "Could not open Chrome as the display user: $($_.Exception.Message)" }
