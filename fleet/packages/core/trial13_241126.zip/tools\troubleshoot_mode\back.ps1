# Tool: troubleshooting mode, back to kiosk (trial 3). Closes the troubleshooting window and reopens
# Showcase exactly as it was (the kiosk command line saved when troubleshooting mode opened).
. (Join-Path $PSScriptRoot 'shared.ps1')
$ErrorActionPreference = 'Continue'
if (-not (Test-Admin)) { Fail 'Needs admin.'; return }
if (-not (Test-Path $SavedLine)) { Fail 'No saved kiosk line: troubleshooting mode was not opened from Fleet on this NUC. Restart the NUC to get back to kiosk.'; return }

$line = (Get-Content $SavedLine -Raw).Trim()
$profileDir = Get-ProfileDir $line
if ($profileDir) { $n = Stop-ChromeProfile $profileDir; Ok "Closed the troubleshooting window ($n processes)" }

if ($line -match '^\s*"([^"]+chrome\.exe)"\s*(.*)$' -or $line -match '^\s*(\S+chrome\.exe)\s*(.*)$') {
  try { Start-AsDisplayUser $Matches[1] $Matches[2]; Ok 'Showcase is back in kiosk mode.' }
  catch { Fail "Could not reopen the kiosk: $($_.Exception.Message). A restart puts it back." ; return }
} else { Fail 'The saved kiosk line could not be read. A restart puts Showcase back.'; return }

Set-ShowcasePause 0
Ok 'Showcase Pin and Kiosk resumed'
Remove-Item $SavedLine -Force -ErrorAction SilentlyContinue
