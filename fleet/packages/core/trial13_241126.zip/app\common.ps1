# Showcase Fleet Manager: helpers shared by every module and tool.
# Dot-source it at the top of a module script:  . (Join-Path $PSScriptRoot '..\..\app\common.ps1')
#
# Output convention, read by the Fleet Manager window:
#   [OK] ...    green     [WARN] ...  amber     [FAIL] ...  red     anything else: plain
#   @@JSON {...}  one line of data for the window to draw (tools only)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# SHOWCASE_FLEET_TEST_HOME: a test folder instead, on Jordan's PC only (proving the agent without touching the real
# install); never set on a NUC
$FleetData = if ($env:SHOWCASE_FLEET_TEST_HOME) { $env:SHOWCASE_FLEET_TEST_HOME } else { Join-Path $env:ProgramData 'showcase_fleet' }

function Ok($m)   { Write-Output "[OK]   $m" }
function Warn($m) { Write-Output "[WARN] $m" }
function Fail($m) { Write-Output "[FAIL] $m" }
function Info($m) { Write-Output $m }

# runs a step and reports it; a failure is a warning, the script carries on
function Step($name, [scriptblock]$do) {
  try { & $do; Ok $name } catch { Warn "$name - $($_.Exception.Message)" }
}

function Send-Json($obj) { Write-Output ('@@JSON ' + ($obj | ConvertTo-Json -Depth 8 -Compress)) }

function Test-Admin {
  $me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
  $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# the user signed in on the display; tools that draw on the screen must run as them. A NUC logs itself in
# (Winlogon AutoAdminLogon): if someone else is on the display (Switch User), stop rather than tie tasks to them
function Get-DisplayUser {
  $u = (Get-CimInstance Win32_ComputerSystem).UserName
  $wl = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -ErrorAction SilentlyContinue
  $auto = if ($wl -and "$($wl.AutoAdminLogon)" -eq '1' -and $wl.DefaultUserName) { "$($wl.DefaultUserName)" -replace '^.*\\', '' } else { '' }
  if ($auto -and $u -and ($u -replace '^.*\\', '') -ne $auto) {
    throw "$u is signed in on the display, but this NUC logs itself in as $auto. Sign back in as $auto, then try again."
  }
  if ($u) { return $u }
  if ($auto) { return "$(if ($wl.DefaultDomainName) { $wl.DefaultDomainName } else { $env:COMPUTERNAME })\$auto" }
  throw 'Nobody is logged in on the NUC display. Let it log in, then try again.'
}

# Fleet's own Chrome windows (its window and the screen tests), known by their profile folder. Never match on a plain
# 'showcase_fleet': Showcase's own command line can carry one (trial 6's console-mode log path did).
$FleetBrowserPattern = 'showcase_fleet_(manager_window|screen_\d)'

# ProgramData lets any user create folders, so Fleet's own folder is locked: admins and SYSTEM change it, everyone
# else reads. Folders the display user's programs write to get their own grant (support_screen, blackout).
function Protect-FleetData {
  New-Item -ItemType Directory -Force -Path $FleetData | Out-Null
  $acl = Get-Acl $FleetData
  try { $owner = (New-Object Security.Principal.NTAccount($acl.Owner)).Translate([Security.Principal.SecurityIdentifier]).Value } catch { $owner = '' }
  if ($acl.AreAccessRulesProtected -and $owner -eq 'S-1-5-32-544') { return }
  & icacls.exe $FleetData /setowner '*S-1-5-32-544' /Q | Out-Null
  & icacls.exe $FleetData /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' /Q | Out-Null
}

# a module's own folder in ProgramData, created on first use
function Get-ModuleData($id) {
  $d = Join-Path $FleetData $id
  New-Item -ItemType Directory -Force -Path $d | Out-Null
  $d
}

# never New-Item -Force on a registry key that exists: it wipes every value already in it
function Set-RegDword($path, $name, $value) {
  if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
  New-ItemProperty -Path $path -Name $name -PropertyType DWord -Value $value -Force | Out-Null
}

# Runs a PowerShell file once as SYSTEM (for what admins are not allowed to touch), waits for it,
# and returns its log. The file must write its log to $Log and finish it with a line 'DONE'.
function Invoke-AsSystem($File, [string]$Arguments, $Log, [int]$TimeoutSeconds = 180) {
  $task = 'showcase_fleet_run_once'
  Remove-Item $Log -ErrorAction SilentlyContinue
  $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$File`" $Arguments"
  Register-ScheduledTask -TaskName $task -Action $action -User 'NT AUTHORITY\SYSTEM' -RunLevel Highest -Force | Out-Null
  try {
    Start-ScheduledTask -TaskName $task
    $until = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $until -and -not ((Test-Path $Log) -and (Select-String -Path $Log -Pattern '^DONE' -Quiet))) { Start-Sleep -Seconds 2 }
  } finally {
    Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
  }
  if (-not (Test-Path $Log)) { throw 'The SYSTEM step did not run. Check Task Scheduler.' }
  $lines = @(Get-Content $Log)
  if ($lines -notcontains 'DONE') { $lines += '[WARN] It did not finish in time. Check the log and try again.' }
  $lines | Where-Object { $_ -ne 'DONE' }
}

# keeps a log file under about 1 MB
function Limit-Log($path) {
  if ((Test-Path $path) -and (Get-Item $path).Length -gt 1MB) {
    Get-Content $path -Tail 2000 | Set-Content "$path.tmp" -Encoding UTF8
    Move-Item "$path.tmp" $path -Force
  }
}

# ---------------------------------------------------------------- this NUC's own settings (trial 6, 24 Oct 2026)
# C:\ProgramData\showcase_fleet\nuc.config, one Name=value per line. Outside Fleet's own folder, so a Fleet update
# never touches it. Edited in the Fleet window (This NUC) or by hand. The Showcase URL lives here, not in any launcher.

$NucConfigPath = Join-Path $FleetData 'nuc.config'
$NucConfigKeys = @('NucId', 'ShowcaseUrl', 'LauncherMode', 'SiteRole', 'ScreenType', 'OckNumber', 'Notes')

function Get-NucConfig {
  $c = [ordered]@{}
  foreach ($k in $NucConfigKeys) { $c[$k] = '' }
  if (Test-Path $NucConfigPath) {
    foreach ($line in Get-Content $NucConfigPath -Encoding UTF8) {
      if ($line -match '^\s*#') { continue }
      $i = $line.IndexOf('=')
      if ($i -gt 0) { $c[$line.Substring(0, $i).Trim()] = $line.Substring($i + 1).Trim() }
    }
  }
  if (-not $c.LauncherMode) { $c.LauncherMode = 'kiosk' }
  if (-not $c.SiteRole) { $c.SiteRole = 'normal' }
  $c
}

function Save-NucConfig($c) {
  New-Item -ItemType Directory -Force -Path $FleetData | Out-Null
  $lines = @("# Showcase Fleet: this NUC's own settings. Edit in the Fleet window (This NUC) or here: one Name=value per line.")
  foreach ($k in $c.Keys) { $lines += "$k=$($c[$k])" }
  Set-Content -Path $NucConfigPath -Value $lines -Encoding UTF8
  # admins and SYSTEM change it; everyone signed in can read it (the launcher needs the URL). A file, so no (OI)(CI).
  & icacls.exe $NucConfigPath /inheritance:r /grant:r '*S-1-5-18:F' '*S-1-5-32-544:F' '*S-1-5-32-545:R' | Out-Null
}

# a Showcase URL for logs and the window: host and path only, never the keys (wherever they sit in it)
function Hide-UrlKeys([string]$u) {
  if (-not $u) { return '' }
  ($u -replace '(sessionKey|authenticate|masterKey)=[^&#]*', '$1=(hidden)') -replace '\?.*$', '?(keys hidden)'
}

# the launchers add polling=true themselves; take it out of a stored URL, keeping the separators right
function Remove-PollingParam([string]$u) {
  $u = $u -replace '([?&])polling=true(&|$)', '$1'
  $u -replace '[?&]$', ''
}

# where this NUC's Showcase URL is today, so nobody retypes it: the running kiosk Chrome, Startup Kiosk's config,
# then any startup bat (in a Startup folder, behind a Startup shortcut, or set aside in an old-startup folder)
function Find-ShowcaseUrl {
  $pick = { param($s) if ($s -match '(https://app\.showcase\.space/[^\s"%]+)') { Remove-PollingParam $Matches[1] } }
  foreach ($p in @(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue)) {
    if ($p.CommandLine -and $p.CommandLine -notmatch '--type=' -and $p.CommandLine -notmatch $FleetBrowserPattern) {
      $u = & $pick $p.CommandLine; if ($u) { return @{ url = $u; from = 'the Showcase window running now' } }
    }
  }
  $kc = Join-Path $env:ProgramData 'ShowcaseKiosk\kiosk.config'
  if (Test-Path $kc) { $u = & $pick ((Get-Content $kc -Raw) -replace 'Url=', ' '); if ($u) { return @{ url = $u; from = 'Showcase Kiosk (kiosk.config)' } } }
  $dirs = @("$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp",
            (Join-Path $env:ProgramData 'ShowcaseKiosk\old-startup'), (Join-Path $FleetData 'launcher\old_startup'))
  try {
    $sid = (New-Object Security.Principal.NTAccount((Get-CimInstance Win32_ComputerSystem).UserName)).Translate([Security.Principal.SecurityIdentifier]).Value
    $prof = (Get-CimInstance Win32_UserProfile | Where-Object SID -eq $sid).LocalPath
    if ($prof) { $dirs += "$prof\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"; $dirs += "$prof\Desktop" }
  } catch { }
  $shell = New-Object -ComObject WScript.Shell
  foreach ($d in $dirs) {
    if (-not (Test-Path -LiteralPath $d)) { continue }
    foreach ($f in Get-ChildItem -LiteralPath $d -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in '.bat', '.cmd', '.lnk' }) {
      $file = $f.FullName
      if ($f.Extension -eq '.lnk') { $file = $shell.CreateShortcut($f.FullName).TargetPath }
      if (-not $file -or -not (Test-Path -LiteralPath $file) -or [IO.Path]::GetExtension($file) -notin '.bat', '.cmd') { continue }
      $text = Get-Content -LiteralPath $file -Raw -ErrorAction SilentlyContinue
      if ($text -match 'set\s+"?URL=([^"\r\n]+)') { $u = & $pick $Matches[1] } else { $u = & $pick $text }
      if ($u) { return @{ url = $u; from = $file } }
    }
  }
  $null
}

# runs a program as the person signed in on the display, in their session, not elevated (a one-off task)
function Start-AsDisplayUser([string]$exe, [string]$arguments = '') {
  $task = 'showcase_fleet_launch_as_user'
  $action = if ($arguments) { New-ScheduledTaskAction -Execute $exe -Argument $arguments } else { New-ScheduledTaskAction -Execute $exe }
  $principal = New-ScheduledTaskPrincipal -UserId (Get-DisplayUser) -LogonType Interactive -RunLevel Limited
  Register-ScheduledTask -TaskName $task -Action $action -Principal $principal -Force | Out-Null
  try { Start-ScheduledTask -TaskName $task; Start-Sleep -Seconds 3 }
  finally { Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue }
}

# runs a program once as the display user, in their session, not elevated; waits for it and returns its exit code
# (-1 if it didn't finish in time). For programs in folders the display user can change: admin never runs those itself.
function Invoke-AsDisplayUser([string]$exe, [string]$arguments = '', [int]$TimeoutSeconds = 60) {
  $task = 'showcase_fleet_run_as_user'
  $action = if ($arguments) { New-ScheduledTaskAction -Execute $exe -Argument $arguments } else { New-ScheduledTaskAction -Execute $exe }
  $principal = New-ScheduledTaskPrincipal -UserId (Get-DisplayUser) -LogonType Interactive -RunLevel Limited
  $settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Seconds ($TimeoutSeconds + 30)) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
  Register-ScheduledTask -TaskName $task -Action $action -Principal $principal -Settings $settings -Force | Out-Null
  try {
    Start-ScheduledTask -TaskName $task
    $until = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
      Start-Sleep -Milliseconds 500
      $state  = (Get-ScheduledTask -TaskName $task).State
      $result = [long](Get-ScheduledTaskInfo -TaskName $task).LastTaskResult
    } while ((Get-Date) -lt $until -and ("$state" -in 'Running', 'Queued' -or $result -in 267009, 267011))   # running / not run yet
    if ("$state" -in 'Running', 'Queued' -or $result -in 267009, 267011) { Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue; return -1 }
    [int]$result
  } finally { Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue }
}

# ---------------------------------------------------------------- the Fleet window on this NUC (trial 7)

# the "Showcase Fleet" shortcuts, on the Public desktop and in the Start menu, straight to the no-console launcher
function Set-FleetShortcuts([string]$dest, [string]$version) {
  $shell = New-Object -ComObject WScript.Shell
  foreach ($dir in @([Environment]::GetFolderPath('CommonDesktopDirectory'), [Environment]::GetFolderPath('CommonPrograms'))) {
    $s = $shell.CreateShortcut((Join-Path $dir 'Showcase Fleet.lnk'))
    $s.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
    $s.Arguments = "`"$(Join-Path $dest 'app\open_fleet.vbs')`""
    $s.WorkingDirectory = $dest
    $s.IconLocation = "$(Join-Path $dest 'app\ui\fleet.ico'),0"
    $s.Description = "Showcase Fleet $version"
    $s.Save()
  }
}

# A copy of Fleet a tech unzipped onto a desktop or into Downloads, which goes once Fleet is installed: the folder
# itself, or the folder Windows' "Extract All" made around it (same name, nothing else in it). $null for anything
# else, so a working copy anywhere else (the vault's own source folder) is never touched.
function Get-CopiedFleetFolder([string]$root) {
  $root = [IO.Path]::GetFullPath($root).TrimEnd('\')
  if ($root -ieq [IO.Path]::GetFullPath((Join-Path $FleetData 'window')).TrimEnd('\')) { return $null }
  $name = Split-Path $root -Leaf
  if ($name -notmatch '^showcase_fleet_manager_(trial\d+_)?\d{6}(_v\d+)?$') { return $null }
  if (-not (Test-Path -LiteralPath (Join-Path $root 'app\server.ps1'))) { return $null }
  $target = $root
  $parent = Split-Path $root -Parent
  if ((Split-Path $parent -Leaf) -ieq $name -and @(Get-ChildItem -LiteralPath $parent -Force).Count -eq 1) { $target = $parent; $parent = Split-Path $parent -Parent }
  if ((Split-Path $parent -Leaf) -notin 'Desktop', 'Downloads') { return $null }
  $target
}

# the display user's own Startup folder (startup scripts run there as that user)
function Get-UserStartupDir {
  $sid = (New-Object Security.Principal.NTAccount((Get-DisplayUser))).Translate([Security.Principal.SecurityIdentifier]).Value
  $prof = (Get-CimInstance Win32_UserProfile | Where-Object SID -eq $sid).LocalPath
  if (-not $prof) { throw 'Could not find the display user''s profile folder.' }
  "$prof\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"
}

# set aside any other Showcase startup script (one with --kiosk in it, or a shortcut to one), so two never run;
# returns what moved. The launcher modules put them back on Remove.
function Move-OldStartup($backup, [string[]]$except = @()) {
  $dirs = @("$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp", (Get-UserStartupDir))
  $shell = New-Object -ComObject WScript.Shell
  $moved = @()
  foreach ($sd in $dirs) {
    if (-not (Test-Path -LiteralPath $sd)) { continue }
    foreach ($f in Get-ChildItem -LiteralPath $sd -File | Where-Object { $_.Extension -in '.bat', '.cmd', '.lnk', '.vbs' }) {
      if ($except -contains $f.Name) { continue }
      # a shortcut counts by its target and arguments (a shortcut straight to chrome.exe --kiosk <url>), plus the script it runs
      $file = $f.FullName; $text = ''
      if ($f.Extension -eq '.lnk') { $lnk = $shell.CreateShortcut($f.FullName); $file = $lnk.TargetPath; $text = "$($lnk.TargetPath) $($lnk.Arguments)" }
      $isScript = $file -and (Test-Path -LiteralPath $file) -and [IO.Path]::GetExtension($file) -in '.bat', '.cmd', '.vbs'
      if ($isScript) { $text += ' ' + (Get-Content -LiteralPath $file -Raw -ErrorAction SilentlyContinue) }
      if ($text -match '--kiosk|app\.showcase\.space') {
        New-Item -ItemType Directory -Force -Path $backup | Out-Null
        Set-Content -Path (Join-Path $backup "$($f.Name).from.txt") -Value $sd -Encoding UTF8
        Move-Item -LiteralPath $f.FullName -Destination (Join-Path $backup $f.Name) -Force
        # stop the copy running now, or its loop keeps fighting the new launcher until a restart
        $name = [IO.Path]::GetFileName($file)
        if ($isScript) {
          Get-CimInstance Win32_Process -Filter "Name='cmd.exe' OR Name='wscript.exe'" | Where-Object { $_.CommandLine -like "*$name*" } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        }
        $moved += "$($f.Name) (from $sd)"
      }
    }
  }
  $moved
}

# put back what Move-OldStartup set aside, each into the folder it came from
function Restore-OldStartup($backup) {
  $back = @()
  if (-not (Test-Path $backup)) { return $back }
  foreach ($f in Get-ChildItem $backup -File | Where-Object { $_.Name -notlike '*.from.txt' }) {
    $fromFile = Join-Path $backup "$($f.Name).from.txt"
    $to = if (Test-Path $fromFile) { (Get-Content $fromFile -Raw).Trim() } else { "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp" }
    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $to $f.Name) -Force
    $back += "$($f.Name) (to $to)"
  }
  Remove-Item $backup -Recurse -Force -ErrorAction SilentlyContinue
  $back
}
