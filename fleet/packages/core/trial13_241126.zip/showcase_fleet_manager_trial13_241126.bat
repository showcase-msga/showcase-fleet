@echo off
rem showcase_fleet_manager_trial13_241126 (trial 13, made 24 Nov 2026; a confirmed release drops "trial")
rem Double-click on the NUC. It asks for admin, then opens the Showcase Fleet window, with no console window.
rem The first time, Fleet also puts itself on the NUC: C:\ProgramData\showcase_fleet\window, plus a
rem "Showcase Fleet" shortcut on the desktop, in the Start menu and on the taskbar. It then reopens from there, and
rem this unzipped folder is deleted if it sits on a desktop or in Downloads. Open Fleet from the shortcut after that.
rem If nothing opens, the reason is in C:\ProgramData\showcase_fleet\window_console.log.

wscript.exe "%~dp0app\open_fleet.vbs"
