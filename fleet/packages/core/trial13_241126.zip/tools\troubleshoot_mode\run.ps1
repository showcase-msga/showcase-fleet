# Tool: troubleshooting mode, status (trial 3). Reads only: is Showcase in kiosk or troubleshooting mode.
. (Join-Path $PSScriptRoot 'shared.ps1')
$ErrorActionPreference = 'Continue'

$kiosk = Get-MainChrome '--kiosk' | Select-Object -First 1
$plain = Get-MainChrome 'app\.showcase\.space' | Where-Object { $_.CommandLine -notmatch '--kiosk' } | Select-Object -First 1
$mode = if ($kiosk) { 'Kiosk (normal)' } elseif ($plain) { 'Troubleshooting mode' } else { 'Showcase is not running' }
$items = @(
  @('Showcase is in', $mode),
  @('Chrome window', $(if ($kiosk) { Hide-Keys $kiosk.CommandLine } elseif ($plain) { Hide-Keys $plain.CommandLine } else { '-' })),
  @('Saved kiosk line', $(if (Test-Path $SavedLine) { 'Yes: Back to kiosk mode will restore it' } else { 'None' })),
  @('Pin and Kiosk', $(if (Test-Path $PauseFile) { try { $d = New-Object DateTime ([long](Get-Content $PauseFile -Raw).Trim()); if ($d -gt (Get-Date)) { "Paused until $($d.ToString('h:mm tt'))" } else { 'Running' } } catch { 'Running' } } else { 'Running' }))
)
Info "Showcase is in: $mode"
Send-Json @{ groups = @(@{ name = 'Troubleshooting mode'; items = $items }) }
