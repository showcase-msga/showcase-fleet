# Tool: network check (141026). Reads only.
param([switch]$Speed)
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$checks = New-Object Collections.ArrayList
function Add-Check($name, $result, $detail) {
  [void]$checks.Add([ordered]@{ name = $name; result = $result; detail = $detail })
  $tag = @{ ok = '[OK]  '; warn = '[WARN]'; bad = '[FAIL]' }[$result]
  Info "$tag $name - $detail"
}

function Test-Ping($target) {
  $p = New-Object Net.NetworkInformation.Ping
  try { $r = $p.Send($target, 2000); if ($r.Status -eq 'Success') { return $r.RoundtripTime } } catch { } finally { $p.Dispose() }
  $null
}

function Test-Port($hostName, $port) {
  $sw = [Diagnostics.Stopwatch]::StartNew()
  $c = New-Object Net.Sockets.TcpClient
  try { if ($c.ConnectAsync($hostName, $port).Wait(4000) -and $c.Connected) { return $sw.ElapsedMilliseconds } } catch { } finally { $c.Dispose() }
  $null
}

# ---- adapters
$wlan = & netsh.exe wlan show interfaces 2>$null
function Wlan($field) { $m = $wlan | Select-String -Pattern "^\s*$field\s*:\s*(.+)$" | Select-Object -First 1; if ($m) { $m.Matches[0].Groups[1].Value.Trim() } }
$adapters = @(Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object { $_.NetAdapter.Status -eq 'Up' } | ForEach-Object {
  $isWifi = $_.NetAdapter.PhysicalMediaType -match '802\.11|Wireless' -or $_.NetAdapter.InterfaceDescription -match 'Wi-?Fi|Wireless'
  [ordered]@{
    name = $_.InterfaceAlias; type = $(if ($isWifi) { 'Wi-Fi' } else { 'Cable' })
    ip = ($_.IPv4Address | Select-Object -First 1).IPAddress
    gateway = ($_.IPv4DefaultGateway | Select-Object -First 1).NextHop
    dns = (@($_.DNSServer | Where-Object { $_.AddressFamily -eq 2 } | ForEach-Object { $_.ServerAddresses }) -join ', ')
    speed = "$($_.NetAdapter.LinkSpeed)"
    ssid = $(if ($isWifi) { Wlan 'SSID' }); signal = $(if ($isWifi) { Wlan 'Signal' })
  }
})
if (-not $adapters.Count) { Add-Check 'Network adapter' 'bad' 'No network adapter is connected.' }
foreach ($a in $adapters) { Info "$($a.name) ($($a.type)): $($a.ip), gateway $($a.gateway)$(if ($a.ssid) { ", Wi-Fi $($a.ssid) $($a.signal)" })" }
foreach ($a in $adapters | Where-Object { $_.signal }) {
  $pct = [int]($a.signal -replace '\D', '')
  Add-Check "Wi-Fi signal ($($a.ssid))" $(if ($pct -ge 70) { 'ok' } elseif ($pct -ge 50) { 'warn' } else { 'bad' }) "$pct%$(if ($pct -lt 70) { ': weak for streaming video. Move the NUC or the access point, or use a cable.' })"
}

# ---- reachability
$gw = ($adapters | Where-Object { $_.gateway } | Select-Object -First 1).gateway
if ($gw) {
  $ms = Test-Ping $gw
  if ($null -ne $ms) { Add-Check 'Router' 'ok' "$gw answers in $ms ms" } else { Add-Check 'Router' 'warn' "$gw does not answer pings (some routers never do)" }
} else { Add-Check 'Router' 'bad' 'No gateway, so no way out to the internet.' }

$ms = Test-Ping '1.1.1.1'
if ($null -ne $ms) { Add-Check 'Internet' $(if ($ms -lt 80) { 'ok' } else { 'warn' }) "1.1.1.1 answers in $ms ms" }
else { Add-Check 'Internet' 'bad' 'Nothing back from 1.1.1.1.' }

$sw = [Diagnostics.Stopwatch]::StartNew()
try { $null = [Net.Dns]::GetHostAddresses('app.showcase.space'); Add-Check 'DNS (names to addresses)' 'ok' "app.showcase.space found in $($sw.ElapsedMilliseconds) ms" }
catch { Add-Check 'DNS (names to addresses)' 'bad' 'Cannot look up app.showcase.space. The site DNS is down or blocked.' }

$dateHeader = $null
$sw = [Diagnostics.Stopwatch]::StartNew()
try {
  $r = Invoke-WebRequest -Uri 'https://app.showcase.space/' -UseBasicParsing -TimeoutSec 10
  $dateHeader = $r.Headers['Date']
  Add-Check 'Showcase app' 'ok' "app.showcase.space loads ($($r.StatusCode)) in $($sw.ElapsedMilliseconds) ms"
} catch { Add-Check 'Showcase app' 'bad' "app.showcase.space does not load: $($_.Exception.Message)" }

foreach ($t in @(
  @('Showcase API', 'api.showcase.space'),
  @('Live sync (Firestore)', 'firestore.googleapis.com'),
  @('Images (Development ID)', 'images.developmentid.com.au'),
  @('Asset downloads (Amazon S3)', 's3.amazonaws.com')
)) {
  $ms = Test-Port $t[1] 443
  if ($null -ne $ms) { Add-Check $t[0] 'ok' "$($t[1]) reachable in $ms ms" } else { Add-Check $t[0] 'bad' "$($t[1]) is not reachable. A firewall may be blocking it." }
}

# a wrong clock breaks secure connections and live sync
if ($dateHeader) {
  $drift = [Math]::Round(((Get-Date).ToUniversalTime() - [datetime]::Parse($dateHeader).ToUniversalTime()).TotalSeconds)
  Add-Check 'Clock' $(if ([Math]::Abs($drift) -le 60) { 'ok' } elseif ([Math]::Abs($drift) -le 300) { 'warn' } else { 'bad' }) $(if ([Math]::Abs($drift) -le 5) { 'Right' } else { "$([Math]::Abs($drift)) seconds $(if ($drift -gt 0) { 'fast' } else { 'slow' })" })
}

if ($Speed) {
  Info 'Speed test: downloading 25 MB...'
  $file = Join-Path $env:TEMP 'showcase_fleet_speed.bin'
  $sw = [Diagnostics.Stopwatch]::StartNew()
  try {
    (New-Object Net.WebClient).DownloadFile('https://speed.cloudflare.com/__down?bytes=25000000', $file)
    $mbps = [Math]::Round((25 * 8) / $sw.Elapsed.TotalSeconds, 1)
    Add-Check 'Download speed' $(if ($mbps -ge 50) { 'ok' } elseif ($mbps -ge 20) { 'warn' } else { 'bad' }) "$mbps Mbps$(if ($mbps -lt 20) { ': too slow for video without local assets' })"
  } catch { Add-Check 'Download speed' 'bad' "The test download failed: $($_.Exception.Message)" }
  finally { Remove-Item $file -Force -ErrorAction SilentlyContinue }
}

Send-Json @{ at = (Get-Date).ToString('h:mm tt'); adapters = $adapters; checks = $checks }
