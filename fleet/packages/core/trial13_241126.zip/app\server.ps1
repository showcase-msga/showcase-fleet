# Showcase Fleet: the small local server behind the Fleet window.
# Started by showcase_fleet_manager_<version>.bat, which asks for admin first.
# Trial 7 (24 Oct 2026): review fixes (token, Host check, busy, version order); opens on the support screen; once
# Fleet is installed, a copied folder's window hands over to the installed one and the unzipped folder is deleted.
# Trial 4 (24 Oct 2026): no console window (app\open_fleet.vbs), support screen module, permissions fix.
# Trial 3 (24 Oct 2026): Baseline is a settings module (recommended vs now, tick to set), planned rows
# can be hidden. Trial 2: modules and tools as a list with the planned ones shown (app\catalogue.json), dark theme,
# logo, and the window puts itself on the NUC by itself when opened as admin (app\install_window.ps1).
# Listens on 127.0.0.1 only, so nothing on the network can reach it, and every request from the
# window carries a one-off token. It stops by itself a few minutes after the window is closed.
#
# Testing on a PC that is not a NUC:
#   powershell -ExecutionPolicy Bypass -File server.ps1 -ReadOnly            (nothing can be installed)
#   powershell -ExecutionPolicy Bypass -File server.ps1 -ReadOnly -NoBrowser (then open the address it prints)
param(
  [int]$Port = 8950,
  [switch]$NoBrowser,
  [switch]$ReadOnly,
  [switch]$Trace     # print every request and how long it took
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# trial 4: there's no console window, so what it would have printed goes to a log instead
if (-not $NoBrowser) {
  try {
    $ConsoleLog = Join-Path $env:ProgramData 'showcase_fleet\window_console.log'
    New-Item -ItemType Directory -Force -Path (Split-Path $ConsoleLog) | Out-Null
    if ((Test-Path $ConsoleLog) -and (Get-Item $ConsoleLog).Length -gt 1MB) { Remove-Item $ConsoleLog -Force }
    Start-Transcript -Path $ConsoleLog -Append | Out-Null
  } catch { }
}

$Root    = Split-Path $PSScriptRoot -Parent
$UiDir   = Join-Path $PSScriptRoot 'ui'
# "$(...)" makes plain text: text straight from Get-Content carries file details that ConvertTo-Json
# in Windows PowerShell 5.1 tries to write out in full, which never finishes
$Version = "$(Get-Content (Join-Path $PSScriptRoot 'version.txt') -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
if (-not $Version) { $Version = 'dev' }
$Token   = [guid]::NewGuid().ToString('N')
$me      = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
$IsAdmin = $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -and -not $ReadOnly
# trial 10 (23 Nov 2026): a NUC enrolled in Fleet online is managed from the dashboard. Its modules are the agent's
# job, so the window doesn't install, remove or apply them (a local change would be undone at 1am); tools still work.
$Managed = Test-Path (Join-Path $env:ProgramData 'showcase_fleet\agent\token.dat')
function Deny-Managed { Json @{ error = 'This NUC is managed from Showcase Fleet online (document.showcase.space/fleet): tick or untick its modules there. They go in at 1am, or straight away with Apply changes now.' } 409 }
$PauseFile  = Join-Path $env:ProgramData 'ShowcasePause.txt'   # shared with Showcase Pin and Kiosk (Ctrl+Alt+Q)
$IdleLimit  = [TimeSpan]::FromMinutes(3)
$script:PauseWritten = $null
$script:LastSeen = $null
$script:JobSeq = 0
$Jobs = @{}

# files copied from a download are marked "from the internet"; clear that so nothing is blocked
Get-ChildItem $Root -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue

# shared helpers, including this NUC's own settings (nuc.config)
. (Join-Path $PSScriptRoot 'common.ps1')

# trial 7: with no console window a failure to start would be invisible, so say it in a box (a tech just opened Fleet)
trap {
  if (-not $NoBrowser) {
    try { [void][Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
          [Windows.Forms.MessageBox]::Show("Showcase Fleet could not start: $($_.Exception.Message)`n`nThe details are in C:\ProgramData\showcase_fleet\window_console.log", 'Showcase Fleet') | Out-Null } catch { }
  }
  break
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -Namespace FleetNative -Name Dpi -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();'
[FleetNative.Dpi]::SetProcessDPIAware() | Out-Null

# ---------------------------------------------------------------- catalogue

function Read-Catalogue($folder, $file) {
  $dir = Join-Path $Root $folder
  if (-not (Test-Path $dir)) { return @() }
  @(Get-ChildItem $dir -Directory | ForEach-Object {
    $f = Join-Path $_.FullName $file
    if (Test-Path $f) {
      $item = Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json
      $item | Add-Member -NotePropertyName dir -NotePropertyValue $_.FullName -Force
      $item
    }
  } | Sort-Object { [int]$_.order })
}

function Get-Modules { Read-Catalogue 'modules' 'module.json' }
function Get-Tools   { Read-Catalogue 'tools' 'tool.json' }

# groups, and the modules and tools still to come, so the window shows the whole set
function Get-Catalogue {
  $f = Join-Path $PSScriptRoot 'catalogue.json'
  if (-not (Test-Path $f)) { return $null }
  $c = ConvertTo-Plain (Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json)
  foreach ($p in @($c.planned)) {
    if (-not $p.detect) { continue }
    $path = Join-Path $env:ProgramData $p.detect
    if (Test-Path $path -PathType Leaf) {
      $p.found = $true
      $p.foundVersion = "$(Get-Content $path -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
    } elseif (Test-Path $path) { $p.found = $true }
  }
  $c
}

# ---------------------------------------------------------------- the window on this NUC

$WindowDir = Join-Path $env:ProgramData 'showcase_fleet\window'
$RunningInstalled = [IO.Path]::GetFullPath($Root).TrimEnd('\') -ieq [IO.Path]::GetFullPath($WindowDir).TrimEnd('\')

# A version as a number that sorts: any confirmed release (DDMMYY, or DDMMYY_v2 for a second one that day) above any
# trial, confirmed ones by date, trials by their number (trial7_241026 above trial6_241026). Unknown is 0.
# So a trial never replaces a confirmed release, an older trial never replaces a newer one, and a newer one always does.
function Get-VersionRank($v) {
  if ("$v" -match '^(\d\d)(\d\d)(\d\d)(?:_v(\d+))?$') { return 1000000000000 + [long]"$($Matches[3])$($Matches[2])$($Matches[1])" * 100 + $(if ($Matches[4]) { [int]$Matches[4] } else { 1 }) }
  if ("$v" -match '^trial(\d+)') { return [long]$Matches[1] }
  0
}

function Get-InstalledWindow {
  $f = Join-Path $WindowDir 'installed.json'
  if (-not (Test-Path $f)) { return @{ installed = $false } }
  try { $i = Get-Content $f -Raw | ConvertFrom-Json; @{ installed = $true; version = "$($i.version)"; at = "$($i.installed)" } }
  catch { @{ installed = $true; version = '' } }
}

function Get-ModuleStatus($m) {
  if ($Trace) { Write-Host "    status: $($m.id)" }
  try {
    $s = & (Join-Path $m.dir 'status.ps1')
    if ($s -is [hashtable]) { return (ConvertTo-Plain $s) }
    return @{ installed = $false; detail = 'Could not read its status.' }
  } catch { return @{ installed = $false; detail = "Could not read its status: $($_.Exception.Message)" } }
}

# Status comes from module scripts; rebuild it from plain values so nothing in it can hang ConvertTo-Json.
function ConvertTo-Plain($v, [int]$depth = 0) {
  if ($null -eq $v -or $depth -gt 5) { return $null }
  if ($v -is [string] -or $v -is [char]) { return "$v" }
  if ($v -is [bool] -or $v -is [int] -or $v -is [long] -or $v -is [double] -or $v -is [decimal]) { return $v }
  if ($v -is [datetime]) { return $v.ToString('s') }
  if ($v -is [System.Collections.IDictionary]) {
    $h = [ordered]@{}
    foreach ($k in $v.Keys) { $h["$k"] = ConvertTo-Plain $v[$k] ($depth + 1) }
    return $h
  }
  if ($v -is [System.Collections.IEnumerable]) { return ,@($v | ForEach-Object { ConvertTo-Plain $_ ($depth + 1) }) }
  if ($v -is [pscustomobject]) {
    $h = [ordered]@{}
    foreach ($p in $v.PSObject.Properties) { $h[$p.Name] = ConvertTo-Plain $p.Value ($depth + 1) }
    return $h
  }
  "$v"
}

function Get-ModuleLog($m) {
  if (-not $m.log) { return @('This module keeps no log.') }
  $path = Join-Path $env:ProgramData $m.log
  if (-not (Test-Path $path)) { return @("No log yet ($path).") }
  @(Get-Content $path -Tail 200 -Encoding UTF8 | ForEach-Object { "$_" })
}

# trial 7: each setting checked against its declared type before an install, so an empty or odd value can't
# quietly fall back to the script's default (unticking every Bluesound day used to bring back Mon and Fri)
function Test-Settings($declared, $given) {
  $days = 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
  foreach ($d in @($declared)) {
    if (-not $d) { continue }
    $p = if ($given) { $given.PSObject.Properties[$d.key] } else { $null }
    $v = if ($p) { $p.Value } else { $null }
    switch ("$($d.type)") {
      'time'   { if ("$v" -and "$v" -notmatch '^\d{1,2}:\d\d$') { return "$($d.label): use a 24-hour time like 18:30." } }
      'days'   { $list = @($v | Where-Object { $_ }); if (-not $list.Count) { return "$($d.label): pick at least one day." }
                 foreach ($x in $list) { if ("$x" -notin $days) { return "$($d.label): '$x' is not a day." } } }
      'select' { if ($null -ne $v -and "$v" -ne '' -and "$v" -notin @($d.options | ForEach-Object { "$($_.value)" })) { return "$($d.label): '$v' is not one of the choices." } }
      'number' { if ("$v") { $n = 0; if (-not [int]::TryParse("$v", [ref]$n)) { return "$($d.label): must be a whole number." }
                 if (($null -ne $d.min -and $n -lt $d.min) -or ($null -ne $d.max -and $n -gt $d.max)) { return "$($d.label): must be between $($d.min) and $($d.max)." } } }
      'list'   { foreach ($x in @($v)) { if ("$x" -and "$x" -notmatch '^[\w.:-]+$') { return "$($d.label): '$x' doesn't look right." } } }
    }
  }
  $null
}

# only the settings a module declares are passed on to its script
function ConvertTo-Params($declared, $given) {
  $h = @{}
  if (-not $given) { return $h }
  foreach ($d in @($declared)) {
    if (-not $d) { continue }
    $p = $given.PSObject.Properties[$d.key]
    if ($p -and $null -ne $p.Value -and "$($p.Value)" -ne '') { $h[$d.key] = $p.Value }
  }
  $h
}

# ---------------------------------------------------------------- jobs (installs, tools)

$JobBlock = {
  param($File, $Params)
  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
  $ProgressPreference = 'SilentlyContinue'
  if (-not $Params) { $Params = @{} }
  try {
    & $File @Params *>&1 | ForEach-Object {
      if ($_ -is [System.Management.Automation.ErrorRecord]) { "[FAIL] $($_.Exception.Message)" } else { "$_" }
    }
  } catch { "[FAIL] $($_.Exception.Message)" }
}

function Start-FleetJob($title, $file, $params) {
  $script:JobSeq++
  $id = "$($script:JobSeq)"
  $j = Start-Job -ScriptBlock $JobBlock -ArgumentList $file, $params
  $Jobs[$id] = @{ job = $j; title = $title; started = Get-Date }
  Write-Host "  $(Get-Date -Format HH:mm:ss)  started: $title"
  $id
}

function Get-FleetJob($id) {
  $e = $Jobs[$id]
  if (-not $e) { return @{ id = $id; done = $true; lines = @('[FAIL] That job is no longer known. Refresh the window.') } }
  # a script that stops to ask a question would wait forever in a background job: end it and say so
  if ($e.job.State -in 'Blocked', 'Suspended', 'Disconnected') {
    Stop-Job -Job $e.job -ErrorAction SilentlyContinue
    $e.stuck = $true
  }
  $lines = @(Receive-Job -Job $e.job -Keep -ErrorAction SilentlyContinue | ForEach-Object { "$_" })
  if ($e.stuck) { $lines += '[FAIL] It stopped to ask a question, which a background job cannot answer. Stopped.' }
  $done = $e.job.State -in 'Completed', 'Failed', 'Stopped', 'Blocked', 'Suspended', 'Disconnected'
  @{ id = $id; title = $e.title; done = $done; lines = $lines }
}

# trial 7: one change at a time, so two installs (each launcher removes the other) can't run together
function Deny-Busy {
  if (Test-JobsRunning) { return (Json @{ error = 'Something is still running in Fleet. Wait for it to finish, then try again.' } 409) }
  $null
}

function Remove-OldJobs {
  foreach ($k in @($Jobs.Keys)) {
    $e = $Jobs[$k]
    if ($e.job.State -ne 'Running' -and ((Get-Date) - $e.started).TotalMinutes -gt 30) { Remove-Job -Job $e.job -Force; $Jobs.Remove($k) }
  }
}

function Test-JobsRunning { @($Jobs.Values | Where-Object { $_.job.State -eq 'Running' }).Count -gt 0 }

# ---------------------------------------------------------------- pause Showcase Pin and Kiosk

function Get-PauseUntil {
  try {
    if (Test-Path $PauseFile) {
      $d = New-Object DateTime ([long](Get-Content $PauseFile -Raw).Trim())
      if ($d -gt (Get-Date)) { return $d }
    }
  } catch { }
  $null
}

function Set-Pause([int]$Minutes) {
  if ($Minutes -le 0) {
    Remove-Item $PauseFile -Force -ErrorAction SilentlyContinue
    $script:PauseWritten = $null
    return
  }
  $ticks = "$((Get-Date).AddMinutes($Minutes).Ticks)"
  Set-Content -Path $PauseFile -Value $ticks -Encoding ASCII
  # the display user's Ctrl+Alt+Q has to be able to end it early
  & icacls.exe $PauseFile /grant '*S-1-5-32-545:M' | Out-Null
  $script:PauseWritten = $ticks
}

function Test-ShowcaseTools {
  [bool](Get-ScheduledTask -TaskName 'Showcase Pin', 'Showcase Kiosk' -ErrorAction SilentlyContinue)
}

# ---------------------------------------------------------------- browser windows

function Find-Browser {
  @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
  ) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
}

# Every window gets its own browser profile, so it never opens as a tab inside Showcase's Chrome.
function Open-Window($profileName, [string[]]$flags) {
  $browser = Find-Browser
  $dataDir = Join-Path $env:TEMP $profileName
  $all = @("--user-data-dir=`"$dataDir`"", '--no-first-run', '--no-default-browser-check') + $flags
  if ($browser) { Start-Process -FilePath $browser -ArgumentList $all | Out-Null; return $true }
  $false
}

# with the support screen installed, the Fleet window opens on it (the hidden screen), centred, never on the TV
function Get-FleetWindowPlace {
  $w = 1280; $h = 880
  try { $s = Get-Content (Join-Path $FleetData 'support_screen\state.json') -Raw | ConvertFrom-Json } catch { $s = $null }
  $scr = $null
  if ($s -and $s.supportScreen) {
    $name = ("$($s.supportScreen)" -split ' ')[0]
    $scr = [System.Windows.Forms.Screen]::AllScreens | Where-Object { $_.DeviceName -eq $name } | Select-Object -First 1
  }
  if (-not $scr) { return @("--window-size=$w,$h") }
  $b = $scr.Bounds
  $w = [Math]::Min($w, $b.Width); $h = [Math]::Min($h, $b.Height)
  @("--window-position=$($b.X + [int](($b.Width - $w) / 2)),$($b.Y + [int](($b.Height - $h) / 2))", "--window-size=$w,$h")
}

# hands over to the copy installed on this NUC: app\handover.ps1 (in that copy) waits for this server to stop, deletes
# this folder if it's one a tech unzipped (Get-CopiedFleetFolder), then opens Fleet from ProgramData
function Start-Handover {
  $h = Join-Path $WindowDir 'app\handover.ps1'
  Start-Process powershell.exe -WindowStyle Hidden -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$h`" -OldPid $PID -Source `"$Root`""
  $script:HandOver = $true
}

function Test-CanHandOver {
  if ($RunningInstalled -or $NoBrowser) { return $false }
  $have = Get-InstalledWindow
  $have.installed -and $have.version -eq $Version -and (Test-Path (Join-Path $WindowDir 'app\handover.ps1'))
}

function Get-Displays {
  $i = 0
  $open = @(Get-ScreenTestProcesses | ForEach-Object { if ($_.CommandLine -match 'showcase_fleet_screen_(\d+)') { [int]$Matches[1] } })
  @([System.Windows.Forms.Screen]::AllScreens | ForEach-Object {
    $i++
    [ordered]@{
      index = $i; name = $_.DeviceName.TrimStart('\', '.'); primary = $_.Primary
      x = $_.Bounds.X; y = $_.Bounds.Y; width = $_.Bounds.Width; height = $_.Bounds.Height
      testOpen = $open -contains $i
    }
  })
}

function Get-ScreenTestProcesses {
  @(Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='msedge.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like '*showcase_fleet_screen_*' })
}

function Open-ScreenTest([int]$index, [string]$pattern) {
  $screens = [System.Windows.Forms.Screen]::AllScreens
  if ($index -lt 1 -or $index -gt $screens.Count) { throw "There is no display $index." }
  if ($pattern -notmatch '^[a-z0-9_]+$') { $pattern = 'grid' }
  Close-ScreenTests $index
  $s = $screens[$index - 1].Bounds
  $url = "http://127.0.0.1:$Port/ui/screen_test.html?p=$pattern&d=$index"
  if (-not (Open-Window "showcase_fleet_screen_$index" @("--window-position=$($s.X),$($s.Y)", "--window-size=$($s.Width),$($s.Height)", '--kiosk', $url))) {
    throw 'Chrome or Edge was not found on this NUC.'
  }
}

function Close-ScreenTests($index) {
  Get-ScreenTestProcesses | Where-Object { "$index" -eq 'all' -or $_.CommandLine -like "*showcase_fleet_screen_$index*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

# ---------------------------------------------------------------- state for the window

function Get-State {
  $pause = Get-PauseUntil
  [ordered]@{
    version   = $Version
    computer  = $env:COMPUTERNAME
    user      = $env:USERNAME
    admin     = $IsAdmin
    managed   = $Managed
    readOnly  = [bool]$ReadOnly
    ips       = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                  Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
                  ForEach-Object { $_.IPAddress })
    clock     = (Get-Date).ToString('ddd d MMM, h:mm tt')
    pauseUntil = $(if ($pause) { $pause.ToString('h:mm tt') } else { $null })
    showcaseTools = Test-ShowcaseTools
    modules   = @(Get-Modules | ForEach-Object {
      [ordered]@{
        id = $_.id; name = $_.name; summary = $_.summary; about = $_.about; version = $_.version; kind = $_.kind
        confirmInstall = $_.confirmInstall; removeNote = $_.removeNote
        settings = @($_.settings | Where-Object { $_ }); actions = @($_.actions | Where-Object { $_ })
        hasLog = [bool]$_.log; status = Get-ModuleStatus $_
      }
    })
    tools     = @(Get-Tools | ForEach-Object {
      [ordered]@{
        id = $_.id; name = $_.name; summary = $_.summary; kind = $_.kind; runLabel = $_.runLabel
        params = @($_.params | Where-Object { $_ }); actions = @($_.actions | Where-Object { $_ })
      }
    })
    running   = @($Jobs.Keys | Where-Object { $Jobs[$_].job.State -eq 'Running' } | ForEach-Object { @{ id = $_; title = $Jobs[$_].title } })
    catalogue = Get-Catalogue
    # autoJob only while it runs, so a reload doesn't replay it and a failed one leaves "Put it on this NUC"
    window    = (Get-InstalledWindow) + @{ runningHere = $RunningInstalled; path = $WindowDir; skipped = $script:AutoSkipped
                  autoJob = $(if ($script:AutoJob -and $Jobs[$script:AutoJob] -and $Jobs[$script:AutoJob].job.State -eq 'Running') { $script:AutoJob } else { $null }) }
  }
}

# ---------------------------------------------------------------- HTTP

function Json($obj, [int]$status = 200) {
  @{ status = $status; type = 'application/json; charset=utf-8'; body = (ConvertTo-Json -InputObject $obj -Depth 8 -Compress) }
}

$Types = @{
  '.html' = 'text/html; charset=utf-8'; '.css' = 'text/css; charset=utf-8'; '.js' = 'application/javascript; charset=utf-8'
  '.ttf' = 'font/ttf'; '.svg' = 'image/svg+xml'; '.png' = 'image/png'; '.ico' = 'image/x-icon'; '.json' = 'application/json; charset=utf-8'
}

function Get-Static($rel) {
  $full = [IO.Path]::GetFullPath((Join-Path $UiDir $rel))
  if (-not $full.StartsWith($UiDir.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path $full -PathType Leaf)) { return Json @{ error = 'Not found' } 404 }
  $type = $Types[[IO.Path]::GetExtension($full).ToLower()]
  if (-not $type) { $type = 'application/octet-stream' }
  @{ status = 200; type = $type; body = [IO.File]::ReadAllBytes($full) }
}

function Deny-ReadOnly {
  Json @{ error = 'Read-only: close this and open Fleet Manager with the .bat file, which asks for admin.' } 403
}

function Invoke-Route($method, $path, $headers, $bodyText, $query = '') {
  # trial 7: only this window's own address. A web page can't reach the server through another name (DNS rebinding).
  $hostHeader = "$($headers['host'])"
  if ($hostHeader -and $hostHeader -notin "127.0.0.1:$Port", "localhost:$Port") { return Json @{ error = 'Forbidden' } 403 }
  if ($path -eq '/') {
    # trial 7: the page (and the token in it) only for the window Fleet opened, whose address carries the token.
    # Read-only test mode can't change anything, so it opens without one.
    if (-not $ReadOnly -and "&$query&" -notlike "*&t=$Token&*") {
      return @{ status = 403; type = 'text/plain; charset=utf-8'; body = 'Open Showcase Fleet from its desktop shortcut.' }
    }
    # trial3_241026 -> "Trial 3 (24 Oct 2026)"; a confirmed 011126 -> "v011126" (English month names, same as the window's)
    $label = if ($Version -match '^trial(\d+)(?:_(\d\d)(\d\d)(\d\d))?$') {
      "Trial $($Matches[1])$(if ($Matches[2]) { ' (' + [int]$Matches[2] + ' ' + [Globalization.CultureInfo]::InvariantCulture.DateTimeFormat.GetAbbreviatedMonthName([int]$Matches[3]) + ' 20' + $Matches[4] + ')' })"
    } else { "v$Version" }
    $html = [IO.File]::ReadAllText((Join-Path $UiDir 'index.html')).Replace('{{TOKEN}}', $Token).Replace('{{VERSION_LABEL}}', $label).Replace('{{VERSION}}', $Version)
    return @{ status = 200; type = 'text/html; charset=utf-8'; body = $html }
  }
  if ($path.StartsWith('/ui/')) { return Get-Static $path.Substring(4) }
  if (-not $path.StartsWith('/api/')) { return Json @{ error = 'Not found' } 404 }
  if ($headers['x-fleet-token'] -ne $Token) { return Json @{ error = 'Forbidden' } 403 }
  $script:LastSeen = Get-Date

  $body = $null
  if ($bodyText) { try { $body = $bodyText | ConvertFrom-Json } catch { return Json @{ error = 'Bad request' } 400 } }
  $parts = $path.Substring(5).Split('/')

  switch ($parts[0]) {
    'state'    { return Json (Get-State) }
    'job'      { return Json (Get-FleetJob $parts[1]) }
    'displays' { return Json @{ displays = @(Get-Displays) } }

    'module' {
      $m = Get-Modules | Where-Object { $_.id -eq $parts[1] }
      if (-not $m) { return Json @{ error = 'No such module' } 404 }
      if ($parts[2] -eq 'log') { return Json @{ lines = @(Get-ModuleLog $m) } }
      if ($method -ne 'POST') { break }
      # a settings module (Baseline): checking reads only; applying the ticked ones needs admin
      if ($parts[2] -eq 'settings' -and $m.settingsScript) {
        $apply = (@($body.apply) | Where-Object { "$_" -match '^[a-z0-9_]+$' }) -join ','
        if ($apply -and -not $IsAdmin) { return Deny-ReadOnly }
        if ($apply -and $Managed) { return Deny-Managed }
        if ($apply) { $busy = Deny-Busy; if ($busy) { return $busy } }
        $params = @{}
        if ($apply) { $params[$m.applyParam] = $apply }
        return Json @{ job = Start-FleetJob "$($m.name)$(if ($apply) { ': apply' } else { ': check' })" (Join-Path $m.dir $m.settingsScript) $params }
      }
      # actions that only read (a log, a check) work in read-only mode and alongside other jobs
      if ($parts[2] -eq 'action') {
        $a = @($m.actions) | Where-Object { $_ -and $_.id -eq $parts[3] }
        if (-not $a) { return Json @{ error = 'No such action' } 404 }
        if (-not $a.readOnly) {
          if (-not $IsAdmin) { return Deny-ReadOnly }
          $busy = Deny-Busy; if ($busy) { return $busy }
        }
        return Json @{ job = Start-FleetJob "$($m.name): $($a.label)" (Join-Path $m.dir $a.script) @{} }
      }
      if (-not $IsAdmin) { return Deny-ReadOnly }
      if ($Managed -and $parts[2] -in 'install', 'remove') { return Deny-Managed }
      $busy = Deny-Busy; if ($busy) { return $busy }
      if ($parts[2] -eq 'install') {
        $bad = Test-Settings $m.settings $body.settings
        if ($bad) { return Json @{ error = $bad } 400 }
        $params = ConvertTo-Params $m.settings $body.settings
        return Json @{ job = Start-FleetJob "Install $($m.name)" (Join-Path $m.dir 'install.ps1') $params }
      }
      if ($parts[2] -eq 'remove') { return Json @{ job = Start-FleetJob "Remove $($m.name)" (Join-Path $m.dir 'remove.ps1') @{} } }
    }

    'tool' {
      $t = Get-Tools | Where-Object { $_.id -eq $parts[1] }
      if (-not $t -or $method -ne 'POST') { return Json @{ error = 'No such tool' } 404 }
      if ($parts[2] -eq 'run') {
        $params = ConvertTo-Params $t.params $body.params
        # a tool that can also change things (NUC settings) only does so as admin
        if ($t.applyParam -and $params[$t.applyParam] -and -not $IsAdmin) { return Deny-ReadOnly }
        if ($t.applyParam -and $params[$t.applyParam]) { $busy = Deny-Busy; if ($busy) { return $busy } }
        return Json @{ job = Start-FleetJob $t.name (Join-Path $t.dir 'run.ps1') $params }
      }
      if ($parts[2] -eq 'action') {
        $a = @($t.actions) | Where-Object { $_ -and $_.id -eq $parts[3] }
        if (-not $a) { return Json @{ error = 'No such action' } 404 }
        if ($a.changes -and -not $IsAdmin) { return Deny-ReadOnly }
        if ($a.changes) { $busy = Deny-Busy; if ($busy) { return $busy } }
        return Json @{ job = Start-FleetJob "$($t.name): $($a.label)" (Join-Path $t.dir $a.script) @{} }
      }
    }

    'screen' {
      if ($method -ne 'POST') { break }
      # a test pattern covers a live screen, so it needs admin like anything else that shows on the display
      if ($parts[1] -eq 'open') {
        if (-not $IsAdmin) { return Deny-ReadOnly }
        Open-ScreenTest ([int]$body.display) "$($body.pattern)"; return Json @{ ok = $true }
      }
      if ($parts[1] -eq 'close') { Close-ScreenTests "$($body.display)"; return Json @{ ok = $true } }
    }

    'pause' {
      if ($method -ne 'POST') { break }
      if (-not $IsAdmin) { return Deny-ReadOnly }
      Set-Pause ([int]$body.minutes)
      return Json @{ ok = $true }
    }

    # This NUC: its own settings in nuc.config. The Showcase URL is shown with its keys hidden unless an admin asks.
    'nuc' {
      if ($method -eq 'GET') {
        $c = Get-NucConfig
        $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
        $monitorId = "$(Get-Content (Join-Path $env:ProgramData 'showcase-monitor\nuc-id.txt') -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
        return Json @{
          config = [ordered]@{ NucId = "$($c.NucId)"; LauncherMode = "$($c.LauncherMode)"; SiteRole = "$($c.SiteRole)"; ScreenType = "$($c.ScreenType)"; OckNumber = "$($c.OckNumber)"; Notes = "$($c.Notes)" }
          urlSet = [bool]$c.ShowcaseUrl; urlShown = Hide-UrlKeys $c.ShowcaseUrl
          detected = [ordered]@{ computer = $env:COMPUTERNAME; model = "$($cs.Manufacturer) $($cs.Model)".Trim(); serial = "$($bios.SerialNumber)".Trim(); nucMonitorId = $monitorId }
          path = $NucConfigPath; exists = (Test-Path $NucConfigPath)
        }
      }
      if (-not $IsAdmin) { return Deny-ReadOnly }
      if ($parts[1] -eq 'reveal') { return Json @{ url = "$((Get-NucConfig).ShowcaseUrl)" } }
      # trial 7: what was found stays here; the window only sees it with the keys hidden, and Save can use it
      if ($parts[1] -eq 'import') {
        $found = Find-ShowcaseUrl
        if (-not $found) { return Json @{ error = 'No Showcase URL found on this NUC (no Showcase window, Startup Kiosk config or startup bat with one). Paste it in.' } 404 }
        $script:ImportedUrl = $found.url
        return Json @{ urlShown = Hide-UrlKeys $found.url; from = "$($found.from)" }
      }
      if ($parts[1] -eq 'save') {
        $c = Get-NucConfig
        $in = $body.config
        # names and numbers go into launch lines and alerts: letters, digits and / _ - . ( ) [ ] and spaces only
        foreach ($k in 'NucId', 'OckNumber') {
          if ($null -ne $in.$k) {
            $v = "$($in.$k)".Trim()
            if ($v -notmatch '^[A-Za-z0-9/_ .()\[\]-]*$') { return Json @{ error = "$k can only have letters, numbers, spaces and / _ - . ( ) [ ]." } 400 }
            $c[$k] = $v
          }
        }
        if ($null -ne $in.Notes) { $c.Notes = ("$($in.Notes)" -replace '[\r\n=]', ' ').Trim() }
        if ("$($in.LauncherMode)" -in 'kiosk', 'console', 'troubleshoot') { $c.LauncherMode = "$($in.LauncherMode)" }
        if ("$($in.SiteRole)" -in 'normal', 'lead') { $c.SiteRole = "$($in.SiteRole)" }
        if ("$($in.ScreenType)" -in '', 'tv', 'led', 'touch', 'headless', 'video') { $c.ScreenType = "$($in.ScreenType)" }
        $url = "$($in.ShowcaseUrl)".Trim()
        if (-not $url -and $in.useImported -and $script:ImportedUrl) { $url = $script:ImportedUrl }
        if ($url) {
          # a Showcase address with its keys; never ! or % or ^ (the startup bat would misread them)
          if ($url -notmatch '^https://(app|remote)\.showcase\.space/[^\s"!%^]+$') { return Json @{ error = 'That is not a Showcase URL: it should start https://app.showcase.space/ and have no spaces.' } 400 }
          $c.ShowcaseUrl = Remove-PollingParam $url
        }
        Save-NucConfig $c
        return Json @{ ok = $true; urlShown = Hide-UrlKeys $c.ShowcaseUrl }
      }
    }

    'window' {
      if ($method -ne 'POST') { break }
      if (-not $IsAdmin) { return Deny-ReadOnly }
      $busy = Deny-Busy; if ($busy) { return $busy }
      if ($parts[1] -eq 'install') { return Json @{ job = Start-FleetJob 'Put Showcase Fleet on this NUC' (Join-Path $PSScriptRoot 'install_window.ps1') @{ Source = $Root } } }
      if ($parts[1] -eq 'remove') { return Json @{ job = Start-FleetJob 'Take Showcase Fleet off this NUC' (Join-Path $PSScriptRoot 'remove_window.ps1') @{} } }
      if ($parts[1] -eq 'handover') {
        if (-not (Test-CanHandOver)) { return Json @{ error = 'This version of Showcase Fleet is not on this NUC yet.' } 400 }
        $del = Get-CopiedFleetFolder $Root
        Start-Handover
        return Json @{ ok = $true; path = $WindowDir; deleting = $del }
      }
    }
  }
  Json @{ error = 'Not found' } 404
}

function Read-Request($client) {
  $client.ReceiveTimeout = 5000
  $stream = $client.GetStream()
  $buf = New-Object byte[] 8192
  $ms = New-Object IO.MemoryStream
  $headerEnd = -1
  while ($headerEnd -lt 0) {
    $n = $stream.Read($buf, 0, $buf.Length)
    if ($n -le 0) { return $null }
    $ms.Write($buf, 0, $n)
    # one character per byte, so the index is the byte offset
    $headerEnd = [Text.Encoding]::GetEncoding(28591).GetString($ms.ToArray()).IndexOf("`r`n`r`n")
    if ($headerEnd -lt 0 -and $ms.Length -gt 65536) { return $null }
  }
  $all = $ms.ToArray()
  $lines = [Text.Encoding]::ASCII.GetString($all, 0, $headerEnd) -split "`r`n"
  $first = $lines[0] -split ' '
  $headers = @{}
  foreach ($h in ($lines | Select-Object -Skip 1)) {
    $i = $h.IndexOf(':')
    if ($i -gt 0) { $headers[$h.Substring(0, $i).Trim().ToLower()] = $h.Substring($i + 1).Trim() }
  }
  $len = 0
  if ($headers['content-length']) { $len = [int]$headers['content-length'] }
  $body = New-Object IO.MemoryStream
  $have = $all.Length - ($headerEnd + 4)
  if ($have -gt 0) { $body.Write($all, $headerEnd + 4, $have) }
  while ($body.Length -lt $len) {
    $n = $stream.Read($buf, 0, [Math]::Min($buf.Length, $len - $body.Length))
    if ($n -le 0) { break }
    $body.Write($buf, 0, $n)
  }
  $target = $first[1]
  $query = ''
  $q = $target.IndexOf('?')
  if ($q -ge 0) { $query = $target.Substring($q + 1); $target = $target.Substring(0, $q) }
  @{ method = $first[0]; path = [Uri]::UnescapeDataString($target); query = $query; headers = $headers; body = [Text.Encoding]::UTF8.GetString($body.ToArray()); stream = $stream }
}

function Send-Response($stream, $res) {
  $bytes = $res.body
  if ($bytes -is [string]) { $bytes = [Text.Encoding]::UTF8.GetBytes($bytes) }
  if ($null -eq $bytes) { $bytes = [byte[]]@() }
  $reason = @{ 200 = 'OK'; 400 = 'Bad Request'; 403 = 'Forbidden'; 404 = 'Not Found'; 500 = 'Server Error' }[[int]$res.status]
  $head = "HTTP/1.1 $($res.status) $reason`r`nContent-Type: $($res.type)`r`nContent-Length: $($bytes.Length)`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nConnection: close`r`n`r`n"
  $hb = [Text.Encoding]::ASCII.GetBytes($head)
  $stream.Write($hb, 0, $hb.Length)
  if ($bytes.Length) { $stream.Write($bytes, 0, $bytes.Length) }
  $stream.Flush()
}

# ---------------------------------------------------------------- run

$listener = $null
for ($p = $Port; $p -lt $Port + 10; $p++) {
  try { $l = New-Object Net.Sockets.TcpListener ([Net.IPAddress]::Loopback, $p); $l.Start(); $listener = $l; $Port = $p; break } catch { }
}
if (-not $listener) { throw "Ports $Port to $($Port + 9) are all in use. Close the other Fleet Manager window first." }

$address = "http://127.0.0.1:$Port/"
Write-Host ''
Write-Host "  Showcase Fleet $Version" -ForegroundColor Cyan
Write-Host "  Running at $address on $env:COMPUTERNAME$(if (-not $IsAdmin) { ', read-only' })"
Write-Host '  Close the Fleet window and this stops by itself. Or press Ctrl+C here.'
Write-Host ''

$script:AutoJob = $null
$script:AutoSkipped = $null
$script:HandOver = $false
if ($IsAdmin -and (Test-CanHandOver)) {
  # this version is already on the NUC: open that one instead, and tidy this copy away
  Write-Host '  This version is already on this NUC; opening it from there.'
  Start-Handover
  $listener.Stop()
  exit
}
if ($IsAdmin) {
  Protect-FleetData
  # the installed copy puts its shortcuts back if they've gone (Jordan, 24 Oct: the shortcut always on the desktop)
  if ($RunningInstalled -and -not (Test-Path (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'Showcase Fleet.lnk'))) {
    try { Set-FleetShortcuts $WindowDir $Version; Write-Host '  Put the desktop and Start menu shortcuts back.' } catch { }
  }
  # Showcase Pin would otherwise push this window behind Showcase straight away. A longer pause already set
  # (troubleshooting mode sets 60 minutes) is left alone, and then it isn't ours to end when this window closes.
  $existing = Get-PauseUntil
  if (-not $existing -or $existing -lt (Get-Date).AddMinutes(30)) { Set-Pause 30 }
  if (Test-ShowcaseTools) { Write-Host '  Showcase Pin and Kiosk paused so the window can sit on top.' }
  # opened from a copied folder: put Fleet on the NUC, unless the one already there is newer
  if (-not $RunningInstalled) {
    $have = Get-InstalledWindow
    if ($have.installed -and (Get-VersionRank $have.version) -gt (Get-VersionRank $Version)) {
      $script:AutoSkipped = "A newer Showcase Fleet ($($have.version)) is already on this NUC than this copy ($Version). Open it from the desktop shortcut instead."
    } elseif (-not $have.installed -or $have.version -ne $Version) {
      $script:AutoJob = Start-FleetJob 'Put Showcase Fleet on this NUC' (Join-Path $PSScriptRoot 'install_window.ps1') @{ Source = $Root }
    }
  }
}
if (-not $NoBrowser) {
  $windowAddress = "${address}?t=$Token"
  if (-not (Open-Window 'showcase_fleet_manager_window' (@("--app=$windowAddress") + (Get-FleetWindowPlace)))) { Start-Process $windowAddress }
}

# Browsers open spare connections that may never send anything. Every connection waits in $open
# until a request has actually arrived on it, so one idle connection never holds up the rest.
$open = New-Object Collections.ArrayList
try {
  while ($true) {
    while ($listener.Pending()) { [void]$open.Add(@{ client = $listener.AcceptTcpClient(); since = Get-Date }) }
    $served = $false
    foreach ($c in @($open)) {
      $client = $c.client
      $ready = $client.Available -gt 0
      $gone = -not $ready -and $client.Client.Poll(0, [Net.Sockets.SelectMode]::SelectRead)   # closed by the browser
      if (-not $ready -and -not $gone -and ((Get-Date) - $c.since).TotalSeconds -lt 30) { continue }
      $open.Remove($c)
      if ($ready) {
        $served = $true
        try {
          $sw = [Diagnostics.Stopwatch]::StartNew()
          $req = Read-Request $client
          if ($req) {
            if ($Trace) { Write-Host "  > $($req.method) $($req.path)" }
            try { $res = Invoke-Route $req.method $req.path $req.headers $req.body $req.query }
            catch { $res = Json @{ error = $_.Exception.Message } 500 }
            Send-Response $req.stream $res
            if ($Trace) { Write-Host "  < $($res.status) $($req.path) $($sw.ElapsedMilliseconds) ms" }
          }
        } catch {
          Write-Host "  Request failed: $($_.Exception.Message)" -ForegroundColor DarkYellow
        }
      }
      $client.Close()
    }
    if ($script:HandOver) { Write-Host '  Handed over to the installed copy. Stopping.'; break }
    if (-not $served) {
      Start-Sleep -Milliseconds 15
      if ($script:LastSeen -and ((Get-Date) - $script:LastSeen) -gt $IdleLimit -and -not (Test-JobsRunning)) {
        Write-Host '  The window was closed. Stopping.'
        break
      }
    }
    Remove-OldJobs
  }
} finally {
  foreach ($c in $open) { $c.client.Close() }
  $listener.Stop()
  # put Showcase back on top, unless someone has changed the pause since (or the installed copy is taking over)
  if (-not $script:HandOver -and $script:PauseWritten -and (Test-Path $PauseFile) -and ((Get-Content $PauseFile -Raw).Trim() -eq $script:PauseWritten)) {
    Remove-Item $PauseFile -Force -ErrorAction SilentlyContinue
  }
  Close-ScreenTests 'all'
  Get-Job | Remove-Job -Force -ErrorAction SilentlyContinue
}
