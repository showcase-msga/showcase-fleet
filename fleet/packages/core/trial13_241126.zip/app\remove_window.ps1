# Showcase Fleet trial 7 (24 Oct 2026): takes the Fleet window off this NUC (the shortcuts, the taskbar pin and
# C:\ProgramData\showcase_fleet\window). Installed modules stay as they are; remove those first if
# they should go too. Refuses when the window is running from that folder, which it can't delete
# while in use: open Fleet from a copied folder to remove it.
. (Join-Path $PSScriptRoot 'common.ps1')

$Dest    = Join-Path $FleetData 'window'
$LogFile = Join-Path $FleetData 'window.log'

if (-not (Test-Admin)) { Fail 'Needs admin.'; return }
$here = [IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent)).TrimEnd('\')
if ($here -ieq [IO.Path]::GetFullPath($Dest).TrimEnd('\')) {
  Fail 'This window is running from the installed copy, so it cannot remove it. Open Fleet from a copied folder and remove it from there.'
  return
}

foreach ($dir in @([Environment]::GetFolderPath('CommonDesktopDirectory'), [Environment]::GetFolderPath('CommonPrograms'))) {
  $lnk = Join-Path $dir 'Showcase Fleet.lnk'
  if (Test-Path $lnk) { Step "Removed $lnk" { Remove-Item $lnk -Force } }
}
# trial 7: the taskbar pin's layout policy, only if it's Fleet's own
$policy = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer'
$layout = Join-Path $FleetData 'taskbar_layout.xml'
if ((Get-ItemProperty $policy -Name StartLayoutFile -ErrorAction SilentlyContinue).StartLayoutFile -ieq $layout) {
  Step 'Removed the taskbar pin (gone from the taskbar after the next sign-in)' { Remove-ItemProperty -Path $policy -Name StartLayoutFile, LockedStartLayout -Force -ErrorAction SilentlyContinue }
}
Remove-Item $layout -Force -ErrorAction SilentlyContinue
if (Test-Path $Dest) { Step "Removed $Dest" { Remove-Item $Dest -Recurse -Force } } else { Ok 'Nothing installed in ProgramData.' }
Add-Content -Path $LogFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  OK removed the window" -Encoding UTF8 -ErrorAction SilentlyContinue
Ok 'Showcase Fleet is off this NUC. Modules that were installed are still installed.'
