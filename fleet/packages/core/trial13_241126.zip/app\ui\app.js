'use strict';
// Showcase Fleet window (trial 3, 24 Oct 2026). Talks only to the local server that opened it.
// Modules and tools are rows in a list; click a row for its settings, actions and log.

const TOKEN = document.querySelector('meta[name="fleet-token"]').content;
const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// the same order as the server's Get-VersionRank: confirmed releases above trials, by date; trials by number
function versionRank(v) {
  const c = /^(\d\d)(\d\d)(\d\d)(?:_v(\d+))?$/.exec(v || '');
  if (c) return 1e12 + Number(c[3] + c[2] + c[1]) * 100 + Number(c[4] || 1);
  const t = /^trial(\d+)/.exec(v || '');
  return t ? Number(t[1]) : 0;
}
// anything running in Fleet at all: one change at a time (the server refuses a second)
const anyBusy = () => busy.size > 0 || (state?.running || []).length > 0;

// trial3_241026 -> "Trial 3 (24 Oct 2026)"; a confirmed release 011126 -> "v011126"
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const verLabel = (v) => {
  const t = /^trial(\d+)(?:_(\d\d)(\d\d)(\d\d))?$/.exec(v || '');
  if (!t) return `v${v || ''}`;
  return `Trial ${t[1]}${t[2] ? ` (${Number(t[2])} ${MONTHS[Number(t[3]) - 1]} 20${t[4]})` : ''}`;
};
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const CHEV = '<svg width="14" height="14" viewBox="0 0 16 16" aria-hidden="true"><path d="M6 3l5 5-5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

let state = null;
const busy = new Set();          // modules and tools with a job running
const builtFor = {};             // module id -> installed settings the form was built from
const open = new Set();          // rows the viewer has expanded
let displays = [];
let chosenDisplay = null;
let followedAuto = false;
let handedOver = false;   // this copy's window has given way to the installed one

async function api(path, body) {
  const res = await fetch('/api/' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'X-Fleet-Token': TOKEN, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch { /* empty */ }
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

function notice(html) {
  const n = $('#notice');
  n.hidden = !html;
  n.innerHTML = html ? `<span class="grow">${html}</span><button class="link" data-dismiss>Dismiss</button>` : '';
  n.querySelector('[data-dismiss]')?.addEventListener('click', () => notice(''));
}

// ------------------------------------------------------------ theme, updates

function setThemeLabel() {
  $('#theme').textContent = document.documentElement.dataset.theme === 'light' ? 'Dark theme' : 'Light theme';
}
$('#theme').addEventListener('click', () => {
  const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
  document.documentElement.dataset.theme = next;
  try { localStorage.setItem('fleet-theme', next); } catch { /* storage off */ }
  setThemeLabel();
});
setThemeLabel();

$('#check-updates').addEventListener('click', () => {
  notice(`This is Showcase Fleet <b>${esc(verLabel(state?.version))}</b>. From the week of 9 Nov the fleet agent keeps this window and every module up to date by itself, and this button asks it to check straight away. Until then, copy a newer Fleet zip onto the NUC and open it once: it replaces the copy on this NUC.`);
});

// ------------------------------------------------------------ tabs

document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => selectTab(t.dataset.tab)));
function selectTab(name) {
  document.querySelectorAll('.tab').forEach((t) => t.setAttribute('aria-selected', String(t.dataset.tab === name)));
  document.querySelectorAll('.panel').forEach((p) => { p.hidden = p.id !== name; });
  if (name === 'tools') loadDisplays();
  if (name === 'nuc' && !nucDirty) loadNuc();   // never wipe edits not saved yet
}

// ------------------------------------------------------------ This NUC (nuc.config)

const MODES = [['kiosk', 'Kiosk (normal)'], ['console', 'Kiosk + console history (inspect from the support screen)'], ['troubleshoot', 'Troubleshooting (a normal window with DevTools)']];
const ROLES = [['normal', 'Just this NUC'], ['lead', 'Lead NUC for the site (Bluesound, model lights)']];
const SCREENS = [['', 'Not set'], ['tv', 'TV'], ['led', 'LED'], ['touch', 'Touch screen'], ['headless', 'No screen (headless)'], ['video', 'Video loop (no Showcase)']];
const opts = (list, v) => list.map(([k, l]) => `<option value="${esc(k)}" ${k === v ? 'selected' : ''}>${esc(l)}</option>`).join('');
let nucDirty = false;       // edits not saved yet
let importedWaiting = false; // "Read from this NUC" found a URL; the server holds it until Save

async function loadNuc() {
  nucDirty = false; importedWaiting = false;
  const box = $('#nuc-form');
  let n;
  try { n = await api('nuc'); } catch (e) { box.innerHTML = `<p class="note">${esc(e.message)}</p>`; return; }
  const c = n.config, d = n.detected, admin = state?.admin;
  $('#nuc-path').textContent = n.path;
  box.innerHTML = `
    <div class="detected"><span>Windows name <b>${esc(d.computer)}</b></span><span>Model <b>${esc(d.model || '-')}</b></span><span>Serial <b>${esc(d.serial || '-')}</b></span>
      <span>NUC Monitor name <b>${esc(d.nucMonitorId || 'not installed')}</b></span></div>
    <div class="fields">
      <div class="field wide"><label for="n-id">NUC name (nucId)</label>
        <input type="text" id="n-id" value="${esc(c.NucId)}" placeholder="3/CLIENT/PROJECT/SCREEN, or 0/AD/TEST/NUC-1 for a test NUC">
        <span class="help">The same name everywhere: NUC Monitor, Chrome Remote Desktop, Fleet.${d.nucMonitorId && d.nucMonitorId !== c.NucId ? ` <button class="link" id="n-use-monitor">Use the NUC Monitor name</button>` : ''}</span></div>
      <div class="field wide"><label for="n-url">Showcase URL</label>
        <input type="text" id="n-url" value="" placeholder="${esc(n.urlSet ? n.urlShown + '  (leave blank to keep it)' : 'https://app.showcase.space/...')}">
        <span class="help">${n.urlSet ? 'Set. Shown without its keys.' : 'Not set yet.'} <button class="link" id="n-reveal">Show it</button> <button class="link" id="n-import">Read from this NUC</button> <span id="n-url-note"></span></span></div>
      <div class="field"><label for="n-mode">Launcher mode</label><select id="n-mode">${opts(MODES, c.LauncherMode)}</select></div>
      <div class="field"><label for="n-role">Site role</label><select id="n-role">${opts(ROLES, c.SiteRole)}</select></div>
      <div class="field"><label for="n-screen">Screen</label><select id="n-screen">${opts(SCREENS, c.ScreenType)}</select></div>
      <div class="field"><label for="n-ock">OCK number</label><input type="text" id="n-ock" value="${esc(c.OckNumber)}" placeholder="From the Octek order"></div>
      <div class="field wide"><label for="n-notes">Notes</label><input type="text" id="n-notes" value="${esc(c.Notes)}"></div>
    </div>
    <div class="row"><button class="btn primary small" id="n-save">Save</button><span class="note" id="n-saved"></span></div>`;
  $('#n-use-monitor')?.addEventListener('click', () => { $('#n-id').value = d.nucMonitorId; });
  $('#n-reveal').addEventListener('click', async () => {
    try { const r = await api('nuc/reveal', {}); $('#n-url').value = r.url || ''; } catch (e) { $('#n-url-note').textContent = e.message; }
  });
  // trial 7: the found URL stays on the server; the window only sees it without its keys
  $('#n-import').addEventListener('click', async () => {
    try {
      const r = await api('nuc/import', {});
      $('#n-url').value = ''; $('#n-url').placeholder = r.urlShown; importedWaiting = true; nucDirty = true;
      $('#n-url-note').textContent = `Found in ${r.from}. Press Save to keep it.`;
    } catch (e) { $('#n-url-note').textContent = e.message; }
  });
  box.querySelectorAll('input, select').forEach((el) => el.addEventListener('input', () => { nucDirty = true; }));
  $('#n-save').addEventListener('click', async () => {
    const config = { NucId: $('#n-id').value, ShowcaseUrl: $('#n-url').value, LauncherMode: $('#n-mode').value,
      SiteRole: $('#n-role').value, ScreenType: $('#n-screen').value, OckNumber: $('#n-ock').value, Notes: $('#n-notes').value,
      useImported: importedWaiting && !$('#n-url').value };
    try {
      await api('nuc/save', { config });
      await loadNuc();
      $('#n-saved').textContent = 'Saved. A new URL or mode: Startup Kiosk needs Reinstall; showcase_startup.bat needs Reopen Showcase now.';
    } catch (e) { $('#n-saved').textContent = e.message; }
  });
  if (!admin) box.querySelectorAll('input, select, #n-save, #n-reveal, #n-import').forEach((el) => { el.disabled = true; });
}

// ------------------------------------------------------------ state

async function refresh() {
  if (handedOver) return;
  try {
    state = await api('state');
    renderHeader();
    renderModules();
    renderTools();
    followAutoInstall();
  } catch (e) {
    $('#nuc-info').textContent = 'Lost the connection. Close this window and open Showcase Fleet again.';
  }
}

function renderHeader() {
  const s = state;
  $('#nuc-info').innerHTML = `<b>${esc(s.computer)}</b> · ${esc(s.ips.join(', ') || 'no network')} · ${esc(s.clock)}`
    + (s.admin ? '<span class="badge admin">Admin</span>' : '<span class="badge ro">Read-only</span>');

  const banner = $('#banner');
  const msgs = [];
  if (!s.admin) {
    msgs.push(s.readOnly
      ? 'Test mode: read-only. Nothing can be installed or changed from this window.'
      : 'Read-only. Open Showcase Fleet from its desktop shortcut or the .bat file, which ask for admin, to install or change anything.');
  }
  if (s.window?.skipped) msgs.push(esc(s.window.skipped));
  if (s.managed) msgs.push('Managed from Showcase Fleet online (document.showcase.space/fleet): module changes are made there and go in at 1am. Tools and checks work here.');
  banner.hidden = !msgs.length;
  banner.innerHTML = msgs.map((m) => `<span class="grow">${m}</span>`).join('');

  // is Fleet itself on this NUC?
  const w = s.window || {};
  const here = $('#here');
  if (w.runningHere) here.innerHTML = 'On this NUC';
  else if (w.installed) {
    // a different version on the NUC: offer this one, unless the one there is newer
    const offer = s.admin && !w.autoJob && !anyBusy() && w.version !== s.version && versionRank(w.version) < versionRank(s.version);
    here.innerHTML = `On this NUC${w.version && w.version !== s.version ? ` (${esc(verLabel(w.version))})` : ''}`
      + (offer ? ' · <button class="link" data-window="install">Put this version on it</button>' : '')
      + (s.admin && !anyBusy() ? ' · <button class="link" data-window="remove">Take it off</button>' : '');
  } else {
    here.innerHTML = 'Not on this NUC' + (s.admin && !w.autoJob && !anyBusy() ? ' · <button class="link" data-window="install">Put it on this NUC</button>' : '');
  }
  here.querySelectorAll('[data-window]').forEach((b) => b.addEventListener('click', () => windowJob(b.dataset.window)));

  const pause = $('#pause');
  pause.hidden = !s.admin || (!s.pauseUntil && !s.showcaseTools);
  if (s.pauseUntil) {
    pause.innerHTML = `<span class="grow">Showcase Pin and Kiosk are paused until <b>${esc(s.pauseUntil)}</b> so this window stays on top. Closing Showcase Fleet ends the pause.</span>
      <button class="link" data-pause="30">30 more minutes</button><button class="link" data-pause="0">Resume Showcase now</button>`;
  } else if (s.showcaseTools) {
    pause.innerHTML = '<span class="grow">Showcase Pin may cover this window.</span><button class="link" data-pause="30">Pause Pin and Kiosk for 30 minutes</button>';
  }
  pause.querySelectorAll('[data-pause]').forEach((b) => b.addEventListener('click', async () => {
    try { await api('pause', { minutes: Number(b.dataset.pause) }); } catch (e) { notice(esc(e.message)); }
    refresh();
  }));
}

// the window puts itself on the NUC when it opens as admin; show that happening, then move over to the installed copy
async function followAutoInstall() {
  const id = state.window?.autoJob;
  if (!id || followedAuto) return;
  followedAuto = true;
  if (await runJob('window', 'Putting Showcase Fleet on this NUC', async () => ({ job: id }))) handover();
}

async function windowJob(what) {
  if (what === 'remove' && !(await confirmBox('Take Showcase Fleet off this NUC?',
    'The desktop and Start menu shortcuts, the taskbar pin and its folder in ProgramData go. Modules that are installed stay installed.', 'Take it off'))) return;
  const ok = await runJob('window', what === 'remove' ? 'Taking Showcase Fleet off this NUC' : 'Putting Showcase Fleet on this NUC', () => api('window/' + what, {}));
  if (ok && what === 'install') handover();
}

// trial 7: once Fleet is on the NUC, this copy's window gives way to the installed one (which opens by itself, on the
// support screen) and an unzipped copy on the desktop or in Downloads is deleted (Jordan, 24 Oct)
async function handover() {
  if (state?.window?.runningHere) return;
  let r;
  try { r = await api('window/handover', {}); } catch (e) { appendLine('[WARN] Could not open the installed copy: ' + e.message); return; }
  handedOver = true;
  appendLine(`[OK] Opening Showcase Fleet from ${r.path}. This window closes.`);
  if (r.deleting) appendLine(`[OK] ${r.deleting} is deleted once this window has closed.`);
  setTimeout(() => {
    document.querySelector('main').innerHTML = '<p class="lede">Showcase Fleet is on this NUC now and has opened from there. This window can be closed.</p>';
    window.close();
  }, 2500);
}

// ------------------------------------------------------------ list rows

function makeRow(list, id, { planned = false } = {}) {
  const row = document.createElement('article');
  row.className = 'item' + (planned ? ' planned' : '');
  row.dataset.id = id;
  row.innerHTML = `
    <div class="item-head">
      <button class="chev" aria-expanded="false" aria-label="Show details">${CHEV}</button>
      <div class="item-main"><div class="item-name"></div><div class="item-sum"></div></div>
      <span class="pill"></span>
      <div class="item-actions"></div>
    </div>
    <div class="item-body" hidden></div>`;
  list.appendChild(row);
  const toggle = () => setOpen(row, !row.classList.contains('open'));
  row.querySelector('.item-head').addEventListener('click', (e) => { if (!e.target.closest('.item-actions')) toggle(); });
  if (open.has(id)) setOpen(row, true);
  return row;
}

function setOpen(row, on) {
  row.classList.toggle('open', on);
  row.querySelector('.item-body').hidden = !on;
  row.querySelector('.chev').setAttribute('aria-expanded', String(on));
  if (on) open.add(row.dataset.id); else open.delete(row.dataset.id);
}

function groupList(container, group) {
  let g = container.querySelector(`[data-group="${group.id}"]`);
  if (!g) {
    container.insertAdjacentHTML('beforeend', `<h2 class="group">${esc(group.name)}<span>${esc(group.note || '')}</span></h2><div class="list" data-group="${esc(group.id)}"></div>`);
    g = container.querySelector(`[data-group="${group.id}"]`);
  }
  return g;
}

// ------------------------------------------------------------ modules

// trial 7: which way a version difference goes, and labels through verLabel ("Trial 6 (24 Oct 2026)")
function moduleStatus(m) {
  const st = m.status || {};
  if (!st.installed) return { cls: 'off', text: 'Not installed', button: 'Install' };
  if (st.problem) return { cls: 'bad', text: 'Needs a look', button: 'Reinstall' };
  if (st.version && !versionRank(st.version)) return { cls: 'update', text: 'Installed before Fleet', button: `Update to ${verLabel(m.version)}` };
  if (st.version && st.version !== m.version) {
    if (versionRank(st.version) > versionRank(m.version)) return { cls: 'ok', text: `Newer than this Fleet (${verLabel(st.version)})`, button: 'Newer installed', newer: true };
    return { cls: 'update', text: `Older version (${verLabel(st.version)})`, button: `Update to ${verLabel(m.version)}` };
  }
  return { cls: 'ok', text: `Installed${st.version ? ' ' + verLabel(st.version) : ''}`, button: 'Reinstall' };
}

function renderModules() {
  const box = $('#module-list');
  const cat = state.catalogue || { groups: [{ id: 'optional', name: 'Modules' }], place: {}, planned: [] };
  for (const group of cat.groups) {
    const list = groupList(box, group);
    for (const m of state.modules.filter((x) => (cat.place?.[x.id] || 'optional') === group.id)) renderModuleRow(list, m);
    for (const p of (cat.planned || []).filter((x) => x.group === group.id && !x.hidden)) renderPlannedRow(list, p);
  }
}

function renderModuleRow(list, m) {
  if (m.kind === 'settings') { renderSettingsModule(list, m); return; }
  let row = list.querySelector(`[data-id="${m.id}"]`);
  if (!row) {
    row = makeRow(list, m.id);
    row.querySelector('.item-name').innerHTML = `${esc(m.name)}<span class="ver">${esc(verLabel(m.version))}</span>${onePerSite(m.id) ? '<span class="ver"> · one NUC per site</span>' : ''}`;
    row.querySelector('.item-sum').textContent = m.summary;
    row.querySelector('.item-actions').innerHTML = '<button class="btn primary small" data-do="install"></button>';
    row.querySelector('.item-body').innerHTML = `
      <div class="detail"></div>
      ${m.about ? `<p class="about">${esc(m.about)}</p>` : ''}
      <div class="fields"></div>
      <div class="row">
        <button class="btn danger small" data-do="remove">Remove</button>
        ${m.actions.map((a) => `<button class="btn ghost small" data-action="${esc(a.id)}">${esc(a.label)}</button>`).join('')}
        ${m.hasLog ? '<button class="link" data-do="log">Log</button>' : ''}
      </div>`;
    row.querySelector('[data-do="install"]').addEventListener('click', () => installModule(m.id));
    row.querySelector('[data-do="remove"]').addEventListener('click', () => removeModule(m.id));
    row.querySelector('[data-do="log"]')?.addEventListener('click', () => showLog(m.id));
    row.querySelectorAll('[data-action]').forEach((b) => b.addEventListener('click', () => moduleAction(m.id, b.dataset.action)));
  }
  const st = moduleStatus(m);
  const pill = row.querySelector('.pill');
  pill.className = 'pill ' + st.cls;
  pill.textContent = st.text;
  const detail = row.querySelector('.detail');
  detail.textContent = m.status?.detail || '';
  detail.hidden = !m.status?.detail;

  // build the settings once, and again only when the installed settings change (after an install)
  const installed = JSON.stringify(m.status?.settings || null);
  if (builtFor[m.id] !== installed) {
    builtFor[m.id] = installed;
    buildFields(row.querySelector('.fields'), m);
  }

  // one change at a time anywhere in Fleet; actions that only read stay available
  const isBusy = anyBusy();
  const install = row.querySelector('[data-do="install"]');
  install.textContent = st.button;
  install.disabled = !state.admin || isBusy || !!st.newer;
  row.querySelector('[data-do="remove"]').disabled = !state.admin || isBusy || !m.status?.installed;
  row.querySelectorAll('[data-action]').forEach((b) => {
    const a = m.actions.find((x) => x.id === b.dataset.action);
    b.disabled = a.readOnly ? busy.has(m.id) : (!state.admin || isBusy || (!a.anytime && !m.status?.installed));
  });
}

// Baseline: our recommended settings, what this NUC is set to now, and a tick to set each
const settingsResults = {};
function renderSettingsModule(list, m) {
  let row = list.querySelector(`[data-id="${m.id}"]`);
  const show = (data) => { settingsResults[m.id] = data; drawSettings(row.querySelector('.results'), data, handlers); };
  const check = () => runJob(m.id, `${m.name}: checking this NUC`, () => api(`module/${m.id}/settings`, {}), show);
  const handlers = {
    recheck: check,
    apply: (chosen) => runJob(m.id, `${m.name}: applying`, () => api(`module/${m.id}/settings`, { apply: chosen }), show),
  };
  if (!row) {
    row = makeRow(list, m.id);
    row.querySelector('.item-name').innerHTML = `${esc(m.name)}<span class="ver">${esc(verLabel(m.version))}</span>`;
    row.querySelector('.item-sum').textContent = m.summary;
    row.querySelector('.item-actions').innerHTML = '<button class="btn primary small" data-do="check">Check</button>';
    row.querySelector('.item-body').innerHTML = `
      ${m.about ? `<p class="about">${esc(m.about)}</p>` : ''}
      <div class="results"><p class="note">Checking this NUC (about 20 seconds)…</p></div>
      ${m.hasLog || m.actions.length ? `<div class="row">
        ${m.actions.map((a) => `<button class="btn ghost small" data-action="${esc(a.id)}">${esc(a.label)}</button>`).join('')}
        ${m.hasLog ? '<button class="link" data-do="log">Log of changes</button>' : ''}
      </div>` : ''}`;
    row.querySelector('[data-do="check"]').addEventListener('click', () => { setOpen(row, true); check(); });
    row.querySelector('[data-do="log"]')?.addEventListener('click', () => showLog(m.id));
    // trial 9: settings modules can have actions too (Baseline: "Put back the old restart")
    row.querySelectorAll('[data-action]').forEach((b) => b.addEventListener('click', () => moduleAction(m.id, b.dataset.action)));
    // opening the row reads the NUC straight away (it only reads)
    row.querySelector('.item-head').addEventListener('click', () => { if (row.classList.contains('open') && !settingsResults[m.id] && !busy.has(m.id)) check(); });
  }
  const st = m.status || {};
  const pill = row.querySelector('.pill');
  if (st.total) {
    pill.className = 'pill ' + (st.done === st.total ? 'ok' : 'update');
    pill.textContent = st.done === st.total ? 'All as recommended' : `${st.done} of ${st.total} as recommended`;
  } else { pill.className = 'pill off'; pill.textContent = 'Not checked yet'; }
  row.querySelector('[data-do="check"]').disabled = busy.has(m.id);
  row.querySelectorAll('[data-action]').forEach((b) => {
    const a = m.actions.find((x) => x.id === b.dataset.action);
    b.disabled = a.readOnly ? busy.has(m.id) : (!state.admin || anyBusy());
  });
}

// suite-wide things (Bluesound, the model lights) go on one NUC per site (Jordan, 24 Oct)
const onePerSite = (id) => (state?.catalogue?.onePerSite || []).includes(id);

function renderPlannedRow(list, p) {
  let row = list.querySelector(`[data-id="${p.id}"]`);
  if (!row) {
    row = makeRow(list, p.id, { planned: true });
    row.querySelector('.item-name').innerHTML = `${esc(p.name)}${onePerSite(p.id) ? '<span class="ver"> · one NUC per site</span>' : ''}`;
    row.querySelector('.item-sum').textContent = p.summary;
    row.querySelector('.item-body').innerHTML = `<p class="about">${esc(p.when || '')}</p>`;
  }
  const pill = row.querySelector('.pill');
  if (p.found) {
    pill.className = 'pill found';
    pill.textContent = `On this NUC, not managed yet${p.foundVersion ? ' (v' + p.foundVersion + ')' : ''}`;
  } else {
    pill.className = 'pill planned';
    pill.textContent = p.idea ? 'Idea' : 'Planned';
  }
}

function buildFields(box, m) {
  const current = m.status?.settings || {};
  box.innerHTML = '';
  box.hidden = !m.settings.length;
  for (const f of m.settings) {
    const id = `f-${m.id}-${f.key}`;
    const value = current[f.key] ?? f.default;
    const wrap = document.createElement('div');
    wrap.className = 'field' + (f.type === 'days' || f.wide ? ' wide' : '');
    wrap.dataset.key = f.key;
    wrap.dataset.type = f.type;
    if (f.type === 'days') {
      const chosen = new Set(Array.isArray(value) ? value : String(value || '').split(',').map((d) => d.trim()));
      wrap.innerHTML = `<span class="lbl" id="${id}">${esc(f.label)}</span>
        <div class="days" role="group" aria-labelledby="${id}">${DAYS.map((d) => `<label><input type="checkbox" value="${d}" ${chosen.has(d) ? 'checked' : ''}><span>${d.slice(0, 3)}</span></label>`).join('')}</div>`;
    } else if (f.type === 'select') {
      wrap.innerHTML = `<label for="${id}">${esc(f.label)}</label><select id="${id}">${f.options.map((o) => `<option value="${esc(o.value)}" ${String(o.value) === String(value) ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}</select>`;
    } else {
      const type = f.type === 'number' ? 'number' : f.type === 'time' ? 'time' : 'text';
      const extra = f.type === 'number' ? `min="${f.min ?? ''}" max="${f.max ?? ''}" step="1"` : '';
      wrap.innerHTML = `<label for="${id}">${esc(f.label)}</label><input id="${id}" type="${type}" ${extra} value="${esc(Array.isArray(value) ? value.join(', ') : value ?? '')}" placeholder="${esc(f.placeholder || '')}">`;
    }
    if (f.help) wrap.insertAdjacentHTML('beforeend', `<span class="help">${esc(f.help)}</span>`);
    box.appendChild(wrap);
  }
}

function readFields(row) {
  const out = {};
  row.querySelectorAll('.field').forEach((w) => {
    const key = w.dataset.key;
    const type = w.dataset.type;
    if (type === 'days') out[key] = [...w.querySelectorAll('input:checked')].map((i) => i.value);
    else if (type === 'number') { const v = w.querySelector('input').value; if (v !== '') out[key] = Number(v); }
    else if (type === 'list') out[key] = w.querySelector('input').value.split(',').map((x) => x.trim()).filter(Boolean);
    else out[key] = (w.querySelector('input, select').value || '').trim();
  });
  return out;
}

function confirmBox(title, text, ok = 'Go ahead') {
  const d = $('#confirm');
  $('#confirm-title').textContent = title;
  $('#confirm-text').textContent = text;
  $('#confirm-ok').textContent = ok;
  d.returnValue = '';
  d.showModal();
  return new Promise((resolve) => d.addEventListener('close', () => resolve(d.returnValue === 'ok'), { once: true }));
}

async function installModule(id) {
  const m = state.modules.find((x) => x.id === id);
  const row = $(`#module-list [data-id="${id}"]`);
  const settings = readFields(row);
  // trial 7: a days setting with nothing ticked would quietly fall back to the script's default days
  const noDays = m.settings.find((f) => f.type === 'days' && !(settings[f.key] || []).length);
  if (noDays) { notice(`${esc(noDays.label)}: tick at least one day.`); return; }
  if (m.confirmInstall && !(await confirmBox(`Install ${m.name}?`, m.confirmInstall, 'Install'))) return;
  await runJob(id, `Installing ${m.name}`, () => api(`module/${id}/install`, { settings }));
}

async function removeModule(id) {
  const m = state.modules.find((x) => x.id === id);
  if (!(await confirmBox(`Remove ${m.name}?`, `It comes off this NUC completely. ${m.removeNote || ''}`.trim(), 'Remove'))) return;
  await runJob(id, `Removing ${m.name}`, () => api(`module/${id}/remove`, {}));
}

async function moduleAction(id, actionId) {
  const m = state.modules.find((x) => x.id === id);
  const a = m.actions.find((x) => x.id === actionId);
  if (a.confirm && !(await confirmBox(a.label, a.confirm))) return;
  await runJob(id, `${m.name}: ${a.label}`, () => api(`module/${id}/action/${actionId}`, {}));
}

async function showLog(id) {
  const m = state.modules.find((x) => x.id === id);
  openConsole(`${m.name}: log (last 200 lines)`);
  try {
    const { lines } = await api(`module/${id}/log`);
    lines.forEach(appendLine);
  } catch (e) { appendLine('[FAIL] ' + e.message); }
  stopSpinner();
}

// ------------------------------------------------------------ jobs and the output panel

// true when the job finished with no [FAIL] line
async function runJob(key, title, start, onJson) {
  busy.add(key);
  if (state) { renderModules(); renderTools(); }
  openConsole(title);
  let ok = true;
  try {
    const { job } = await start();
    let shown = 0;
    for (;;) {
      const j = await api('job/' + job);
      const lines = j.lines || [];
      for (; shown < lines.length; shown++) {
        const line = lines[shown];
        if (line.startsWith('@@JSON ')) {
          try { onJson?.(JSON.parse(line.slice(7))); } catch (e) { appendLine('[WARN] Could not read the result: ' + e.message); }
        } else {
          if (line.startsWith('[FAIL]')) ok = false;
          appendLine(line);
        }
      }
      if (j.done) break;
      await sleep(700);
    }
    appendLine('Finished.');
  } catch (e) {
    ok = false;
    appendLine('[FAIL] ' + e.message);
  } finally {
    stopSpinner();
    busy.delete(key);
    await refresh();
  }
  return ok;
}

function openConsole(title) {
  $('#console').hidden = false;
  $('#console-title').textContent = title;
  $('#console-body').innerHTML = '';
  $('#console-spin').classList.remove('stopped');
}
function stopSpinner() { $('#console-spin').classList.add('stopped'); }
function appendLine(text) {
  const body = $('#console-body');
  const t = String(text);
  const cls = t.startsWith('[OK]') ? 'l-ok' : t.startsWith('[WARN]') ? 'l-warn' : t.startsWith('[FAIL]') ? 'l-fail' : '';
  body.insertAdjacentHTML('beforeend', `<span class="${cls}">${esc(t)}</span>\n`);
  body.scrollTop = body.scrollHeight;
}
$('#console-close').addEventListener('click', () => { $('#console').hidden = true; });

// ------------------------------------------------------------ tools

const PATTERNS = [
  ['grid', 'Grid and edges', 'repeating-linear-gradient(90deg,#fff 0 1px,transparent 1px 12px),repeating-linear-gradient(0deg,#fff 0 1px,#111 1px 12px)'],
  ['white', 'White', '#fff'], ['black', 'Black', '#000'], ['red', 'Red', '#f00'], ['green', 'Green', '#0f0'], ['blue', 'Blue', '#00f'],
  ['grey', 'Grey 50%', '#808080'],
  ['bars', 'Colour bars', 'linear-gradient(90deg,#c0c0c0 0 14%,#c0c000 14% 28%,#00c0c0 28% 43%,#00c000 43% 57%,#c000c0 57% 71%,#c00000 71% 86%,#0000c0 86%)'],
  ['ramp', 'Grey ramp', 'linear-gradient(90deg,#000,#fff)'],
  ['rgbramp', 'Colour ramps', 'linear-gradient(#000 0 0) 0 0/0 0,linear-gradient(90deg,#000,#f00) 0 0/100% 34% no-repeat,linear-gradient(90deg,#000,#0f0) 0 50%/100% 34% no-repeat,linear-gradient(90deg,#000,#00f) 0 100%/100% 34% no-repeat'],
  ['checker', 'Fine checker', 'repeating-conic-gradient(#000 0 25%,#fff 0 50%) 0 0/6px 6px'],
  ['cabinets', 'LED cabinets', 'repeating-linear-gradient(90deg,#3cf 0 2px,transparent 2px 20px),repeating-linear-gradient(0deg,#3cf 0 2px,#102 2px 20px)'],
  ['scan', 'Moving line', 'linear-gradient(90deg,#000 45%,#fff 45% 55%,#000 55%)'],
  ['cycle', 'Cycle all', 'linear-gradient(90deg,#f00,#0f0,#00f,#fff)'],
];

const toolResults = {};   // tool id -> last result, so a refresh does not lose it

function renderTools() {
  const box = $('#tool-list');
  const list = groupList(box, { id: 'tools', name: 'Tools', note: 'Run on demand' });
  for (const t of state.tools) {
    let row = list.querySelector(`[data-id="${t.id}"]`);
    if (!row) {
      row = makeRow(list, t.id);
      row.querySelector('.item-name').textContent = t.name;
      row.querySelector('.item-sum').textContent = t.summary;
      row.querySelector('.pill').hidden = true;
      row.querySelector('.item-body').innerHTML = '<div class="body"></div><div class="results" hidden></div>';
      buildTool(row, t);
    }
    row.querySelectorAll('[data-run], [data-tool-action]').forEach((b) => {
      const a = t.actions.find((x) => x.id === b.dataset.toolAction);
      b.disabled = busy.has(t.id) || (a?.changes && !state.admin);
    });
  }
  const planned = groupList(box, { id: 'tools-planned', name: 'On the way', note: '' });
  for (const p of state.catalogue?.plannedTools || []) {
    let row = planned.querySelector(`[data-id="${p.id}"]`);
    if (!row) {
      row = makeRow(planned, p.id, { planned: true });
      row.querySelector('.item-name').textContent = p.name;
      row.querySelector('.item-sum').textContent = p.summary;
      row.querySelector('.pill').className = 'pill planned';
      row.querySelector('.pill').textContent = 'Planned';
      row.querySelector('.item-body').innerHTML = `<p class="about">${esc(p.when || '')}</p>`;
    }
  }
}

function buildTool(row, t) {
  const body = row.querySelector('.body');
  const actions = row.querySelector('.item-actions');
  if (t.kind === 'screen') {
    actions.innerHTML = '';
    // opening and closing tests needs admin; read-only can still look at the displays
    const dis = state.admin ? '' : ' disabled';
    body.innerHTML = `
      <div class="field"><span class="lbl">Display</span><div class="chips" id="display-chips"><span class="note">Looking for displays…</span></div></div>
      <div class="field"><span class="lbl">Pattern (opens full screen on that display)</span>
        <div class="swatches">${PATTERNS.map(([id, label, bg]) => `<button class="swatch" data-pattern="${id}"${dis}><i style="background:${bg}"></i>${esc(label)}</button>`).join('')}</div></div>
      <div class="row"><button class="btn ghost small" data-close="one"${dis}>Close test on this display</button><button class="btn ghost small" data-close="all"${dis}>Close all tests</button><button class="link" data-reload-displays>Find displays again</button></div>
      <p class="note">On the screen: arrow keys, space or a click change the pattern, H hides the label, Esc closes. Showcase Blackout covers it at night.${state.admin ? '' : ' Opening a test needs admin.'}</p>`;
    body.querySelectorAll('[data-pattern]').forEach((b) => b.addEventListener('click', () => openPattern(b.dataset.pattern)));
    body.querySelector('[data-close="one"]').addEventListener('click', () => closePattern(chosenDisplay));
    body.querySelector('[data-close="all"]').addEventListener('click', () => closePattern('all'));
    body.querySelector('[data-reload-displays]').addEventListener('click', loadDisplays);
    loadDisplays();
    return;
  }

  actions.innerHTML = `<button class="btn primary small" data-run="">${esc(t.runLabel || 'Run')}</button>`;
  actions.querySelector('[data-run]').addEventListener('click', () => runTool(row, t, ''));
  const params = t.params.filter((p) => p.type === 'text');
  const extras = t.params.filter((p) => p.type === 'bool');
  body.innerHTML = `
    ${params.length ? `<div class="fields">${params.map((p) => `<div class="field"><label for="t-${t.id}-${p.key}">${esc(p.label)}</label><input type="text" id="t-${t.id}-${p.key}" data-param="${esc(p.key)}" placeholder="${esc(p.placeholder || '')}">${p.help ? `<span class="help">${esc(p.help)}</span>` : ''}</div>`).join('')}</div>` : ''}
    ${extras.length || t.actions.length ? `<div class="row">
      ${extras.map((p) => `<button class="btn ghost small" data-run="${esc(p.key)}">${esc(p.label)}</button>`).join('')}
      ${t.actions.map((a) => `<button class="btn ghost small" data-tool-action="${esc(a.id)}">${esc(a.label)}</button>`).join('')}
    </div>` : ''}
    ${t.kind === 'settings' ? '<p class="note">Check first: each setting shows whether it is already done. Tick the ones to change, then apply. Only one-off settings here; the Baseline module will keep them set for good.</p>' : ''}`;
  body.querySelectorAll('[data-run]').forEach((b) => b.addEventListener('click', () => runTool(row, t, b.dataset.run)));
  body.querySelectorAll('[data-tool-action]').forEach((b) => b.addEventListener('click', () => toolAction(t, b.dataset.toolAction)));
  if (toolResults[t.id]) drawResult(row, t, toolResults[t.id]);
}

async function runTool(row, t, flag, extra = {}) {
  const params = { ...extra };
  row.querySelectorAll('[data-param]').forEach((i) => { if (i.value.trim()) params[i.dataset.param] = i.value.trim(); });
  if (flag) params[flag] = true;
  setOpen(row, true);
  await runJob(t.id, t.name, () => api(`tool/${t.id}/run`, { params }), (data) => {
    toolResults[t.id] = data;
    drawResult(row, t, data);
  });
}

async function toolAction(t, id) {
  const a = t.actions.find((x) => x.id === id);
  if (a.confirm && !(await confirmBox(a.label, a.confirm))) return;
  await runJob(t.id, `${t.name}: ${a.label}`, () => api(`tool/${t.id}/action/${id}`, {}));
}

function drawResult(row, t, data) {
  const box = row.querySelector('.results');
  box.hidden = false;
  if (t.kind === 'scan') drawScan(box, data);
  else if (t.kind === 'checks') drawChecks(box, data);
  else if (t.kind === 'info') drawInfo(box, data);
}

function copyText(text, button) {
  const done = () => { const old = button.textContent; button.textContent = 'Copied'; setTimeout(() => { button.textContent = old; }, 1500); };
  if (navigator.clipboard) navigator.clipboard.writeText(text).then(done, () => fallbackCopy(text, done));
  else fallbackCopy(text, done);
}
function fallbackCopy(text, done) {
  const ta = document.createElement('textarea');
  ta.value = text; document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); done(); } finally { ta.remove(); }
}

function drawScan(box, data) {
  const devices = data.devices || [];
  box.innerHTML = `
    <div class="bar"><span>${devices.length} devices on ${esc((data.networks || []).join(', '))} · scanned ${esc(data.at || '')}</span>
      <span class="row"><input type="search" placeholder="Filter" aria-label="Filter devices"><button class="link" data-copy>Copy as text</button></span></div>
    <div class="table-wrap"><table>
      <thead><tr><th>IP</th><th>Name</th><th>Likely</th><th>Open ports</th><th>MAC</th></tr></thead>
      <tbody>${devices.map((d) => `<tr class="${d.self ? 'me' : ''}"><td class="mono">${esc(d.ip)}</td><td>${esc(d.name || '')}</td><td>${esc(d.likely || '')}</td><td class="mono">${esc((d.ports || []).join(', '))}</td><td class="mono">${esc(d.mac || '')}</td></tr>`).join('')}</tbody>
    </table></div>`;
  const rows = [...box.querySelectorAll('tbody tr')];
  box.querySelector('input[type="search"]').addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase();
    rows.forEach((r) => { r.hidden = q && !r.textContent.toLowerCase().includes(q); });
  });
  box.querySelector('[data-copy]').addEventListener('click', (e) => copyText(
    devices.map((d) => [d.ip, d.name, d.likely, (d.ports || []).join(' '), d.mac].map((x) => x || '-').join('\t')).join('\n'), e.target));
}

function drawChecks(box, data) {
  const adapters = data.adapters || [];
  const checks = data.checks || [];
  box.innerHTML = `
    ${adapters.map((a) => `<div class="detail"><b>${esc(a.name)}</b> (${esc(a.type)}) · ${esc(a.ip || 'no address')} · gateway ${esc(a.gateway || 'none')}${a.ssid ? ` · Wi-Fi "${esc(a.ssid)}" ${esc(a.signal || '')}` : ''}${a.speed ? ` · ${esc(a.speed)}` : ''}</div>`).join('')}
    <ul class="checks">${checks.map((c) => `<li><span class="dot ${esc(c.result)}"></span><span class="what">${esc(c.name)}</span><span class="val">${esc(c.detail || '')}</span></li>`).join('')}</ul>
    <div class="row end"><button class="link" data-copy>Copy as text</button></div>`;
  box.querySelector('[data-copy]').addEventListener('click', (e) => copyText(
    adapters.map((a) => `${a.name} (${a.type}): ${a.ip || 'no address'}, gateway ${a.gateway || 'none'}${a.ssid ? `, Wi-Fi ${a.ssid} ${a.signal || ''}` : ''}`)
      .concat(checks.map((c) => `${c.result === 'ok' ? 'OK  ' : c.result === 'warn' ? 'WARN' : 'FAIL'} ${c.name}: ${c.detail || ''}`)).join('\n'), e.target));
}

function drawInfo(box, data) {
  const groups = data.groups || [];
  box.innerHTML = `<div class="kv">${groups.map((g) => `<h4>${esc(g.name)}</h4><dl>${g.items.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl>`).join('')}</div>
    <div class="row end"><button class="link" data-copy>Copy as text</button></div>`;
  box.querySelector('[data-copy]').addEventListener('click', (e) => copyText(
    groups.map((g) => `${g.name}\n` + g.items.map(([k, v]) => `  ${k}: ${v}`).join('\n')).join('\n'), e.target));
}

// Baseline: recommended, now, and a tick for each one that can be set from here
function drawSettings(box, data, { recheck, apply }) {
  const items = data.settings || [];
  const done = items.filter((s) => s.ok).length;
  box.innerHTML = `
    <div class="bar"><span>${done} of ${items.length} as recommended · checked ${esc(data.at || '')}</span>
      <span class="row"><button class="link" data-tick-all>Tick everything not as recommended</button><button class="link" data-copy>Copy as text</button></span></div>
    <div class="settings">
      <div class="setting head"><span></span><span>Setting</span><span>Recommended</span><span>Now</span></div>
      ${items.map((s) => `
      <div class="setting ${s.ok ? 'done' : ''}">
        <span>${s.canApply && !s.ok ? `<input type="checkbox" data-setting="${esc(s.id)}" aria-label="Set ${esc(s.name)} to ${esc(s.recommended)}">` : ''}</span>
        <div><div class="s-name">${esc(s.name)}</div><div class="s-about">${esc(s.about)}</div></div>
        <div class="s-rec">${esc(s.recommended)}</div>
        <div class="s-state"><span class="dot ${s.ok ? 'ok' : s.canApply ? 'warn' : 'bad'}"></span><span>${esc(s.now)}${!s.canApply && !s.ok ? ' <span class="tag">(set by hand)</span>' : ''}</span></div>
      </div>`).join('')}
    </div>
    <div class="row end"><button class="btn ghost small" data-recheck>Check again</button><button class="btn primary small" data-apply>Apply ticked</button></div>`;
  const boxes = [...box.querySelectorAll('[data-setting]')];
  const applyBtn = box.querySelector('[data-apply]');
  const count = () => { const n = boxes.filter((b) => b.checked).length; applyBtn.textContent = n ? `Apply ticked (${n})` : 'Apply ticked'; };
  boxes.forEach((b) => b.addEventListener('change', count));
  box.querySelector('[data-tick-all]').addEventListener('click', () => { boxes.forEach((b) => { b.checked = true; }); count(); });
  box.querySelector('[data-recheck]').addEventListener('click', () => recheck());
  applyBtn.disabled = !state.admin || !boxes.length;
  applyBtn.addEventListener('click', async () => {
    const chosen = boxes.filter((b) => b.checked).map((b) => b.dataset.setting);
    if (!chosen.length) { notice('Tick at least one setting to apply.'); return; }
    const names = items.filter((s) => chosen.includes(s.id)).map((s) => `· ${s.name}: ${s.now} → ${s.recommended}`).join('\n');
    if (!(await confirmBox('Set these as recommended?', `${names}\n\nNothing shows on the display. Each change is logged.`, 'Yes, set them'))) return;
    await apply(chosen);
  });
  box.querySelector('[data-copy]').addEventListener('click', (e) => copyText(
    items.map((s) => `${s.ok ? 'OK  ' : 'TODO'} ${s.name}: now ${s.now}, recommended ${s.recommended}`).join('\n'), e.target));
}

// ------------------------------------------------------------ screen test

async function loadDisplays() {
  const chips = $('#display-chips');
  if (!chips) return;
  try {
    displays = (await api('displays')).displays;
  } catch (e) { chips.innerHTML = `<span class="note">${esc(e.message)}</span>`; return; }
  if (!displays.some((d) => d.index === chosenDisplay)) chosenDisplay = (displays.find((d) => !d.primary) || displays[0])?.index ?? null;
  chips.innerHTML = displays.map((d) => `<button class="chip" data-display="${d.index}" aria-pressed="${d.index === chosenDisplay}">
      Display ${d.index}${d.primary ? ' (main)' : ''}<small>${d.width} × ${d.height}${d.testOpen ? ' · test open' : ''}</small></button>`).join('');
  chips.querySelectorAll('[data-display]').forEach((b) => b.addEventListener('click', () => {
    chosenDisplay = Number(b.dataset.display);
    chips.querySelectorAll('[data-display]').forEach((x) => x.setAttribute('aria-pressed', String(Number(x.dataset.display) === chosenDisplay)));
  }));
}

async function openPattern(pattern) {
  if (!chosenDisplay) return;
  const d = displays.find((x) => x.index === chosenDisplay);
  if (d?.primary && !(await confirmBox('Test on the main display?', 'The test covers this window too. Press Esc on the test, or close it from here, to get back.', 'Open test'))) return;
  try { await api('screen/open', { display: chosenDisplay, pattern }); } catch (e) { notice(esc(e.message)); }
  setTimeout(loadDisplays, 1500);
}

async function closePattern(which) {
  try { await api('screen/close', { display: which }); } catch (e) { notice(esc(e.message)); }
  setTimeout(loadDisplays, 800);
}

// ------------------------------------------------------------ go

refresh();
setInterval(refresh, 20000);   // also tells the server the window is still open
