' Showcase Fleet trial 4 (24 Oct 2026): opens the Fleet window with admin and no console window.
' The .bat and the desktop shortcut both run this. What the window's helper would have printed goes to
' C:\ProgramData\showcase_fleet\window_console.log instead.
Set fso = CreateObject("Scripting.FileSystemObject")
here = fso.GetParentFolderName(WScript.ScriptFullName)
server = fso.BuildPath(here, "server.ps1")
CreateObject("Shell.Application").ShellExecute "powershell.exe", "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & server & """", "", "runas", 0
