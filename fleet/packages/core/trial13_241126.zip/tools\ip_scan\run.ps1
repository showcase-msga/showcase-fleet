# Tool: IP scanner (141026). Reads only; sends pings and opens a few ports, changes nothing.
param([string]$Network = '')
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')

$mine = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
  Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | ForEach-Object { $_.IPAddress })
$gateways = @(Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | ForEach-Object { $_.NextHop } | Where-Object { $_ -ne '0.0.0.0' })

if ($Network) {
  if ($Network -notmatch '^(\d{1,3})\.(\d{1,3})\.(\d{1,3})') { throw "'$Network' is not a network. Use the first three numbers, like 192.168.20." }
  $nets = @("$($Matches[1]).$($Matches[2]).$($Matches[3])")
} else {
  $nets = @($mine | ForEach-Object { ($_ -split '\.')[0..2] -join '.' } | Sort-Object -Unique)
}
if (-not $nets.Count) { throw 'This NUC has no network address, so there is nothing to scan.' }
Info "Scanning $($nets -join ', ') (254 addresses each)..."

# 1. ping every address at once; a ping also fills in the MAC table, even for devices that ignore pings
$pings = foreach ($n in $nets) { foreach ($i in 1..254) {
  $p = New-Object Net.NetworkInformation.Ping
  [pscustomobject]@{ Ip = "$n.$i"; Ping = $p; Task = $p.SendPingAsync("$n.$i", 1000) }
} }
try { [Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($pings | ForEach-Object { $_.Task }), 4000) | Out-Null } catch { }
$alive = @{}
foreach ($x in $pings) {
  if ($x.Task.Status -eq 'RanToCompletion' -and $x.Task.Result.Status -eq 'Success') { $alive[$x.Ip] = $x.Task.Result.RoundtripTime }
  $x.Ping.Dispose()
}
Start-Sleep -Milliseconds 500

$macs = @{}
Get-NetNeighbor -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {
  $_.State -notin 'Unreachable', 'Incomplete' -and $_.LinkLayerAddress -and $_.LinkLayerAddress -notmatch '^(00-){5}00$|^(FF-){5}FF$' -and $_.IPAddress -notmatch '\.(0|255)$'
} | ForEach-Object { $macs[$_.IPAddress] = $_.LinkLayerAddress }

$hosts = @(@($alive.Keys) + @($macs.Keys) + @($mine) | Where-Object { $ip = $_; $nets | Where-Object { $ip -like "$_.*" } } | Sort-Object -Unique)
Info "$($hosts.Count) devices answered. Checking their ports and names..."

# 2. a few ports that say what a device is
$portList = 22, 80, 443, 445, 554, 1400, 3000, 3389, 5000, 7000, 8008, 8080, 9000, 9100, 11000
$probes = foreach ($h in $hosts) { foreach ($port in $portList) {
  $c = New-Object Net.Sockets.TcpClient
  [pscustomobject]@{ Ip = $h; Port = $port; Client = $c; Task = $c.ConnectAsync($h, $port) }
} }
Start-Sleep -Milliseconds 1500
$open = @{}
foreach ($pr in $probes) {
  if ($pr.Task.Status -eq 'RanToCompletion' -and $pr.Client.Connected) { $open[$pr.Ip] = @($open[$pr.Ip]) + $pr.Port | Where-Object { $_ } }
  $pr.Client.Dispose()
}

# 3. names from the network's DNS, where it has them
$dns = foreach ($h in $hosts) { [pscustomobject]@{ Ip = $h; Task = [Net.Dns]::GetHostEntryAsync($h) } }
try { [Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($dns | ForEach-Object { $_.Task }), 2500) | Out-Null } catch { }
$names = @{}
foreach ($d in $dns) {
  if ($d.Task.Status -eq 'RanToCompletion' -and $d.Task.Result.HostName -and $d.Task.Result.HostName -ne $d.Ip) { $names[$d.Ip] = $d.Task.Result.HostName }
}

function Get-BluesoundName($ip) {
  try {
    $r = Invoke-WebRequest -Uri "http://$($ip):11000/SyncStatus" -UseBasicParsing -TimeoutSec 3
    if ($r.Content -match '<SyncStatus') { $n = ([xml]$r.Content).SyncStatus.name; if ($n) { return $n } }
  } catch { }
  $null
}

$devices = foreach ($h in $hosts) {
  $ports = @($open[$h] | Sort-Object)
  $name = $names[$h]
  $likely = ''
  if ($mine -contains $h) { $likely = 'This NUC' }
  elseif ($gateways -contains $h) { $likely = 'Router (the gateway)' }
  elseif ($ports -contains 11000) { $bn = Get-BluesoundName $h; $likely = if ($bn) { "Bluesound player: $bn" } else { 'Bluesound player?' } }
  elseif ($ports -contains 1400) { $likely = 'Sonos speaker' }
  elseif ($ports -contains 9000 -or $ports -contains 3000) { $likely = 'Another NUC (asset server or LED webserver)' }
  elseif ($ports -contains 8008) { $likely = 'Chromecast or Google TV' }
  elseif ($ports -contains 7000) { $likely = 'AirPlay device (Apple TV, smart TV)' }
  elseif ($ports -contains 9100) { $likely = 'Printer' }
  elseif ($ports -contains 554) { $likely = 'Camera' }
  elseif ($ports -contains 3389 -or $ports -contains 445) { $likely = 'Windows PC' }
  elseif ($ports -contains 5000) { $likely = 'Control device (port 5000, e.g. Kramer)' }
  elseif ($ports -contains 22 -and ($ports -contains 80 -or $ports -contains 443)) { $likely = 'Network device (router, switch, access point)' }
  elseif ($ports -contains 80 -or $ports -contains 443 -or $ports -contains 8080) { $likely = 'Has a web page (router, TV, controller)' }
  elseif ($name -match '^(AD-|NUC|DESKTOP-)') { $likely = 'Windows PC' }
  elseif (-not $alive.ContainsKey($h)) { $likely = 'Ignores pings (phone, tablet or locked-down device)' }
  [ordered]@{
    ip = $h; name = $name; mac = $macs[$h]; ports = $ports; likely = $likely
    ms = $alive[$h]; self = ($mine -contains $h)
  }
}
$devices = @($devices | Sort-Object { [version]$_.ip })
Ok "Found $($devices.Count) devices."
Send-Json @{ at = (Get-Date).ToString('h:mm tt'); networks = @($nets | ForEach-Object { "$_.0/24" }); devices = $devices }
