# showcase_startup_bat: status (trial 7). Returns a hashtable; reads only.
$fleet = Join-Path $env:ProgramData 'showcase_fleet'
$verFile = Join-Path $fleet 'launcher\version.txt'
if (-not (Test-Path $verFile)) { return @{ installed = $false } }
$version = "$(Get-Content $verFile -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
$running = [bool](Get-CimInstance Win32_Process -Filter "Name='cmd.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*showcase_startup_trial*' })
$mode = 'kiosk'
$cfgFile = Join-Path $fleet 'nuc.config'
if (Test-Path $cfgFile) { $m = Select-String -Path $cfgFile -Pattern '^LauncherMode=(.+)$' | Select-Object -First 1; if ($m) { $mode = $m.Matches[0].Groups[1].Value.Trim() } }
@{ installed = $true; version = $version; problem = -not $running
   detail = "Mode: $mode. $(if ($running) { 'Running.' } else { 'Not running right now: it starts at logon (or press Reopen Showcase now).' })" }
