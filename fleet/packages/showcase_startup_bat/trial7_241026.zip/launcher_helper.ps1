# Showcase Fleet: helper for showcase_startup.bat (trial 7, 24 Oct 2026). Runs hidden, as the display user.
#   -Action close      close Chrome and Edge, but never Fleet's own windows (known by their profile folder)
#   -Action logpath    print a new dated Chrome log path for console mode, and delete logs over 14 days old. The log
#                      can hold the page address, keys and all, so it lives in the display user's own folder.
#   -Action position   with the support screen installed: print where the real screen is, for Chrome
param([string]$Action = 'close')
$ErrorActionPreference = 'SilentlyContinue'
$logs = Join-Path $env:LOCALAPPDATA 'ShowcaseChromeLogs'

if ($Action -eq 'close') {
  Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='msedge.exe'" |
    Where-Object { $_.CommandLine -notmatch 'showcase_fleet_(manager_window|screen_\d)' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
  Start-Sleep -Seconds 2
}
elseif ($Action -eq 'logpath') {
  New-Item -ItemType Directory -Force -Path $logs | Out-Null
  Get-ChildItem $logs -Filter 'chrome_*.log' | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-14) } | Remove-Item -Force
  Join-Path $logs ('chrome_' + (Get-Date).ToString('yyyyMMdd_HHmmss') + '.log')
}
elseif ($Action -eq 'position') {
  # the support screen program lists the real screens left to right; Showcase goes on the first
  $state = Join-Path $env:ProgramData 'showcase_fleet\support_screen\state.json'
  $s = $null
  for ($i = 0; $i -lt 3 -and -not $s; $i++) { try { $s = Get-Content $state -Raw -ErrorAction Stop | ConvertFrom-Json } catch { Start-Sleep -Milliseconds 300 } }
  if (-not $s -or -not $s.supportScreen -or -not @($s.realScreens).Count) { return }
  $name = (@($s.realScreens)[0] -split ' ')[0]
  Add-Type -AssemblyName System.Windows.Forms
  $scr = [System.Windows.Forms.Screen]::AllScreens | Where-Object { $_.DeviceName -eq $name } | Select-Object -First 1
  if ($scr) { $b = $scr.Bounds; "--window-position=$($b.X),$($b.Y) --window-size=$($b.Width),$($b.Height)" }
}
