# showcase_startup_bat: "Reopen Showcase now" (trial 7). Stops the running launcher and starts it again as the
# display user, so it picks up a new URL or mode from This NUC.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$startup = Get-UserStartupDir
$vbs = Get-ChildItem -LiteralPath $startup -Filter 'showcase_startup_trial*.vbs' -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $vbs) { Fail 'The launcher is not installed.'; return }
Get-CimInstance Win32_Process -Filter "Name='cmd.exe' OR Name='wscript.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like '*showcase_startup_trial*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-AsDisplayUser (Join-Path $env:SystemRoot 'System32\wscript.exe') "`"$($vbs.FullName)`""
Ok "Reopening Showcase in $((Get-NucConfig).LauncherMode) mode."
