@echo off
rem showcase_startup_trial7_241026 (Showcase Fleet, trial 7, made 24 Oct 2026)
rem The fleet's standard startup (showcase_startup_210726), now one identical file on every NUC: the Showcase URL and
rem the mode come from C:\ProgramData\showcase_fleet\nuc.config, never from this file, so a new version of this
rem file can go to every NUC without touching anyone's URL. Run hidden at logon by the .vbs of the same name in the
rem display user's Startup folder, so no console window shows.
rem Modes (LauncherMode in nuc.config): kiosk (as 210726), console (kiosk plus remote debugging and a dated Chrome
rem log, inspect from the support screen with chrome://inspect), troubleshoot (a normal window with DevTools).
rem The URL is only ever used as !URL! (delayed expansion), so the & signs in it are never read as commands.
rem Trial 7: opens on the real screen when the support screen is installed; Chrome's log is in the user's own folder.
setlocal EnableDelayedExpansion
set "CFG=%ProgramData%\showcase_fleet\nuc.config"
set "URL="
set "MODE=kiosk"
if not exist "%CFG%" exit /b 1
for /f "usebackq tokens=1,* delims==" %%a in ("%CFG%") do (
  if /i "%%a"=="ShowcaseUrl" set "URL=%%b"
  if /i "%%a"=="LauncherMode" set "MODE=%%b"
)
if not defined URL exit /b 1
set "URL=!URL!&polling=true"
set "HELPER=%~dp0launcher_helper.ps1"
set "COMMON=--autoplay-policy=no-user-gesture-required --user-data-dir="%LOCALAPPDATA%\Google\Chrome\User Data\showcase" --disk-cache-size=2174836480 --no-first-run --disable-background-timer-throttling --disable-backgrounding-occluded-windows --disable-renderer-backgrounding --disable-features=CalculateNativeWinOcclusion,IntensiveWakeUpThrottling"
set "TAIL=--start-fullscreen"
if /i "!MODE!"=="troubleshoot" set "TAIL=--start-maximized --auto-open-devtools-for-tabs"
if /i "!MODE!"=="console" (
  for /f "delims=" %%p in ('powershell -NoProfile -ExecutionPolicy Bypass -File "%HELPER%" -Action logpath') do set "TAIL=--start-fullscreen --remote-debugging-port=9222 --enable-logging --log-file="%%p""
)
rem with the support screen installed, Windows' main display is the hidden one: open on the real screen instead
set "PLACE="
for /f "delims=" %%w in ('powershell -NoProfile -ExecutionPolicy Bypass -File "%HELPER%" -Action position') do set "PLACE=%%w"

rem Chrome or Edge sometimes open at startup; close them (never Fleet's own windows), then open Showcase
powershell -NoProfile -ExecutionPolicy Bypass -File "%HELPER%" -Action close
call :open temp

rem first run Chrome can force a popup; wait, then open it again cleanly
timeout /t 30 /nobreak >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%HELPER%" -Action close
call :open showcase

rem keep Showcase in front (as 210726), if NirCmd is on this NUC
:loop
where nircmd >nul 2>&1 && nircmd win activate title "showcase"
timeout /t 100 /nobreak >nul
goto loop

:open
if /i "!MODE!"=="troubleshoot" (
  start "" chrome.exe "!URL!" !COMMON! --window-name="%~1" !PLACE! !TAIL!
) else (
  start "" chrome.exe --kiosk "!URL!" !COMMON! --window-name="%~1" !PLACE! !TAIL!
)
exit /b
