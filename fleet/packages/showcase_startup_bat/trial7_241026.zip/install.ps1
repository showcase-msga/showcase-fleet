# showcase_startup_bat: install or update (trial 7, 24 Oct 2026)
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$Version  = 'trial7_241026'
$Launcher = Join-Path $FleetData 'launcher'
$Bat      = "showcase_startup_$Version.bat"
$Vbs      = "showcase_startup_$Version.vbs"

$cfg = Get-NucConfig
if (-not $cfg.ShowcaseUrl) { Fail 'No Showcase URL for this NUC yet. Set it in This NUC (or press "Read from this NUC" there), save, then install this again.'; return }
Ok "Showcase URL from This NUC: $(Hide-UrlKeys $cfg.ShowcaseUrl)"
Info "Mode: $($cfg.LauncherMode)"

# one launcher per NUC
$kioskRemove = Join-Path $PSScriptRoot '..\startup_kiosk\remove.ps1'
if ((Get-ScheduledTask -TaskName 'Showcase Kiosk' -ErrorAction SilentlyContinue) -and (Test-Path $kioskRemove)) {
  Info 'Removing Startup Kiosk first (one launcher per NUC)...'
  & $kioskRemove
}

# stop an older copy of this launcher, then set aside any other Showcase startup script
Get-CimInstance Win32_Process -Filter "Name='cmd.exe' OR Name='wscript.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like '*showcase_startup_trial*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$startup = Get-UserStartupDir
Get-ChildItem -LiteralPath $startup -Filter 'showcase_startup_trial*.vbs' -ErrorAction SilentlyContinue | Remove-Item -Force
$moved = @(Move-OldStartup (Join-Path $Launcher 'old_startup'))
if ($moved.Count) { $moved | ForEach-Object { Ok "Set aside: $_" } } else { Info 'No other Showcase startup script found.' }

Protect-FleetData
Step "Launcher files in $Launcher" {
  New-Item -ItemType Directory -Force -Path $Launcher | Out-Null
  Get-ChildItem $Launcher -Filter 'showcase_startup_trial*.bat' -ErrorAction SilentlyContinue | Remove-Item -Force
  Copy-Item (Join-Path $PSScriptRoot 'showcase_startup.bat') (Join-Path $Launcher $Bat) -Force
  Copy-Item (Join-Path $PSScriptRoot 'launcher_helper.ps1') (Join-Path $Launcher 'launcher_helper.ps1') -Force
  Set-Content (Join-Path $Launcher 'version.txt') $Version
}
# trial 6 kept Chrome's console log here, where its keys were readable; it's in the display user's own folder now
$oldLogs = Join-Path $FleetData 'chrome_logs'
if (Test-Path $oldLogs) { Step 'Removed the old Chrome log folder (logs are in the display user''s own folder now)' { Remove-Item $oldLogs -Recurse -Force } }
Step "Starts at logon, hidden ($Vbs in the display user's Startup folder)" {
  Copy-Item (Join-Path $PSScriptRoot 'showcase_startup.vbs') (Join-Path $startup $Vbs) -Force
}

Info 'Opening Showcase now (as the display user)...'
try { Start-AsDisplayUser (Join-Path $env:SystemRoot 'System32\wscript.exe') "`"$(Join-Path $startup $Vbs)`""; Ok 'Started. Showcase opens in a few seconds, and again cleanly after 30 seconds.' }
catch { Warn "Couldn't start it now ($($_.Exception.Message)); it starts at the next logon." }
