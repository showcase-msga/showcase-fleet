' Showcase Fleet (trial 7, 24 Oct 2026): runs the fleet's standard startup bat hidden at logon, so no console
' window ever shows. Sits in the display user's Startup folder; the bat and its helper live in
' C:\ProgramData\showcase_fleet\launcher\. The bat has this file's own name, and if it's missing nothing shows
' (no "cannot find the file" box on the TV).
On Error Resume Next
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
bat = sh.ExpandEnvironmentStrings("%ProgramData%") & "\showcase_fleet\launcher\" & fso.GetBaseName(WScript.ScriptName) & ".bat"
If fso.FileExists(bat) Then sh.Run """" & bat & """", 0, False
