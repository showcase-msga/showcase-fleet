# showcase_startup_bat: remove (trial 7). Stops the launcher, takes it out of Startup, and puts back whatever
# startup script it set aside. Showcase itself stays open until the next restart.
# Trial 7: the launcher's .vbs is taken out of every profile's Startup folder, so none is left pointing at a bat
# that's gone (even if the display user can't be found right now).
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$Launcher = Join-Path $FleetData 'launcher'
Get-CimInstance Win32_Process -Filter "Name='cmd.exe' OR Name='wscript.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like '*showcase_startup_trial*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$profiles = @(Get-CimInstance Win32_UserProfile -ErrorAction SilentlyContinue | Where-Object { -not $_.Special -and $_.LocalPath } | ForEach-Object LocalPath)
foreach ($p in $profiles) {
  Get-ChildItem -LiteralPath "$p\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -Filter 'showcase_startup_trial*.vbs' -ErrorAction SilentlyContinue |
    ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force; Ok "Out of Startup: $($_.FullName)" }
}
$back = @(Restore-OldStartup (Join-Path $Launcher 'old_startup'))
if ($back.Count) { $back | ForEach-Object { Ok "Put back: $_" } } else { Warn 'Nothing was set aside, so no startup script is in place now: Showcase will not open at the next logon until a launcher is installed.' }
Get-ChildItem $Launcher -Filter 'showcase_startup_trial*.bat' -ErrorAction SilentlyContinue | Remove-Item -Force
Remove-Item (Join-Path $Launcher 'version.txt'), (Join-Path $Launcher 'launcher_helper.ps1') -Force -ErrorAction SilentlyContinue
Ok 'showcase_startup.bat removed.'
