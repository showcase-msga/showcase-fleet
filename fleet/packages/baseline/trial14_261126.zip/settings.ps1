# Showcase Fleet module: baseline (trial 9, 10 Nov 2026; trial 13, 24 Nov 2026: the adapters setting fixed and made
# non-critical, Wake on LAN back on, and a 'critical' flag per setting for the agent's check; trial 14, 26 Nov 2026:
# auto-login proved from the last start, and a time zone check with a 'warn' flag). Our recommended NUC settings.
# Checks each one against what we recommend and, when asked, applies the ticked ones
# (-Apply fast_startup,delivery_optimisation,...). Every change is a registry value, a powercfg
# setting or a SYSTEM scheduled task, so nothing shows on the display. Changes go to
# C:\ProgramData\showcase_fleet\baseline\baseline.log, and the last check to last_check.json, which the
# Fleet window shows. Later the agent keeps these set for good; for now it's by hand.
param([string]$Apply = '')
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
. (Join-Path $PSScriptRoot 'restart_common.ps1')
$ErrorActionPreference = 'Continue'
$Version = 'trial14_261126'
$Data = Get-ModuleData 'baseline'
$Log  = Join-Path $Data 'baseline.log'

function Write-BaselineLog($m) { try { Add-Content -Path $Log -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m" -Encoding UTF8; Limit-Log $Log } catch { } }
function Get-Reg($path, $name) { (Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue).$name }

# "Current AC Power Setting Index: 0x00000000" (mains power; a NUC has no battery)
function Get-PowerAc($sub, $setting) {
  $line = & powercfg.exe /q SCHEME_CURRENT $sub $setting 2>$null | Where-Object { $_ -match 'Current AC Power Setting Index:\s*0x([0-9a-f]+)' } | Select-Object -First 1
  if ($line -and $line -match '0x([0-9a-f]+)') { [Convert]::ToInt32($Matches[1], 16) } else { $null }
}
function Format-Minutes($seconds) { if ($seconds -eq 0) { 'Never' } elseif ($null -eq $seconds) { 'Unknown' } else { "After $([math]::Round($seconds / 60)) min" } }

$PowerKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power'
$DoKey    = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'
$NetClass = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}'

# ---- network adapter power (trial 13). For each physical adapter: is Windows allowed to turn it off to save power?
# MSPower_DeviceEnable is the tick on Device Manager's Power Management tab ('Enable' true = allowed). A driver with
# no entry there falls back to the adapter's own report, or to PnPCapabilities 0x18 (= unticked, from the next restart).
function Get-AdapterClassKey($adapter) {
  Get-ChildItem $NetClass -ErrorAction SilentlyContinue | Where-Object {
    (Get-ItemProperty $_.PSPath -Name NetCfgInstanceId -ErrorAction SilentlyContinue).NetCfgInstanceId -eq $adapter.InterfaceGuid } | Select-Object -First 1
}
function Get-MsPowerEntry($adapter) {
  $pnp = "$($adapter.PnPDeviceID)"
  if (-not $pnp) { return $null }
  Get-CimInstance -Namespace root/wmi -ClassName MSPower_DeviceEnable -ErrorAction SilentlyContinue |
    Where-Object { "$($_.InstanceName)".StartsWith($pnp, [StringComparison]::OrdinalIgnoreCase) } | Select-Object -First 1
}
function Get-AdapterPower {
  foreach ($a in @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue)) {
    $ms  = Get-MsPowerEntry $a
    $pm  = Get-NetAdapterPowerManagement -Name $a.Name -ErrorAction SilentlyContinue
    $key = Get-AdapterClassKey $a
    $cap = if ($key) { (Get-ItemProperty $key.PSPath -Name PnPCapabilities -ErrorAction SilentlyContinue).PnPCapabilities } else { $null }
    # PnPCapabilities only takes at a restart: still allowed after one since Baseline set it means the driver ignores it
    $pending = $false
    if ($null -ne $cap -and ($cap -band 0x18) -eq 0x18 -and "$($pm.AllowComputerToTurnOffDevice)" -eq 'Enabled') {
      $setAt = try { [datetime](Get-Content (Join-Path $Data 'adapter_pnp_set.txt') -ErrorAction Stop | Select-Object -First 1) } catch { $null }
      $pending = $setAt -and (Get-CimInstance Win32_OperatingSystem).LastBootUpTime -lt $setAt
    }
    $state = if (-not $ms -and -not $pm) { 'unknown' }          # nothing readable (not admin, or the driver reports nothing)
             elseif ($ms) { if ($ms.Enable) { 'allowed' } else { 'never' } }
             elseif ($pending) { 'next restart' }
             elseif ("$($pm.AllowComputerToTurnOffDevice)" -eq 'Enabled') { 'allowed' } else { 'never' }
    $wol = if ($pm -and "$($pm.WakeOnMagicPacket)" -in @('Enabled', 'Disabled')) { "$($pm.WakeOnMagicPacket)".ToLower() -replace 'enabled', 'on' -replace 'disabled', 'off' } else { $null }
    [pscustomobject]@{ name = $a.Name; state = $state; wol = $wol }
  }
}
function Set-AdapterPowerNever {
  foreach ($a in @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue)) {
    $ms = Get-MsPowerEntry $a
    if ($ms) {
      if ($ms.Enable) { Set-CimInstance -InputObject $ms -Property @{ Enable = $false } -ErrorAction Stop; Write-BaselineLog "Adapter $($a.Name): power saving off (Device Manager tick)" }
    } else {
      $key = Get-AdapterClassKey $a
      if ($key) {
        $cap = (Get-ItemProperty $key.PSPath -Name PnPCapabilities -ErrorAction SilentlyContinue).PnPCapabilities
        $new = [int]$(if ($null -eq $cap) { 0 } else { $cap }) -bor 0x18
        if ($cap -ne $new) { New-ItemProperty -Path $key.PSPath -Name PnPCapabilities -PropertyType DWord -Value $new -Force | Out-Null
                             (Get-Date).ToString('s') | Set-Content (Join-Path $Data 'adapter_pnp_set.txt') -Encoding UTF8
                             Write-BaselineLog "Adapter $($a.Name): PnPCapabilities $cap to $new (from the next restart)" }
      }
    }
    # Wake on LAN back on, where the adapter has it (trials 9 to 11 switched it off). Takes effect at the next restart.
    $pm = Get-NetAdapterPowerManagement -Name $a.Name -ErrorAction SilentlyContinue
    if ($pm -and "$($pm.WakeOnMagicPacket)" -eq 'Disabled') {
      try { Enable-NetAdapterPowerManagement -Name $a.Name -WakeOnMagicPacket -NoRestart -ErrorAction Stop; Write-BaselineLog "Adapter $($a.Name): Wake on LAN back on" }
      catch { Write-BaselineLog "Adapter $($a.Name): Wake on LAN not switched on ($($_.Exception.Message))" }
    }
  }
}

# each: what we recommend, how to read what it is now, and (if we can set it) how to set it
$Settings = @(
  @{ id = 'fast_startup'; name = 'Fast Startup'; recommended = 'Off'
     about = "With Fast Startup on, a shutdown is really hibernation, so scheduled restarts don't give a clean start (Dacre, Camberwell)."
     check = { $v = Get-Reg $PowerKey 'HiberbootEnabled'; @{ ok = ($v -eq 0); now = $(if ($v -eq 0) { 'Off' } elseif ($null -eq $v) { 'On (Windows default)' } else { 'On' }) } }
     apply = { Set-RegDword $PowerKey 'HiberbootEnabled' 0 } }

  @{ id = 'hibernation'; name = 'Hibernation'; recommended = 'Off'
     about = "Stops Fast Startup coming back on (it did at Camberwell). Leave it unticked on NUCs that run Jotham's nightly hibernate script, which needs hibernation."
     check = { $v = Get-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' 'HibernateEnabled'; @{ ok = ($v -eq 0); now = $(if ($v -eq 0) { 'Off' } else { 'On' }) } }
     apply = { & powercfg.exe /hibernate off; if ($LASTEXITCODE -ne 0) { throw "powercfg code $LASTEXITCODE" } } }

  @{ id = 'delivery_optimisation'; name = 'Delivery Optimisation peering'; recommended = 'Off (policy)'
     about = "Stops the NUC sharing Windows updates with other PCs and the internet, which can saturate a suite's 4G. Set as a machine policy, the only way it sticks."
     check = { $v = Get-Reg $DoKey 'DODownloadMode'; @{ ok = ($v -eq 0); now = $(if ($v -eq 0) { 'Off (policy)' } elseif ($null -eq $v) { 'On (no policy)' } else { "Policy mode $v" }) } }
     apply = {
       if (-not (Test-Path $DoKey)) { New-Item -Path $DoKey -Force | Out-Null }   # new key only; never -Force on one that exists
       New-ItemProperty -Path $DoKey -Name DODownloadMode -PropertyType DWord -Value 0 -Force | Out-Null
       if ((Get-Service DoSvc -ErrorAction SilentlyContinue).Status -eq 'Running') { Restart-Service DoSvc -Force -ErrorAction SilentlyContinue }
     } }

  @{ id = 'never_sleep'; name = 'Sleep and hibernate on mains'; recommended = 'Never'
     about = 'The NUC never goes to sleep or hibernates by itself.'
     check = { $s = Get-PowerAc 'SUB_SLEEP' 'STANDBYIDLE'; $h = Get-PowerAc 'SUB_SLEEP' 'HIBERNATEIDLE'
               @{ ok = ($s -eq 0 -and ($h -eq 0 -or $null -eq $h)); now = "Sleep: $(Format-Minutes $s). Hibernate: $(Format-Minutes $h)" } }
     apply = { & powercfg.exe /change standby-timeout-ac 0; & powercfg.exe /change hibernate-timeout-ac 0 } }

  @{ id = 'screen_on'; name = 'Screen turns off'; recommended = 'Never'
     about = 'Windows never blanks the display by itself. Showcase Blackout, where it is used, still blacks the screen at night.'
     check = { $v = Get-PowerAc 'SUB_VIDEO' 'VIDEOIDLE'; @{ ok = ($v -eq 0); now = Format-Minutes $v } }
     apply = { & powercfg.exe /change monitor-timeout-ac 0 } }

  # Trial 13 (24 Nov 2026). Trial 9 to 11 set this with Disable-NetAdapterPowerManagement and no switches, which
  # can't untick "Allow the computer to turn off this device" (no cmdlet has that switch on Windows 11 26200) and
  # turns off every other power feature instead, Wake on LAN included. So the check could never pass, and Baseline
  # failed on 8 of the first 13 live NUCs. Now: the tick itself, through MSPower_DeviceEnable (what Device
  # Manager's Power Management tab sets; takes effect at once), or PnPCapabilities 0x18 where a driver has no such
  # entry (takes effect at the next restart, 4:30 am). Wake on LAN is switched back on. Not critical: a driver
  # that won't take it is reported, and the rest of Baseline still counts as installed.
  @{ id = 'adapters_awake'; name = 'Network adapters powered down to save power'; recommended = 'Never'; critical = $false
     about = "Windows never switches a network adapter off, Wi-Fi runs at maximum performance, and Wake on LAN stays on. Some drivers don't let Windows change this; Baseline reports it and carries on."
     check = {
       $rows = @(Get-AdapterPower)
       $on   = @($rows | Where-Object { $_.state -eq 'allowed' } | ForEach-Object { $_.name })
       $soon = @($rows | Where-Object { $_.state -eq 'next restart' } | ForEach-Object { $_.name })
       $wol  = @($rows | Where-Object { $_.wol } | ForEach-Object { "$($_.name) $($_.wol)" })
       $unk  = @($rows | Where-Object { $_.state -eq 'unknown' } | ForEach-Object { $_.name })
       @{ ok = ($rows.Count -gt 0 -and $on.Count -eq 0 -and $unk.Count -eq 0)
          now = $(if (-not $rows.Count) { 'No adapters read' } elseif ($unk.Count -and -not (Test-Admin)) { 'Needs admin to read' }
                  elseif ($unk.Count) { "Couldn't read: $($unk -join ', ')" } elseif ($on.Count) { "Allowed: $($on -join ', ')" }
                  elseif ($soon.Count) { "Never (from the next restart: $($soon -join ', '))" } else { 'Never' }) +
                $(if ($wol.Count) { ". Wake on LAN: $($wol -join ', ')" } else { '' }) } }
     apply = {
       & powercfg.exe /setacvalueindex SCHEME_CURRENT 19cbb8fa-5279-450e-9fac-8a3d5fedd0c1 12bbebe6-58d6-4636-95bb-3217ef867c1a 0
       & powercfg.exe /setactive SCHEME_CURRENT
       Set-AdapterPowerNever
     } }

  # trial 14: AutoAdminLogon alone read Off on 12 of 13 NUCs that do sign in by themselves; Get-AutoLoginState
  # (Fleet core's common.ps1, trial 14) also takes the last start as proof. Still a check only: never set by Fleet.
  @{ id = 'auto_login'; name = 'Auto-login'; recommended = 'On'
     about = "After a restart the NUC signs in by itself, so Showcase comes back. Proved from the last start when the AutoAdminLogon setting isn't used (a NUC can sign in by itself without it). Set by hand: it needs the account password."
     check = {
       if (Get-Command Get-AutoLoginState -ErrorAction SilentlyContinue) { Get-AutoLoginState }
       else { $w = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -ErrorAction SilentlyContinue
              @{ ok = ("$($w.AutoAdminLogon)" -eq '1'); now = $(if ("$($w.AutoAdminLogon)" -eq '1') { "On, as $($w.DefaultUserName)" } else { 'AutoAdminLogon not set (update Fleet core to trial 14 for the full check)' }) } } } }

  # trial 14: the clock's time zone against the site's state (from the nucId; Get-SiteTimeZone in common.ps1). Fleet's
  # whole night runs on local time (1am install, 2am check, 3am updates, 4:30 restart), so a NUC on the wrong zone does
  # all of it in the wrong hours: 671 Chapel SY-LED was on Pacific time (24 Nov), so its 4:30 am restart came at about
  # 11:30 pm in Melbourne. A check, shown as a problem when wrong ('warn'); never set by itself, because the prefix is
  # the owning state and a site in another state needs its bracket. The action sets it, on a tech's say-so.
  @{ id = 'time_zone'; name = 'Time zone'; recommended = "The site's state"; warn = $true
     about = "Fleet's night (1am install, 2am check, 3am updates, 4:30 am restart) runs on the NUC's own clock, so the time zone must be the site's. The state comes from the nucId: a bracket like (SA) where the site is in another state, otherwise the prefix (2 NSW, 3 VIC, 4 QLD). 'Set the time zone' sets it; nothing on the display changes."
     check = {
       $z = (Get-TimeZone).Id
       $e = if (Get-Command Get-SiteTimeZone -ErrorAction SilentlyContinue) { Get-SiteTimeZone } else { $null }
       if (-not $e) { @{ ok = $true; now = "$z (the nucId doesn't say which state, so not checked)" } }
       elseif ($z -eq $e.zone) { @{ ok = $true; now = "$z ($($e.state))" } }
       else { @{ ok = $false; now = "$z, not $($e.zone) for $($e.state)" } } } }

  @{ id = 'activated'; name = 'Windows activated'; recommended = 'Yes'
     about = "An unactivated NUC shows the 'Activate Windows' watermark over Showcase."
     check = { $l = Get-CimInstance SoftwareLicensingProduct -Filter "PartialProductKey IS NOT NULL AND Name LIKE 'Windows%'" -ErrorAction SilentlyContinue | Select-Object -First 1
               @{ ok = ($l.LicenseStatus -eq 1); now = $(if ($l.LicenseStatus -eq 1) { 'Yes' } else { "No (status $($l.LicenseStatus))" }) } } }

  @{ id = 'windows_update'; name = 'Windows Update'; recommended = 'On, nights only (Quiet)'
     about = 'Some old setups switched Windows Update off. The Quiet module turns it back on and keeps updates to the night.'
     check = { $s = Get-Service wuauserv -ErrorAction SilentlyContinue
               @{ ok = ($s -and "$($s.StartType)" -ne 'Disabled'); now = $(if (-not $s) { 'Not found' } else { "Service $($s.StartType), $($s.Status)" }) } } }

  @{ id = 'daily_restart'; name = 'Daily restart'; recommended = "Fleet's, at $RestartLabel"
     about = "One restart a day at $RestartLabel, as SYSTEM, with nothing on the display. Any other restart task on this NUC is set aside (switched off and listed in the log), so it never restarts twice; 'Put back the old restart' undoes it. If the NUC is off at $RestartLabel it doesn't restart late."
     check = {
       $ours   = Get-ScheduledTask -TaskName $RestartTaskName -TaskPath '\' -ErrorAction SilentlyContinue
       $others = @(Get-RestartTasks | Where-Object { $_.TaskName -ne $RestartTaskName -and $_.State -ne 'Disabled' } | ForEach-Object { Format-RestartTask $_ })
       $oursOn = [bool]($ours -and $ours.State -ne 'Disabled')
       $now = @()
       if ($oursOn) { $now += "Fleet's at $(Format-RestartTask $ours -TimeOnly)" } elseif ($ours) { $now += "Fleet's, switched off" }
       if ($others.Count) { $now += "Other: $($others -join '; ')" }
       @{ ok = ($oursOn -and -not $others.Count); now = $(if ($now.Count) { $now -join '. ' } else { 'None found' }) } }
     apply = {
       # set the others aside first, so the NUC never has two restarts at once
       $saved = @(Get-SetAsideRestarts)
       foreach ($t in @(Get-RestartTasks | Where-Object { $_.TaskName -ne $RestartTaskName -and $_.State -ne 'Disabled' })) {
         Disable-ScheduledTask -TaskName $t.TaskName -TaskPath $t.TaskPath -ErrorAction Stop | Out-Null
         if (-not ($saved | Where-Object { $_.name -eq $t.TaskName -and $_.path -eq $t.TaskPath })) {
           $saved += [pscustomobject]@{ name = $t.TaskName; path = $t.TaskPath; was = (Format-RestartTask $t); at = (Get-Date).ToString('s') }
         }
         Write-BaselineLog "Set aside restart task $($t.TaskPath)$($t.TaskName) ($(Format-RestartTask $t))"
       }
       Save-SetAsideRestarts $saved
       Register-FleetRestart
       Write-BaselineLog "Fleet daily restart at $RestartLabel ($RestartTaskName)"
     } }
)

# ---- apply the ticked ones
$want = @($Apply -split '[,\s]+' | Where-Object { $_ })
# 'all' = every setting Baseline can set (the agent's nightly install, 23 Nov 2026)
if ($want -contains 'all') { $want = @($Settings | Where-Object { $_.apply } | ForEach-Object { $_.id }) }
if ($want.Count) {
  if (-not (Test-Admin)) { Fail 'Changing settings needs admin. Open Fleet from its desktop shortcut, which asks for it.' }
  else {
    foreach ($id in $want) {
      $s = $Settings | Where-Object { $_.id -eq $id }
      if (-not $s) { Warn "Unknown setting '$id', skipped."; continue }
      if (-not $s.apply) { Warn "$($s.name) is set by hand, skipped."; continue }
      try { & $s.apply | Out-Null; Ok "$($s.name): set to $($s.recommended)"; Write-BaselineLog "OK   $id" }
      catch { Fail "$($s.name): $($_.Exception.Message)"; Write-BaselineLog "FAIL $id - $($_.Exception.Message)" }
    }
  }
}

# ---- check every setting against what we recommend
$rows = foreach ($s in $Settings) {
  try { $r = & $s.check } catch { $r = @{ ok = $false; now = "Could not read: $($_.Exception.Message)" } }
  # critical (trial 13): whether the agent's 2am check fails Baseline over this setting. Only the adapters one isn't:
  # some drivers won't take it, and it mustn't hold back the daily restart and the rest.
  # warn (trial 14): a check-only setting that shows as a problem when it isn't right (the time zone), though Fleet
  # doesn't set it; it never fails the agent's 2am check, which looks only at settings Fleet can set
  [ordered]@{ id = $s.id; name = $s.name; about = $s.about; recommended = $s.recommended; now = "$($r.now)"; ok = [bool]$r.ok; canApply = [bool]$s.apply
              critical = $(if ($null -eq $s.critical) { $true } else { [bool]$s.critical }); warn = [bool]$s.warn }
}
$done = @($rows | Where-Object { $_.ok }).Count
$result = [ordered]@{ version = $Version; at = (Get-Date).ToString('ddd d MMM, h:mm tt'); done = $done; total = @($rows).Count; settings = @($rows) }
try { $result | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $Data 'last_check.json') -Encoding UTF8 } catch { }
Info "$done of $(@($rows).Count) settings as recommended on $env:COMPUTERNAME."
Send-Json $result
