# baseline: status (trial 13, 24 Nov 2026; trial 14, 26 Nov 2026). Reads the last check only, so the window stays quick; Check runs a fresh one.
# Trial 13: "installed" no longer needs every setting as recommended. Up to trial 11 it needed done = total, which counts
# the settings set by hand (auto-login, activation, Windows Update) and the adapters one some drivers won't take, so a NUC
# with auto-login off never showed Baseline as installed (Wahroonga, 23 Nov). Now: installed when every critical setting
# Fleet can set is as recommended; anything else Fleet can set but isn't right shows as a problem, by name.
# Trial 14: a check-only setting marked 'warn' (the time zone) also shows as a problem when it isn't right; it never
# affects "installed".
$file = Join-Path $env:ProgramData 'showcase_fleet\baseline\last_check.json'
if (-not (Test-Path $file)) { return @{ installed = $false; detail = 'Not checked on this NUC yet. Open the row and press Check.' } }
try { $c = Get-Content $file -Raw | ConvertFrom-Json } catch { return @{ installed = $false; detail = 'The last check could not be read. Check again.' } }
$off  = @($c.settings | Where-Object { ($_.canApply -or $_.warn) -and -not $_.ok })
$hard = @($off | Where-Object { $_.canApply -and ($null -eq $_.critical -or $_.critical) })   # a last check from before trial 13 has no 'critical': all count
$detail = "$($c.done) of $($c.total) as recommended at the last check, $($c.at)."
if ($off.Count) { $detail += " Not as recommended: $(@($off | ForEach-Object { if ($_.warn) { "$($_.name) ($($_.now))" } else { $_.name } }) -join ', ')." }
@{ installed = ($hard.Count -eq 0); problem = ($off.Count -gt 0); version = "$($c.version)"; done = [int]$c.done; total = [int]$c.total; at = "$($c.at)"
   detail = $detail }
