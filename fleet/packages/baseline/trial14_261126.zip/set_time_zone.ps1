# baseline action: set the time zone to the site's state (trial 14, 26 Nov 2026). Run from the console (Module
# action) or the Fleet window, on a tech's say-so; Baseline never does it by itself. The state comes from the nucId
# (Get-SiteTimeZone in Fleet core's common.ps1): a bracket like (SA), otherwise the prefix (2 NSW, 3 VIC, 4 QLD).
# Nothing on the display changes and nothing restarts; Fleet's night moves to the right hours from tonight.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$ErrorActionPreference = 'Continue'
$Log = Join-Path (Get-ModuleData 'baseline') 'baseline.log'
function Write-BaselineLog($m) { try { Add-Content -Path $Log -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m" -Encoding UTF8; Limit-Log $Log } catch { } }

if (-not (Get-Command Get-SiteTimeZone -ErrorAction SilentlyContinue)) { Fail 'This needs Fleet core trial 14 or later on the NUC.'; return }
$e = Get-SiteTimeZone
if (-not $e) { Fail "The nucId ('$((Get-NucConfig).NucId)') doesn't say which state, so Fleet won't guess. Set the time zone by hand in Windows' Date and time settings."; return }
$was = (Get-TimeZone).Id
if ($was -eq $e.zone) { Ok "Already on $($e.zone) ($($e.state)). Nothing changed."; return }
if (-not (Test-Admin)) { Fail 'Changing the time zone needs admin.'; return }
try {
  Set-TimeZone -Id $e.zone -ErrorAction Stop
  Write-BaselineLog "OK   time zone $was to $($e.zone) ($($e.state), from the nucId)"
  Ok "Time zone $was to $($e.zone) ($($e.state)). The clock now reads $((Get-Date).ToString('ddd d MMM, h:mm tt'))."
} catch { Fail "The time zone wasn't changed: $($_.Exception.Message)"; Write-BaselineLog "FAIL time zone - $($_.Exception.Message)"; return }
# a fresh check, so the window and the dashboard show it straight away
& (Join-Path $PSScriptRoot 'settings.ps1') | Out-Null
