# Showcase Analytics: switches Chrome's local debugging connection on in the NUC's own startup launcher (trial 15,
# 28 Nov 2026; Jordan chose this: "Module patches each bat"). Dot-sourced by install.ps1, remove.ps1 and status.ps1.
#
# What it changes, and only this: on a launcher line that starts Chrome with --kiosk, '--kiosk' becomes
# '--remote-debugging-port=92NN --kiosk'. Nothing else in the file moves. Before the first change the original is
# copied to analytics\backup, and removing the module puts it back (or, if someone has edited the file since, takes
# just the flag out again).
#
# It only patches a launcher that runs Chrome with its own profile (--user-data-dir somewhere in the file): Chrome 136+
# ignores the debugging port on Chrome's default profile, and switching a suite to a new profile would lose its pairing
# and cache, so those are left alone and reported. The connection answers on the NUC itself only (127.0.0.1).
# Takes effect the next time Chrome starts (the 4:30am daily restart, or a Chrome restart).

# SHOWCASE_FLEET_TEST_HOME (tests on a PC that isn't a NUC): everything, the Startup folder included, is in that folder
$TestHome = $env:SHOWCASE_FLEET_TEST_HOME
$AnalyticsHome = if ($TestHome) { Join-Path $TestHome 'analytics' } else { Join-Path $env:ProgramData 'showcase_fleet\analytics' }
$BackupDir = Join-Path $AnalyticsHome 'backup'
$PatchIndex = Join-Path $BackupDir 'patched.json'
$PortFlag = '--remote-debugging-port='
$Utf8NoBom = New-Object Text.UTF8Encoding $false

# every launcher file Windows starts at sign-in: the all-users and per-user Startup folders, plus one level of
# .bat/.cmd/.vbs that those call by full path (SC_Startup.bat often calls C:\Showcase\Showcase.bat)
function Get-LauncherFiles {
  $dirs = @("$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp")
  foreach ($u in Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue) {
    $d = Join-Path $u.FullName 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup'
    if (Test-Path $d) { $dirs += $d }
  }
  if ($TestHome) { $dirs = @(Join-Path $TestHome 'startup') }
  $found = @{}
  foreach ($d in $dirs) {
    foreach ($f in Get-ChildItem $d -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '^\.(bat|cmd|vbs)$' }) { $found[$f.FullName] = $true }
  }
  foreach ($f in @($found.Keys)) {
    try {
      $text = (Read-Launcher $f).text
      foreach ($m in [regex]::Matches($text, '(?i)[a-z]:\\[^"''\r\n<>|*?]+?\.(bat|cmd|vbs)\b')) {
        if (Test-Path -LiteralPath $m.Value) { $found[(Resolve-Path -LiteralPath $m.Value).Path] = $true }
      }
    } catch { }
  }
  @($found.Keys | Sort-Object)
}

# a launcher line that opens Showcase in kiosk Chrome
function Test-KioskLine([string]$line) {
  if ($line -notmatch '(?i)--kiosk') { return $false }
  if ($line -match '^\s*(::|rem\s|'')') { return $false }   # comments
  $true
}

function Get-PatchIndex {
  # PowerShell 5.1's ConvertFrom-Json hands back a JSON array as one item: piping it on unrolls it into entries
  if (Test-Path $PatchIndex) { try { $j = Get-Content $PatchIndex -Raw -Encoding UTF8 | ConvertFrom-Json; return @($j | ForEach-Object { $_ } | Where-Object { $_ -and $_.file }) } catch { } }
  @()
}

function Save-PatchIndex($items) {
  New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
  [IO.File]::WriteAllText($PatchIndex, (ConvertTo-Json -InputObject @($items | Where-Object { $_ }) -Depth 4), $Utf8NoBom)
}

function Get-FileSha([string]$path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }

# reads a launcher in its own encoding (UTF-8 with a BOM, otherwise the PC's ANSI code page, as cmd.exe reads bats)
function Read-Launcher([string]$path) {
  $raw = [IO.File]::ReadAllBytes($path)
  $bom = $raw.Length -ge 3 -and $raw[0] -eq 0xEF -and $raw[1] -eq 0xBB -and $raw[2] -eq 0xBF
  $enc = if ($bom) { New-Object Text.UTF8Encoding $true } else { [Text.Encoding]::Default }
  [pscustomobject]@{ raw = $raw; enc = $enc; text = [IO.File]::ReadAllText($path, $enc) }
}

# what each launcher looks like now: patched, can be patched, or why not
function Get-LauncherReport {
  $out = @()
  foreach ($f in Get-LauncherFiles) {
    $text = (Read-Launcher $f).text
    $lines = $text -split "`r?`n"
    $kiosk = @($lines | Where-Object { Test-KioskLine $_ })
    if (-not $kiosk.Count) { continue }
    $ownProfile = $text -match '(?i)--user-data-dir'
    $done = @($kiosk | Where-Object { $_ -match "(?i)$([regex]::Escape($PortFlag))\d+" }).Count
    $out += [pscustomobject]@{ file = $f; kioskLines = $kiosk.Count; patched = $done; ownProfile = $ownProfile }
  }
  $out
}

# adds the port to every kiosk line not already carrying one; ports 9222 up, one per kiosk window across the NUC
function Invoke-LauncherPatch {
  $index = @(Get-PatchIndex)
  $notes = @()
  $used = New-Object 'System.Collections.Generic.HashSet[int]'
  $all = Get-LauncherFiles
  foreach ($f in $all) {
    foreach ($m in [regex]::Matches((Read-Launcher $f).text, "(?i)$([regex]::Escape($PortFlag))(\d+)")) { [void]$used.Add([int]$m.Groups[1].Value) }
  }
  $next = 9222
  foreach ($f in $all) {
    $rl = Read-Launcher $f
    $raw = $rl.raw; $text = $rl.text
    $nl = if ($text -match "`r`n") { "`r`n" } else { "`n" }
    $lines = $text -split "`r?`n"
    if (-not @($lines | Where-Object { Test-KioskLine $_ }).Count) { continue }
    if ($text -notmatch '(?i)--user-data-dir') {
      $notes += "Not changed: $f starts Chrome on its default profile, where Chrome ignores the debugging port. Move this NUC to a Fleet launcher to get analytics."
      continue
    }
    $changed = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
      if (-not (Test-KioskLine $lines[$i]) -or $lines[$i] -match "(?i)$([regex]::Escape($PortFlag))\d+") { continue }
      while ($used.Contains($next)) { $next++ }
      if ($next -gt 9229) { $notes += "Not changed: more than 8 kiosk windows on this NUC ($f)."; break }
      $lines[$i] = [regex]::Replace($lines[$i], '(?i)--kiosk', "$PortFlag$next --kiosk", 1)
      [void]$used.Add($next); $changed = $true
    }
    if (-not $changed) { continue }
    $entry = @($index | Where-Object { $_.file -eq $f }) | Select-Object -First 1
    if (-not $entry) {
      New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
      $bak = Join-Path $BackupDir ("{0}_{1}.orig" -f ([IO.Path]::GetFileName($f)), (Get-Date).ToString('yyyyMMddHHmmss'))
      [IO.File]::WriteAllBytes($bak, $raw)
      $entry = [pscustomobject]@{ file = $f; backup = $bak; patchedSha = '' }
      $index += $entry
    }
    # written back in the file's own encoding, so cmd.exe reads it exactly as before
    [IO.File]::WriteAllText($f, ($lines -join $nl), $rl.enc)
    $entry.patchedSha = Get-FileSha $f
    $notes += "Debugging port added to $f (takes effect when Chrome next starts)."
  }
  Save-PatchIndex $index
  $notes
}

# puts every patched launcher back as it was
function Undo-LauncherPatch {
  $notes = @()
  foreach ($e in Get-PatchIndex) {
    if (-not (Test-Path -LiteralPath $e.file)) { continue }
    if ((Get-FileSha $e.file) -eq $e.patchedSha -and (Test-Path -LiteralPath $e.backup)) {
      [IO.File]::WriteAllBytes($e.file, [IO.File]::ReadAllBytes($e.backup))
      $notes += "Put back the original $($e.file)."
    } else {
      # edited since we patched it: take out only our flag, leave everything else as it is now
      $rl = Read-Launcher $e.file
      $t = $rl.text
      $t2 = [regex]::Replace($t, "(?i)$([regex]::Escape($PortFlag))922[2-9]\s+(?=--kiosk)", '')
      if ($t2 -ne $t) { [IO.File]::WriteAllText($e.file, $t2, $rl.enc); $notes += "Took the debugging port out of $($e.file) (it had been edited since, so the rest stays)." }
    }
  }
  if (Test-Path $PatchIndex) { Remove-Item $PatchIndex -Force }
  $notes
}

# the kiosk Chromes running now, and the debugging ports they were started with
function Get-ChromeDebugState {
  $procs = @(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue | Where-Object { "$($_.CommandLine)" -match '(?i)--kiosk' -and "$($_.CommandLine)" -notmatch '--type=' })
  $ports = @($procs | ForEach-Object { if ("$($_.CommandLine)" -match "(?i)$([regex]::Escape($PortFlag))(\d+)") { [int]$Matches[1] } })
  [pscustomobject]@{ kioskChromes = $procs.Count; ports = $ports }
}
