# showcase_analytics: remove (trial 15, 28 Nov 2026). Stops the reader, puts the startup bat back, deletes its files.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
. (Join-Path $PSScriptRoot 'launcher_patch.ps1')

$task = 'Showcase Analytics'
Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue | Stop-ScheduledTask
Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
  Where-Object { "$($_.CommandLine)" -like '*analytics_reader.ps1*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 1

foreach ($n in Undo-LauncherPatch) { Ok $n }
Remove-Item $AnalyticsHome -Recurse -Force -ErrorAction SilentlyContinue

if (Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue) { Warn "The task is still there. Delete '$task' in Task Scheduler by hand." }
elseif (Test-Path $AnalyticsHome) { Warn "Stopped, but $AnalyticsHome could not be fully deleted. Restart the NUC, then remove again." }
else { Ok 'Showcase Analytics removed. Chrome keeps its debugging connection until it next restarts.' }
