# Showcase Analytics: the NUC-side reader (trial 15, 28 Nov 2026). Runs as SYSTEM from the 'Showcase Analytics' task,
# hidden, one copy at a time. Every few seconds it asks the Showcase app tab, through Chrome's local debugging connection
# (127.0.0.1, ports 9222 to 9229, switched on by this module in the NUC's own startup bat), for what has changed on screen,
# and queues it to disk. About every 15 minutes it sends the queue to Fleet with the NUC's own device token.
# Read-only towards Showcase: reader.js only reads the page. Silent: no window, nothing on screen, failures go to the log.
param([int]$DrainSeconds = 5, [int]$UploadMinutes = 15, [switch]$Once, [int[]]$Ports = (9222..9229), [int]$Loops = 0, [switch]$UploadNow)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Utf8 = New-Object Text.UTF8Encoding $false

# SHOWCASE_FLEET_TEST_HOME: a scratch folder for tests on a PC that isn't a NUC (same switch as the agent)
$Home_ = if ($env:SHOWCASE_FLEET_TEST_HOME) { Join-Path $env:SHOWCASE_FLEET_TEST_HOME 'analytics' } else { Join-Path $env:ProgramData 'showcase_fleet\analytics' }
$Queue = Join-Path $Home_ 'queue'
$Log   = Join-Path $Home_ 'analytics.log'
$StatusFile = Join-Path $Home_ 'status.json'
$PageJs = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'reader.js'), $Utf8)
$Version = 'trial15_281126'
$MaxQueueMB = 50
$MaxPerUpload = 400
New-Item -ItemType Directory -Force -Path $Queue | Out-Null

function Write-Log([string]$m) {
  try {
    if ((Test-Path $Log) -and (Get-Item $Log).Length -gt 1MB) { Move-Item $Log "$Log.1" -Force }
    [IO.File]::AppendAllText($Log, "$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) $m`r`n", $Utf8)
  } catch { }
}

# one reader at a time (the task also starts it every 5 minutes in case it stopped)
$mutex = New-Object Threading.Mutex($false, 'Global\ShowcaseFleetAnalyticsReader')
if (-not $mutex.WaitOne(0)) { return }

$st = [ordered]@{ version = $Version; started = (Get-Date).ToString('s'); port = $null; tab = $false; store = $false
                  lastEvent = $null; lastPoll = $null; lastUpload = $null; uploadError = $null; error = $null; events = 0 }
function Save-Status { try { [IO.File]::WriteAllText($StatusFile, ($st | ConvertTo-Json -Compress), $Utf8) } catch { } }

# ---------------------------------------------------------------- Chrome DevTools Protocol, the minimum
$script:ws = $null; $script:wsUrl = $null; $script:msgId = 0

function Find-ShowcaseTab {
  foreach ($p in $Ports) {
    try {
      $list = Invoke-RestMethod -Uri "http://127.0.0.1:$p/json/list" -TimeoutSec 2 -UseBasicParsing
      $t = @($list) | Where-Object { $_.type -eq 'page' -and "$($_.url)" -like 'https://app.showcase.space/*' -and $_.webSocketDebuggerUrl } | Select-Object -First 1
      if ($t) { return @{ port = $p; url = $t.webSocketDebuggerUrl } }
    } catch { }
  }
  $null
}

function Close-Ws { try { if ($script:ws) { $script:ws.Dispose() } } catch { }; $script:ws = $null; $script:wsUrl = $null }

function Open-Ws([string]$url) {
  Close-Ws
  $w = New-Object Net.WebSockets.ClientWebSocket
  $w.Options.KeepAliveInterval = [TimeSpan]::FromSeconds(20)
  if (-not $w.ConnectAsync([Uri]$url, [Threading.CancellationToken]::None).Wait(5000)) { $w.Dispose(); throw 'Could not connect to the Showcase tab.' }
  $script:ws = $w; $script:wsUrl = $url
}

function Invoke-Cdp([string]$method, $params, [int]$timeoutMs = 8000) {
  $id = ++$script:msgId
  $json = @{ id = $id; method = $method; params = $params } | ConvertTo-Json -Depth 6 -Compress
  $bytes = $Utf8.GetBytes($json)
  $seg = New-Object 'ArraySegment[byte]' (, $bytes)
  if (-not $script:ws.SendAsync($seg, [Net.WebSockets.WebSocketMessageType]::Text, $true, [Threading.CancellationToken]::None).Wait($timeoutMs)) { throw 'Send timed out.' }
  $deadline = (Get-Date).AddMilliseconds($timeoutMs)
  $buf = New-Object byte[] 65536
  while ((Get-Date) -lt $deadline) {
    $ms = New-Object IO.MemoryStream
    do {
      $rseg = New-Object 'ArraySegment[byte]' (, $buf)
      $task = $script:ws.ReceiveAsync($rseg, [Threading.CancellationToken]::None)
      $left = [int][math]::Max(100, ($deadline - (Get-Date)).TotalMilliseconds)
      if (-not $task.Wait($left)) { throw 'Receive timed out.' }
      $r = $task.Result
      if ($r.MessageType -eq [Net.WebSockets.WebSocketMessageType]::Close) { throw 'Chrome closed the connection.' }
      $ms.Write($buf, 0, $r.Count)
    } while (-not $r.EndOfMessage)
    $msg = $Utf8.GetString($ms.ToArray()) | ConvertFrom-Json
    if ($msg.id -eq $id) {
      if ($msg.error) { throw "Chrome: $($msg.error.message)" }
      return $msg.result
    }
  }
  throw 'No answer from Chrome.'
}

function Invoke-PageJs([string]$expr) {
  $r = Invoke-Cdp 'Runtime.evaluate' @{ expression = $expr; returnByValue = $true; silent = $true; userGesture = $false }
  if ($r.exceptionDetails) { throw "Page: $($r.exceptionDetails.text)" }
  $r.result.value
}

# ---------------------------------------------------------------- the queue
function Get-QueueFile { Join-Path $Queue ("q_{0}.jsonl" -f (Get-Date).ToString('yyyyMMdd_HH')) }

function Add-ToQueue($events) {
  if (-not $events) { return }
  $sb = New-Object Text.StringBuilder
  foreach ($e in @($events)) { [void]$sb.AppendLine(($e | ConvertTo-Json -Depth 6 -Compress)) }
  [IO.File]::AppendAllText((Get-QueueFile), $sb.ToString(), $Utf8)
}

# never let the queue fill the disk: past the cap, the oldest files go first
function Limit-Queue {
  $files = @(Get-ChildItem $Queue -Filter '*.jsonl' | Sort-Object Name)
  $total = ($files | Measure-Object Length -Sum).Sum
  foreach ($f in $files) {
    if ($total -le $MaxQueueMB * 1MB) { break }
    $total -= $f.Length; Remove-Item $f.FullName -Force -ErrorAction SilentlyContinue
    Write-Log "Queue over $MaxQueueMB MB: dropped $($f.Name)"
  }
}

# sends every closed queue file (not the hour still being written), oldest first, then deletes what was sent
function Send-Queue {
  $fleetHome = if ($env:SHOWCASE_FLEET_TEST_HOME) { $env:SHOWCASE_FLEET_TEST_HOME } else { Join-Path $env:ProgramData 'showcase_fleet' }
  $agentCommon = Join-Path $fleetHome 'window\agent\agent_common.ps1'
  if (-not (Test-Path $agentCommon)) { $st.uploadError = 'Fleet agent not found on this NUC.'; return }
  $current = Split-Path (Get-QueueFile) -Leaf
  $files = @(Get-ChildItem $Queue -Filter 'q_*.jsonl' | Where-Object { $_.Name -ne $current } | Sort-Object Name)
  if (-not $files.Count) { return }
  try {
    . $agentCommon   # Invoke-FleetApi, Get-AgentState: the NUC's own token and fingerprint, read only
    $state = Get-AgentState
    $api = Get-Prop $state 'api'
    if (-not $api) { throw 'No API address in the agent state yet.' }
    foreach ($f in $files) {
      $lines = @([IO.File]::ReadAllLines($f.FullName, $Utf8) | Where-Object { $_ })
      for ($i = 0; $i -lt $lines.Count; $i += $MaxPerUpload) {
        $chunk = $lines[$i..([math]::Min($i + $MaxPerUpload, $lines.Count) - 1)]
        $events = @($chunk | ForEach-Object { try { $_ | ConvertFrom-Json } catch { } } | Where-Object { $_ })
        if ($events.Count) { Invoke-FleetApi $api 'usage' @{ reader = $Version; tz = (Get-TimeZone).Id; events = $events } | Out-Null }
      }
      Remove-Item $f.FullName -Force
    }
    $st.lastUpload = (Get-Date).ToString('s'); $st.uploadError = $null
  } catch {
    $st.uploadError = "$($_.Exception.Message)"
    Write-Log "Upload: $($_.Exception.Message)"
  }
}

# ---------------------------------------------------------------- main loop
Write-Log "Reader $Version started."
$nextUpload = if ($UploadNow) { Get-Date } else { (Get-Date).AddMinutes(2) }
try {
  while ($true) {
    try {
      if (-not $script:ws -or $script:ws.State -ne [Net.WebSockets.WebSocketState]::Open) {
        $tab = Find-ShowcaseTab
        if (-not $tab) {
          $st.port = $null; $st.tab = $false; $st.store = $false
          $st.error = 'No Showcase tab on Chrome''s debugging connection (Chrome not running, or its startup bat has no debugging port yet).'
          Close-Ws
        } else {
          Open-Ws $tab.url
          $st.port = $tab.port; $st.tab = $true; $st.error = $null
          Write-Log "Connected to the Showcase tab on port $($tab.port)."
        }
      }
      if ($script:ws) {
        $out = Invoke-PageJs 'window.__scAnalytics ? window.__scAnalytics.drain() : null'
        if ($null -eq $out) {
          $res = Invoke-PageJs $PageJs   # a new page (reload, restart, project switch): put the reader in again
          Write-Log "Page reader: $res"
        } else {
          $st.store = [bool]$out.store
          $ev = @($out.ev)
          if ($ev.Count) { Add-ToQueue $ev; $st.lastEvent = (Get-Date).ToString('s'); $st.events += $ev.Count }
          foreach ($p in @($out.pr)) { if ($p) { Write-Log "Page: $p" } }
        }
        $st.lastPoll = (Get-Date).ToString('s')
      }
    } catch {
      $st.error = "$($_.Exception.Message)"
      Write-Log "Read: $($_.Exception.Message)"
      Close-Ws   # find the tab again next time (it may have moved to a new page or a new Chrome)
    }
    if ((Get-Date) -ge $nextUpload) { Limit-Queue; Send-Queue; $nextUpload = (Get-Date).AddMinutes($UploadMinutes) }
    Save-Status
    if ($Once -or ($Loops -gt 0 -and --$Loops -eq 0)) { break }
    Start-Sleep -Seconds $DrainSeconds
  }
} finally {
  Close-Ws
  try { $mutex.ReleaseMutex() } catch { }
}
