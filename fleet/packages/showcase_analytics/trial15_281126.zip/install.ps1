# showcase_analytics: install or update (trial 15, 28 Nov 2026). Runs as SYSTEM from the Fleet agent's 1am pass (or the
# Fleet window). Copies the reader, switches the debugging connection on in the NUC's startup bat, and starts the reader.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
. (Join-Path $PSScriptRoot 'launcher_patch.ps1')

$version = 'trial15_281126'
$bin  = Join-Path $AnalyticsHome 'bin'
$task = 'Showcase Analytics'

# stop the running reader before its files are replaced
Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue | Stop-ScheduledTask
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
  Where-Object { "$($_.CommandLine)" -like '*analytics_reader.ps1*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 1

New-Item -ItemType Directory -Force -Path $bin, (Join-Path $AnalyticsHome 'queue') | Out-Null
# SYSTEM and Administrators only: the reader runs as SYSTEM, and nobody else should be able to change what it runs
& icacls.exe $AnalyticsHome /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null

Step 'Copied the reader' {
  foreach ($f in 'analytics_reader.ps1', 'reader.js') { Copy-Item (Join-Path $PSScriptRoot $f) (Join-Path $bin $f) -Force }
}

foreach ($n in Invoke-LauncherPatch) { if ($n -like 'Not changed*') { Warn $n } else { Ok $n } }
$report = @(Get-LauncherReport)
if (-not $report.Count) { Warn 'No startup bat on this NUC opens Chrome in kiosk mode, so there is nothing to read until Showcase starts from one.' }

$ps = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$action    = New-ScheduledTaskAction -Execute $ps -Argument "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$(Join-Path $bin 'analytics_reader.ps1')`""
$atStart   = New-ScheduledTaskTrigger -AtStartup
# every 5 minutes: starts it again if it ever stopped; does nothing while it runs (one copy at a time)
$revive    = New-ScheduledTaskTrigger -Once -At (Get-Date).Date -RepetitionInterval (New-TimeSpan -Minutes 5)
$principal = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -Force -TaskName $task -TaskPath '\' -Description "Showcase Fleet: Showcase Analytics $version (read-only)" -Action $action -Trigger @($atStart, $revive) -Principal $principal -Settings $settings | Out-Null
Start-ScheduledTask -TaskName $task
Set-Content (Join-Path $AnalyticsHome 'version.txt') $version -Encoding ASCII
Start-Sleep -Seconds 4

if (Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { "$($_.CommandLine)" -like '*analytics_reader.ps1*' }) { Ok 'The reader is running.' }
else { Warn 'Installed, but the reader is not running yet: the task starts it within 5 minutes.' }

$c = Get-ChromeDebugState
if ($c.kioskChromes -and -not $c.ports.Count) { Info 'Showcase is open without the debugging connection: analytics starts the next time Chrome starts (the 4:30am restart).' }
elseif ($c.ports.Count) { Info "Chrome's debugging connection is on (port $($c.ports -join ', '))." }
