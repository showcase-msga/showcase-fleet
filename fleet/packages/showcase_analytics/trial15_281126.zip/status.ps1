# showcase_analytics: status (trial 15, 28 Nov 2026). Returns a hashtable; reads only.
# 'problem' means only that the reader itself isn't installed or running. Waiting for Chrome's next start, or a launcher
# that can't take the debugging port, are reported in the detail without failing the module (the 2am check would
# otherwise roll it back every night until the 4:30am restart).
. (Join-Path $PSScriptRoot 'launcher_patch.ps1')
$task = Get-ScheduledTask -TaskName 'Showcase Analytics' -ErrorAction SilentlyContinue
if (-not $task) { return @{ installed = $false } }
$version = "$(Get-Content (Join-Path $AnalyticsHome 'version.txt') -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
$running = [bool](Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { "$($_.CommandLine)" -like '*analytics_reader.ps1*' })
$s = $null
try { $s = Get-Content (Join-Path $AnalyticsHome 'status.json') -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
$queued = @(Get-ChildItem (Join-Path $AnalyticsHome 'queue') -Filter '*.jsonl' -ErrorAction SilentlyContinue).Count
$launchers = @(Get-LauncherReport)
$c = Get-ChromeDebugState

$bits = @()
if (-not $running) { $bits += 'Reader not running (the task restarts it within 5 minutes).' }
if ($s -and $s.tab -and $s.store) { $bits += "Collecting on port $($s.port)." }
elseif ($c.kioskChromes -and -not $c.ports.Count) { $bits += 'Waiting for Chrome to restart with the debugging connection (4:30am).' }
elseif ($s -and $s.error) { $bits += "Not collecting: $($s.error)" }
$noProfile = @($launchers | Where-Object { -not $_.ownProfile })
if ($noProfile.Count) { $bits += "Can't switch on: $(($noProfile | ForEach-Object { Split-Path $_.file -Leaf }) -join ', ') uses Chrome's default profile." }
if (-not $launchers.Count) { $bits += 'No kiosk startup bat found.' }
if ($s -and $s.lastEvent) { $bits += "Last change seen $($s.lastEvent)." }
if ($s -and $s.lastUpload) { $bits += "Last sent $($s.lastUpload)." }
if ($s -and $s.uploadError) { $bits += "Sending: $($s.uploadError)" }
if ($queued) { $bits += "$queued hour file(s) waiting to send." }

@{ installed = $true; version = $(if ($version) { $version } else { '?' }); problem = -not $running; settings = @{}
   detail = ($bits -join ' ') }
