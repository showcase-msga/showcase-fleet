// Showcase Analytics page reader (trial 15, 28 Nov 2026). Injected into the Showcase app tab by analytics_reader.ps1
// through Chrome's local debugging connection. READ-ONLY: it never dispatches, clicks, writes storage or changes the page.
// It keeps a small digest of what is on screen and records a new event whenever the digest changes; the NUC side drains
// the buffer every few seconds. Never read: forms, typed text, names, emails, phones, tap positions, session keys.
// Store lookup reused from the Levande lights extension (levande3_041126/extension/page-reader.js, lines 29 to 48).
(function () {
  if (window.__scAnalytics) return 'already on';
  var VERSION = 'trial15_281126';
  var MAX = 3000;
  var buf = [];
  var last = '';
  var store = null;
  var problems = [];

  function findStore() {
    try {
      var root = document.getElementById('root');
      if (!root) return null;
      var key = Object.keys(root).find(function (k) { return k.indexOf('__reactContainer$') === 0; });
      if (!key) return null;
      var q = [root[key]], n = 0;
      while (q.length && n < 5000) {
        var f = q.shift(); n++;
        if (!f) continue;
        var p = f.memoizedProps;
        if (p && p.store && typeof p.store.getState === 'function') return p.store;
        if (f.child) q.push(f.child);
        if (f.sibling) q.push(f.sibling);
      }
    } catch (e) { }
    return null;
  }

  function s(v, max) { return (typeof v === 'string' || typeof v === 'number') ? String(v).slice(0, max || 60) : ''; }
  function file(src) {
    try { return decodeURIComponent(String(src).split('?')[0].split('#')[0].split('/').pop()).slice(0, 80); } catch (e) { return ''; }
  }

  // the gallery folder, video title or similar side-menu item Showcase underlines when it is selected
  function activeMenuItem() {
    try {
      // only the upper-case side menus (gallery folders, video titles); not links like the filter's "Reset"
      var els = document.querySelectorAll('.underline.uppercase, .uppercase .underline');
      for (var i = 0; i < els.length; i++) {
        var t = (els[i].innerText || '').trim();
        if (t && t.length <= 60 && els[i].getBoundingClientRect().width > 0) return t;
      }
    } catch (e) { }
    return '';
  }

  // the picture in the middle of the screen (the gallery or slideshow photo on show), by file name only
  function centreImage() {
    try {
      var els = document.elementsFromPoint(innerWidth / 2, innerHeight / 2);
      for (var i = 0; i < els.length && i < 8; i++) {
        if (els[i].tagName === 'IMG') return file(els[i].currentSrc || els[i].src);
      }
    } catch (e) { }
    return '';
  }

  // a playing video: its file, and whether it fills the screen (the screensaver)
  function playingVideo() {
    try {
      var v = document.querySelectorAll('video');
      for (var i = 0; i < v.length; i++) {
        if (!v[i].paused && !v[i].ended) {
          var r = v[i].getBoundingClientRect();
          return { f: file(v[i].currentSrc || v[i].src), full: r.width * r.height >= innerWidth * innerHeight * 0.9 };
        }
      }
    } catch (e) { }
    return null;
  }

  function filterSummary(u) {
    if (!u || !u.apply) return '';
    var out = [];
    try {
      var c = u.configurations || {};
      Object.keys(c).forEach(function (k) {
        var m = c[k] || {};
        if ((m.min && m.min !== 'Any') || (m.max && m.max !== 'Any')) out.push(k + ' ' + (m.min || 'Any') + '-' + (m.max || 'Any'));
      });
      if (u.range && ((u.range.min && u.range.min !== 'Any') || (u.range.max && u.range.max !== 'Any'))) out.push('price ' + u.range.min + '-' + u.range.max);
      if (u.unitType && u.unitType !== 'Any') out.push('type ' + u.unitType);
      if (u.aspect && u.aspect.length) out.push('aspect ' + u.aspect.join('/'));
      if (u.showAvailable) out.push('available only');
    } catch (e) { }
    return out.join(', ').slice(0, 200);
  }

  function digest() {
    var parts = location.pathname.split('/').filter(Boolean);
    var d = { p: s(parts[0], 80), v: s(parts.slice(1).join('/'), 80), vis: document.visibilityState === 'visible' ? 1 : 0 };
    var st = null;
    try { st = store && store.getState(); } catch (e) { st = null; }
    if (st) {
      var b = st.building || {}, a = st.appConfig || {}, h = st.houseAndLand || {}, t = st.threeDView || {}, sl = st.shortlist || {};
      d.blk = s(b.activeBlock); d.lvl = s(b.activeLevel); d.unit = s(b.activeUnit);
      d.l3d = s(t.selectedLevelId);
      d.stage = s(h.activeStageId); d.lot = s(h.activeLotName); d.pkg = s(h.activePackageId);
      d.ss = a.slideshowIsPlaying ? 1 : 0; d.vp = a.videoIsPlaying ? 1 : 0; d.fs = a.fullscreen ? 1 : 0;
      var list = Array.isArray(sl.shortlists) ? sl.shortlists : [];
      d.sl = list.length;
      d.sln = list.slice(0, 20).map(function (x) { return s(x && x.propertyName, 30); }).join('|');
      d.flt = filterSummary(st.unitFilter);
    }
    d.menu = activeMenuItem();
    d.img = centreImage();
    var pv = playingVideo();
    d.vid = pv ? pv.f : ''; d.scr = pv && pv.full && d.v !== 'video-gallery' ? 1 : 0;
    return d;
  }

  function config() {
    try {
      var pc = store.getState().projectConfig || {};
      var nav = (pc.navigationSettings || []).filter(function (x) { return x && x.active; }).map(function (x) { return s(x.key, 30); });
      return {
        nav: nav.join('|'),
        idle: pc.idlePage ? ((pc.idlePage.active ? 'on ' : 'off ') + s(pc.idlePage.page, 30)) : '',
        vss: pc.videoScreensaver ? ((pc.videoScreensaver.enabled ? 'on ' : 'off ') + (pc.videoScreensaver.delay || '')) : '',
        gint: pc.gallerySettings ? (pc.gallerySettings.intervalInSeconds || '') : '',
        type: s(pc.type, 30)
      };
    } catch (e) { return {}; }
  }

  function push(ev) {
    buf.push(ev);
    if (buf.length > MAX) buf.splice(0, buf.length - MAX);
  }

  function tick(why) {
    try {
      if (!store) {
        store = findStore();
        if (store) {
          try { store.subscribe(function () { tick('store'); }); } catch (e) { problems.push('subscribe failed'); }
          push({ t: Date.now(), e: 'cfg', d: config(), r: VERSION });
        }
      }
      var d = digest();
      var key = JSON.stringify(d);
      if (key === last) return;
      last = key;
      d.t = Date.now(); d.e = 'v'; d.w = why;
      push(d);
    } catch (e) {
      if (problems.length < 20) problems.push(String(e && e.message || e).slice(0, 120));
    }
  }

  window.__scAnalytics = {
    version: VERSION,
    drain: function () {
      tick('poll');
      var out = buf; buf = [];
      var p = problems; problems = [];
      return { r: VERSION, store: !!store, ev: out, pr: p };
    }
  };
  // picks up changes the store doesn't see (the gallery photo, the side menu, a video), without hammering the page
  setInterval(function () { tick('poll'); }, 2000);
  tick('start');
  return 'on';
})();
