# Showcase Fleet Manager module: quiet (trial10_231126). Runs as SYSTEM, started by install.ps1 or remove.ps1.
# -Mode Apply: Windows updates at night only, no Windows pop-ups. -Mode Remove: Windows' defaults.
# SYSTEM because it writes every user's settings and switches the update services back on.
param([ValidateSet('Apply', 'Remove')][string]$Mode = 'Apply', [ValidateRange(0, 5)][int]$Hour = 3)
$ErrorActionPreference = 'Stop'
$apply = $Mode -eq 'Apply'
$log = Join-Path $PSScriptRoot 'quiet.log'
Set-Content -Path $log -Value "quiet trial10_231126: $Mode, $(Get-Date -Format 'yyyy-MM-dd HH:mm')" -Encoding UTF8
function Note($line) { Add-Content -Path $log -Value $line -Encoding UTF8 }
function Step($name, [scriptblock]$do) {
  try { & $do; Note "[OK]   $name" } catch { Note "[WARN] $name - $($_.Exception.Message)" }
}

# machine settings: key under HKLM, value name, DWORD value.
# Apply writes them; Remove deletes them, which puts Windows back to its default.
$wu = 'SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
$machine = [ordered]@{
  "Updates install and restart at $($Hour):00 only, every day" = @(
    @("$wu\AU", 'NoAutoUpdate', 0),
    @("$wu\AU", 'AUOptions', 4),
    @("$wu\AU", 'ScheduledInstallDay', 0),
    @("$wu\AU", 'ScheduledInstallEveryWeek', 1),
    @("$wu\AU", 'ScheduledInstallTime', $Hour),
    @("$wu\AU", 'AlwaysAutoRebootAtScheduledTime', 1),
    @("$wu\AU", 'AlwaysAutoRebootAtScheduledTimeMinutes', 15))
  'Never restarts between 6am and midnight' = @(
    @($wu, 'SetActiveHours', 1),
    @($wu, 'ActiveHoursStart', 6),
    @($wu, 'ActiveHoursEnd', 0))
  'Update and restart notifications off' = @(
    @($wu, 'SetUpdateNotificationLevel', 1),
    @($wu, 'UpdateNotificationLevel', 2),
    @($wu, 'SetAutoRestartNotificationDisable', 1))
  'Driver updates left out' = @(
    ,@($wu, 'ExcludeWUDriversInQualityUpdate', 1))
  'Tips, suggestions and "finish setting up" off' = @(
    @('SOFTWARE\Policies\Microsoft\Windows\CloudContent', 'DisableWindowsConsumerFeatures', 1),
    @('SOFTWARE\Policies\Microsoft\Windows\CloudContent', 'DisableSoftLanding', 1),
    @('SOFTWARE\Policies\Microsoft\Windows\CloudContent', 'DisableConsumerAccountStateContent', 1))
  'Windows Security notifications off' = @(
    @('SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications', 'DisableNotifications', 1),
    @('SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications', 'DisableEnhancedNotifications', 1))
  'Crash dialogs off' = @(
    ,@('SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting', 'DontShowUI', 1))
  'AutoPlay off (USB and disc pop-ups)' = @(
    @('SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer', 'NoDriveTypeAutoRun', 255),
    @('SOFTWARE\Policies\Microsoft\Windows\Explorer', 'NoAutoplayfornonVolume', 1))
  'Feedback requests off' = @(
    ,@('SOFTWARE\Policies\Microsoft\Windows\DataCollection', 'DoNotShowFeedbackNotifications', 1))
  # trial 9 (Revisions List item 30c, from the Maison Savoy projectors, 28 Oct 2026)
  'Privacy settings screen after a feature update off' = @(
    ,@('SOFTWARE\Policies\Microsoft\Windows\OOBE', 'DisablePrivacyExperience', 1))
  'Edge first-run screens off' = @(
    ,@('SOFTWARE\Policies\Microsoft\Edge', 'HideFirstRunExperience', 1))
  'OneDrive off (no sign-in or "Turn on Windows Backup" prompts)' = @(
    @('SOFTWARE\Policies\Microsoft\Windows\OneDrive', 'DisableFileSyncNGSC', 1),
    @('SOFTWARE\Policies\Microsoft\OneDrive', 'KFMBlockOptIn', 1))
}

# per-user settings, written into every user on the NUC and the default profile (for new users)
$user = @(
  @('Software\Microsoft\Windows\CurrentVersion\PushNotifications', 'ToastEnabled', 0),
  @('Software\Microsoft\Windows\CurrentVersion\Notifications\Settings', 'NOC_GLOBAL_SETTING_TOASTS_ENABLED', 0),
  @('Software\Policies\Microsoft\Windows\CurrentVersion\PushNotifications', 'NoToastApplicationNotification', 1),
  @('Software\Policies\Microsoft\Windows\Explorer', 'DisableNotificationCenter', 1),
  @('Software\Microsoft\Windows\CurrentVersion\Policies\Explorer', 'NoLowDiskSpaceChecks', 1),
  @('Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement', 'ScoobeSystemSettingEnabled', 0),
  @('Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager', 'SubscribedContent-310093Enabled', 0),
  @('Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager', 'SubscribedContent-338388Enabled', 0),
  @('Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager', 'SubscribedContent-338389Enabled', 0),
  @('Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager', 'SubscribedContent-353694Enabled', 0),
  @('Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager', 'SubscribedContent-353696Enabled', 0),
  @('Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager', 'SoftLandingEnabled', 0),
  @('Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager', 'SystemPaneSuggestionsEnabled', 0),
  @('Software\Policies\Microsoft\Windows\CloudContent', 'DisableWindowsSpotlightFeatures', 1),
  @('Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers', 'DisableAutoplay', 1))

# reg.exe returns its exit code; its error text is dropped (a missing value on removal is fine)
function Reg {
  $ErrorActionPreference = 'Continue'
  & reg.exe @args 2>$null | Out-Null
  $LASTEXITCODE
}

# never New-Item -Force on a key that exists: it wipes every value already in it
function SetValue($path, $name, $value) {
  $full = "HKLM:\$path"
  if (-not (Test-Path $full)) { New-Item -Path $full -Force | Out-Null }
  New-ItemProperty -Path $full -Name $name -PropertyType DWord -Value $value -Force | Out-Null
}

foreach ($name in $machine.Keys) {
  Step $(if ($apply) { $name } else { "$name - back to normal" }) {
    foreach ($v in $machine[$name]) {
      if ($apply) { SetValue $v[0] $v[1] $v[2] }
      else { Remove-ItemProperty -Path "HKLM:\$($v[0])" -Name $v[1] -ErrorAction SilentlyContinue }
    }
  }
}

Step $(if ($apply) { 'Firewall "blocked some features" pop-ups off' } else { 'Firewall pop-ups back to normal' }) {
  Set-NetFirewallProfile -All -NotifyOnListen $(if ($apply) { 'False' } else { 'True' })
}

# trial 9 (Revisions List item 31): Chrome's "app.showcase.space wants to access other apps and services
# on this device" prompt (Local Network Access, Chrome 142+), allowed by policy so it never shows over
# Showcase. A list policy: one string value per URL. Only our own entry is added or removed.
$showcaseUrl = 'https://app.showcase.space'
$lna = 'HKLM:\SOFTWARE\Policies\Google\Chrome\LocalNetworkAccessAllowedForUrls'
Step $(if ($apply) { 'Chrome local network prompt allowed for Showcase' } else { 'Chrome local network prompt back to normal' }) {
  $props = if (Test-Path $lna) { (Get-ItemProperty -Path $lna).PSObject.Properties | Where-Object { $_.Name -match '^\d+$' } } else { @() }
  $ours = @($props | Where-Object { "$($_.Value)" -eq $showcaseUrl })
  if ($apply) {
    if ($ours.Count) { return }
    if (-not (Test-Path $lna)) { New-Item -Path $lna -Force | Out-Null }
    $next = 1; while (@($props | Where-Object { $_.Name -eq "$next" }).Count) { $next++ }
    New-ItemProperty -Path $lna -Name "$next" -PropertyType String -Value $showcaseUrl -Force | Out-Null
  } else {
    foreach ($p in $ours) { Remove-ItemProperty -Path $lna -Name $p.Name -ErrorAction SilentlyContinue }
    if ((Test-Path $lna) -and -not @((Get-ItemProperty -Path $lna).PSObject.Properties | Where-Object { $_.Name -match '^\d+$' }).Count) {
      Remove-Item -Path $lna -ErrorAction SilentlyContinue
    }
  }
}

# the old NUC setup checklist switched Windows Update off; night updates need it on (Windows defaults)
if ($apply) {
  foreach ($s in @(@('wuauserv', 3), @('UsoSvc', 2))) {
    $key = "HKLM:\SYSTEM\CurrentControlSet\Services\$($s[0])"
    if (-not (Test-Path $key)) { continue }
    if ((Get-ItemProperty $key).Start -eq 4) {
      Step "Service $($s[0]) was switched off - switched back on" { Set-ItemProperty -Path $key -Name Start -Value $s[1] }
    } else { Note "[OK]   Service $($s[0]) is on" }
  }
}

$hives = @()
foreach ($p in Get-CimInstance Win32_UserProfile | Where-Object { -not $_.Special -and $_.SID -like 'S-1-5-21-*' }) {
  $hives += [pscustomobject]@{ Name = (Split-Path $p.LocalPath -Leaf); Sid = $p.SID; Loaded = $p.Loaded; File = (Join-Path $p.LocalPath 'NTUSER.DAT') }
}
$default = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList').Default
$hives += [pscustomobject]@{ Name = 'default profile'; Sid = ''; Loaded = $false; File = (Join-Path $default 'NTUSER.DAT') }

$n = 0
foreach ($h in $hives) {
  $root = $h.Sid
  if (-not $h.Loaded) {
    if (-not (Test-Path $h.File)) { continue }
    $n++; $root = "showcase_fleet_quiet_$n"
    if (Reg load "HKU\$root" $h.File) { Note "[WARN] Pop-ups for $($h.Name) - could not open its settings"; continue }
  }
  Step "Pop-ups for $($h.Name) $(if ($apply) { 'off' } else { 'back to normal' })" {
    $bad = 0
    foreach ($v in $user) {
      if ($apply) { if (Reg add "HKU\$root\$($v[0])" /v $v[1] /t REG_DWORD /d $v[2] /f) { $bad++ } }
      else { Reg delete "HKU\$root\$($v[0])" /v $v[1] /f | Out-Null }
    }
    if ($bad) { throw "$bad settings could not be written" }
  }
  if (-not $h.Loaded) { Reg unload "HKU\$root" | Out-Null }
}

Note 'DONE'
