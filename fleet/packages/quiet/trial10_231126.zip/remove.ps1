# quiet: remove (trial10_231126). Windows Update, the pop-ups, OneDrive and Chrome's local network prompt go back to Windows' defaults.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')

$data = Get-ModuleData 'quiet'
Copy-Item (Join-Path $PSScriptRoot 'quiet.ps1') (Join-Path $data 'quiet.ps1') -Force
Info 'Putting Windows Update and pop-ups back to normal (up to 3 minutes)...'
$lines = @(Invoke-AsSystem (Join-Path $data 'quiet.ps1') '-Mode Remove' (Join-Path $data 'quiet.log'))
$lines | ForEach-Object { Info $_ }
if ($lines -match 'did not finish') { Warn "Kept $data so you can run Remove again."; return }
Remove-Item $data -Recurse -Force
Ok 'Quiet removed.'
