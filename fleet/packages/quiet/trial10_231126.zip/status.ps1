# quiet: status. Returns a hashtable; reads only.
$file = Join-Path $env:ProgramData 'showcase_fleet\quiet\installed.json'
if (-not (Test-Path $file)) { return @{ installed = $false } }
$i = Get-Content $file -Raw | ConvertFrom-Json
$au = Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -ErrorAction SilentlyContinue
$hour = $au.ScheduledInstallTime
if ($null -eq $hour -or $au.AUOptions -ne 4) {
  return @{ installed = $true; version = $i.version; problem = $true; settings = @{ UpdateHour = $i.UpdateHour }
            detail = 'Installed, but the update schedule is missing. Something else changed it; reinstall.' }
}
$label = if ($hour -eq 0) { 'midnight' } else { "$($hour):00 am" }
@{ installed = $true; version = $i.version; settings = @{ UpdateHour = [int]$hour }
   detail = "Updates install at $label only. No Windows pop-ups." }
