# quiet: install or update (trial10_231126: the update hour is fixed at 3am, Overnight Timetable.md)
param([ValidateRange(0, 5)][int]$UpdateHour = 3)
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$Version = 'trial10_231126'

$data = Get-ModuleData 'quiet'
Copy-Item (Join-Path $PSScriptRoot 'quiet.ps1') (Join-Path $data 'quiet.ps1') -Force
Info "Setting night-only updates at $($UpdateHour):00 and switching off pop-ups (up to 3 minutes)..."
Invoke-AsSystem (Join-Path $data 'quiet.ps1') "-Mode Apply -Hour $UpdateHour" (Join-Path $data 'quiet.log') | ForEach-Object { Info $_ }
@{ version = $Version; UpdateHour = $UpdateHour } | ConvertTo-Json | Set-Content (Join-Path $data 'installed.json') -Encoding UTF8
Ok "Quiet $Version installed. Updates install, and the NUC restarts if needed, at $($UpdateHour):00 only."
Info 'Anything Windows already has waiting installs at that time tonight.'
