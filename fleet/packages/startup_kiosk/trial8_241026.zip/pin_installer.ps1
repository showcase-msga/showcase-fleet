# Showcase pin: install
# Keeps the Showcase browser window on top of everything on the main screen (the TV or LED).
# Checks four times a second: if anything has come up over Showcase, it puts Showcase straight back
# on top, logs what it was, and (if a Slack webhook is set below) posts it to Slack.
# Run in an Admin PowerShell window on the NUC (paste the whole file in, or run it with -File).
# Safe to run again: it replaces the old copy instead of adding a second one.
#
# Pause:  Ctrl+Alt+Q pauses this and the Showcase Kiosk launcher together for 30 minutes, then both
#         carry on by themselves. Press again to end early.
# Remove: remove-pin.cmd, right-click > Run as administrator.

# SHOWCASE FLEET COPY (trial 7, 24 Oct 2026) of AD/01 Operations/Showcase Pin 081026. Fleet changes: settings come
# in as parameters from the Startup Kiosk module, and Pin watches the screen Showcase is on (the real screen), not
# Windows' main display, which Fleet's support screen makes the hidden screen.
# Trial 7: no webhook passed keeps the Slack webhook already set; the check runs as the display user; the real
# screen read at most once a second, keeping the last good answer while the support screen rewrites it; pin.log
# capped at 1 MB; per-monitor DPI aware.
# ---- settings, passed by Fleet's Startup Kiosk module ----
param(
  [string]$SiteName      = '',                # how this NUC is named in Slack alerts; blank = its computer name
  [string]$SlackWebhook  = '',                # Slack incoming webhook URL; blank = log only (no Slack)
  [string]$Browsers      = 'chrome,msedge',   # the browser(s) Showcase runs in
  [string]$TitleContains = ''                 # optional: part of the Showcase window title
)

# ---- install: nothing to change below ----
& {
  $ErrorActionPreference = 'Stop'

  $me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
  if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run this in an Admin PowerShell window.' }
  if ($SlackWebhook -and $SlackWebhook -notlike 'https://hooks.slack.com/*') { throw 'The Slack webhook should start with https://hooks.slack.com/' }

  # it has to run as whoever is logged in on the display, or it cannot reach the Showcase window
  # (Fleet's common.ps1: the NUC's own login, not a Switch User)
  $user = Get-DisplayUser

  $dir  = Join-Path $env:ProgramData 'ShowcasePin'
  $exe  = Join-Path $dir 'ShowcasePin.exe'
  $task = 'Showcase Pin'

  # Fleet: no webhook passed keeps the one this NUC already has, so a standalone Pin's Slack alerts stay on
  $pinConfig = Join-Path $dir 'pin.config'
  if (-not $SlackWebhook -and (Test-Path $pinConfig)) {
    $line = Get-Content $pinConfig | Where-Object { $_ -like 'Slack=*' } | Select-Object -First 1
    if ($line) { $SlackWebhook = $line.Substring(6).Trim() }
  }

  # stop a running copy so the exe can be replaced
  Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue | Stop-ScheduledTask
  Get-Process ShowcasePin -ErrorAction SilentlyContinue | Stop-Process -Force
  Start-Sleep -Seconds 1
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  # it writes its log as the logged-in user, not as admin (Users group by SID, so any Windows language works)
  & icacls.exe $dir /grant '*S-1-5-32-545:(OI)(CI)M' | Out-Null

  # settings the app reads at start; the webhook stays on this NUC, never in the task's command line
  Set-Content -Path $pinConfig -Encoding UTF8 -Value @(
    "Site=$SiteName", "Slack=$SlackWebhook", "Browsers=$Browsers", "Title=$TitleContains")

  $src = @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ShowcasePin
{
    public static class Win
    {
        public delegate bool EnumProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr lParam);
        [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr hWnd, uint cmd);
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
        [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
        [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hWnd, int index);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder sb, int max);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, StringBuilder sb, int max);
        [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint mods, uint vk);
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr value);
        [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr hWnd, int attr, out int value, int size);

        [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }

        // Fleet (trial 7): per-monitor DPI aware (v2), so window and screen sizes are real pixels on every screen,
        // whatever each one's scaling; older Windows falls back to system aware
        public static void DpiAware()
        {
            try { if (SetProcessDpiAwarenessContext(new IntPtr(-4))) return; } catch { }
            try { SetProcessDPIAware(); } catch { }
        }

        public static readonly IntPtr HWND_TOPMOST = new IntPtr(-1), HWND_NOTOPMOST = new IntPtr(-2);
        public const uint GW_OWNER = 4;
        public const int GWL_STYLE = -16, WS_CAPTION = 0x00C00000, DWMWA_CLOAKED = 14;
        public const int GWL_EXSTYLE = -20, WS_EX_TRANSPARENT = 0x20;
        // z-order only: never move, resize or take focus
        public const uint ZORDER_ONLY = 0x1 | 0x2 | 0x10 | 0x200; // NOSIZE | NOMOVE | NOACTIVATE | NOOWNERZORDER
    }

    public class Found
    {
        public IntPtr Hwnd;
        public string Process;
        public string Class;
        public string Title;
        public Rectangle Rect;
        public bool Owned;
        public bool ClickThrough; // an overlay the mouse passes through (usually invisible)
        public bool Kiosk; // no title bar: full-screen or kiosk mode, the way Showcase runs
    }

    public static class Finder
    {
        // Fleet: the screen Showcase belongs on. With Fleet's support screen installed, Windows' main display is
        // the hidden support screen, so use the first real screen the support screen program reports; else the main one.
        // Trial 7: the file is read at most once a second (Pin asks eight times a second), and a read that fails or
        // lands mid-write keeps the last good answer.
        static string lastScreenName = "";
        static DateTime screenReadAt = DateTime.MinValue;

        public static Rectangle ShowcaseScreen()
        {
            if (DateTime.Now - screenReadAt >= TimeSpan.FromSeconds(1))
            {
                screenReadAt = DateTime.Now;
                string name = RealScreenName();
                if (name != null) lastScreenName = name;
            }
            if (lastScreenName.Length > 0)
                foreach (Screen sc in Screen.AllScreens) if (sc.DeviceName == lastScreenName) return sc.Bounds;
            return Screen.PrimaryScreen.Bounds;
        }

        // the first real screen in the support screen program's state file; "" = no support screen (no file, or no
        // real screen listed), null = it couldn't be read this time
        static string RealScreenName()
        {
            try
            {
                string state = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), @"showcase_fleet\support_screen\state.json");
                if (!File.Exists(state)) return "";
                string s;
                // share everything, so the writer can still swap the file in while this reads it
                using (FileStream fs = new FileStream(state, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                using (StreamReader r = new StreamReader(fs)) s = r.ReadToEnd();
                if (!s.TrimEnd().EndsWith("}")) return null;
                int i = s.IndexOf("\"realScreens\":[");
                if (i < 0) return null;
                if (string.CompareOrdinal(s, i, "\"realScreens\":[\"", 0, 16) != 0) return "";
                int start = i + 16, sp = s.IndexOf(' ', start);
                if (sp < 0) return null;
                return s.Substring(start, sp - start).Replace("\\\\", "\\");
            }
            catch { return null; }
        }

        static readonly Dictionary<uint, string> names = new Dictionary<uint, string>();
        static DateTime namesAt = DateTime.MinValue;

        static string ProcName(uint pid)
        {
            if (DateTime.Now - namesAt > TimeSpan.FromMinutes(1)) { names.Clear(); namesAt = DateTime.Now; }
            string name;
            if (names.TryGetValue(pid, out name)) return name;
            try { using (Process p = Process.GetProcessById((int)pid)) name = p.ProcessName.ToLowerInvariant(); }
            catch { name = ""; }
            names[pid] = name;
            return name;
        }

        // every visible, un-minimised, un-cloaked top-level window, topmost first (z-order)
        public static List<Found> All()
        {
            List<Found> list = new List<Found>();
            Win.EnumWindows(delegate(IntPtr h, IntPtr l)
            {
                if (!Win.IsWindowVisible(h) || Win.IsIconic(h)) return true;
                int cloaked;
                if (Win.DwmGetWindowAttribute(h, Win.DWMWA_CLOAKED, out cloaked, 4) == 0 && cloaked != 0) return true;
                Win.RECT r;
                if (!Win.GetWindowRect(h, out r)) return true;
                uint pid;
                Win.GetWindowThreadProcessId(h, out pid);
                StringBuilder title = new StringBuilder(256), cls = new StringBuilder(256);
                Win.GetWindowText(h, title, title.Capacity);
                Win.GetClassName(h, cls, cls.Capacity);
                Found f = new Found();
                f.Hwnd = h;
                f.Process = ProcName(pid);
                f.Class = cls.ToString();
                f.Title = title.ToString();
                f.Rect = Rectangle.FromLTRB(r.Left, r.Top, r.Right, r.Bottom);
                f.Owned = Win.GetWindow(h, Win.GW_OWNER) != IntPtr.Zero;
                f.Kiosk = (Win.GetWindowLong(h, Win.GWL_STYLE) & Win.WS_CAPTION) != Win.WS_CAPTION;
                f.ClickThrough = (Win.GetWindowLong(h, Win.GWL_EXSTYLE) & Win.WS_EX_TRANSPARENT) != 0;
                list.Add(f);
                return true;
            }, IntPtr.Zero);
            return list;
        }

        // The Showcase window: an unowned browser window covering at least 90% of the main screen.
        // If several qualify (someone opened a maximised browser on the TV), a full-screen window
        // with no title bar beats one with a title bar, and the window already pinned beats a new one.
        public static int Showcase(List<Found> all, string[] browsers, string title, IntPtr current)
        {
            Rectangle screen = ShowcaseScreen();
            long need = (long)screen.Width * screen.Height * 9 / 10;
            int best = -1, bestScore = -1;
            for (int i = 0; i < all.Count; i++)
            {
                Found f = all[i];
                if (f.Owned || Array.IndexOf(browsers, f.Process) < 0) continue;
                if (title.Length > 0 && f.Title.IndexOf(title, StringComparison.OrdinalIgnoreCase) < 0) continue;
                Rectangle o = Rectangle.Intersect(f.Rect, screen);
                if ((long)o.Width * o.Height < need) continue;
                int score = (f.Kiosk ? 2 : 0) + (f.Hwnd == current ? 1 : 0);
                if (score > bestScore) { best = i; bestScore = score; }
            }
            return best;
        }

        // Windows above Showcase that cover a real part of the main screen.
        // Left out: the taskbar, tooltips and input-method windows (system furniture), click-through
        // overlays, Chrome Remote Desktop's own "sharing" bar, the Showcase Blackout screen, and this program.
        static readonly string[] IgnoreClasses = { "Shell_TrayWnd", "Shell_SecondaryTrayWnd", "tooltips_class32", "Progman", "WorkerW", "IME", "MSCTFIME UI" };
        static readonly string[] IgnoreProcesses = { "showcasepin", "showcaseblackout", "remoting_desktop" };

        public static List<Found> Covering(List<Found> all, int showcase)
        {
            List<Found> covers = new List<Found>();
            Rectangle screen = ShowcaseScreen();
            Rectangle sc = Rectangle.Intersect(all[showcase].Rect, screen);
            long minArea = (long)screen.Width * screen.Height / 200; // 0.5% of the screen, about 120x90 on 1080p
            for (int i = 0; i < showcase; i++)
            {
                Found f = all[i];
                if (f.ClickThrough || Array.IndexOf(IgnoreClasses, f.Class) >= 0 || Array.IndexOf(IgnoreProcesses, f.Process) >= 0) continue;
                Rectangle o = Rectangle.Intersect(f.Rect, sc);
                if ((long)o.Width * o.Height >= minArea) covers.Add(f);
            }
            return covers;
        }

        public static bool BlackoutShowing(List<Found> all)
        {
            foreach (Found f in all) if (f.Process == "showcaseblackout") return true;
            return false;
        }

        public static string Describe(Found f)
        {
            string t = f.Title.Length > 0 ? "'" + f.Title + "'" : "untitled window (" + f.Class + ")";
            return t + " (" + f.Process + ", " + f.Rect.Width + "x" + f.Rect.Height + ")";
        }
    }

    // One pause for all the Showcase tools. Ctrl+Alt+Q writes "paused until" to a shared file that the
    // pin and the kiosk launcher both read, so one key pauses both. Whichever tool got the key handles it.
    public static class SharedPause
    {
        static readonly string FilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "ShowcasePause.txt");
        public static readonly TimeSpan Length = TimeSpan.FromMinutes(30);

        public static DateTime Until
        {
            get
            {
                try
                {
                    if (!File.Exists(FilePath)) return DateTime.MinValue;
                    long ticks;
                    return long.TryParse(File.ReadAllText(FilePath).Trim(), out ticks) ? new DateTime(ticks) : DateTime.MinValue;
                }
                catch { return DateTime.MinValue; }
            }
        }

        public static bool Active { get { return DateTime.Now < Until; } }

        public static void Toggle()
        {
            try
            {
                if (Active) File.Delete(FilePath);
                else File.WriteAllText(FilePath, (DateTime.Now + Length).Ticks.ToString());
            }
            catch { }
        }
    }

    public class Slack
    {
        readonly string webhook, logPath;
        readonly Dictionary<string, DateTime> lastSent = new Dictionary<string, DateTime>();
        static readonly TimeSpan Cooldown = TimeSpan.FromMinutes(30);

        public Slack(string webhook, string logPath) { this.webhook = webhook; this.logPath = logPath; }

        // one message per culprit per 30 minutes, so a window that keeps coming back cannot flood the channel
        public void Alert(string key, string text)
        {
            if (webhook.Length == 0) return;
            DateTime last;
            if (lastSent.TryGetValue(key, out last) && DateTime.Now - last < Cooldown) return;
            lastSent[key] = DateTime.Now;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    ServicePointManager.SecurityProtocol |= (SecurityProtocolType)3072; // TLS 1.2
                    using (WebClient wc = new WebClient())
                    {
                        wc.Headers[HttpRequestHeader.ContentType] = "application/json";
                        wc.Encoding = Encoding.UTF8;
                        wc.UploadString(webhook, "{\"text\":\"" + Json(text) + "\"}");
                    }
                }
                catch (Exception e) { Program.Write(logPath, "Slack post failed: " + e.Message); }
            });
        }

        static string Json(string s)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in s)
            {
                if (c == '"' || c == '\\') sb.Append('\\').Append(c);
                else if (c == '\n') sb.Append("\\n");
                else if (c < ' ') sb.Append(' ');
                else sb.Append(c);
            }
            return sb.ToString();
        }
    }

    public class Pinner : Form
    {
        const int WM_HOTKEY = 0x0312, HOTKEY_ID = 1;
        const uint MOD_ALT = 1, MOD_CONTROL = 2, MOD_NOREPEAT = 0x4000;

        readonly Config config;
        readonly Slack slack;
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        IntPtr pinned = IntPtr.Zero;
        bool missingLogged, wasPaused;

        public Pinner(Config config)
        {
            this.config = config;
            slack = new Slack(config.Slack, config.LogPath);
            ShowInTaskbar = false;
            FormBorderStyle = FormBorderStyle.None;

            IntPtr handle = Handle; // the hotkey needs a window handle; this window is never shown
            bool hotkey = Win.RegisterHotKey(handle, HOTKEY_ID, MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, (uint)Keys.Q);
            Log("Started (" + Program.Version + ") for " + config.Site + (config.Slack.Length > 0 ? ", Slack alerts on" : ", Slack alerts off (no webhook)")
                + (hotkey ? ", Ctrl+Alt+Q pauses for 30 minutes" : ", Ctrl+Alt+Q is held by the kiosk launcher (the pause still applies here)"));

            timer.Interval = 250;
            timer.Tick += delegate { Tick(); };
            timer.Start();
            Tick();
        }

        protected override void SetVisibleCore(bool value) { base.SetVisibleCore(false); }

        void Tick()
        {
            if (SharedPause.Active)
            {
                if (!wasPaused)
                {
                    wasPaused = true;
                    // let other windows on top while paused
                    if (pinned != IntPtr.Zero) Win.SetWindowPos(pinned, Win.HWND_NOTOPMOST, 0, 0, 0, 0, Win.ZORDER_ONLY);
                    Log("Paused until " + SharedPause.Until.ToString("HH:mm") + " (Ctrl+Alt+Q)");
                }
                return;
            }
            if (wasPaused) { wasPaused = false; Log("Pause over, pinning again"); }

            List<Found> all = Finder.All();
            // at night the black screen is on top; leave the order alone so the LED never flickers
            if (Finder.BlackoutShowing(all)) return;

            int i = Finder.Showcase(all, config.Browsers, config.Title, pinned);
            if (i < 0)
            {
                if (!missingLogged) { Log("No Showcase window filling the main screen, waiting"); missingLogged = true; }
                pinned = IntPtr.Zero;
                return;
            }
            missingLogged = false;
            Found showcase = all[i];
            if (showcase.Hwnd != pinned)
            {
                pinned = showcase.Hwnd;
                Log("Pinning " + Finder.Describe(showcase));
            }

            foreach (Found c in Finder.Covering(all, i))
            {
                Log("Covered by " + Finder.Describe(c) + ", put Showcase back on top");
                slack.Alert(c.Process + "|" + c.Title,
                    ":warning: " + config.Site + " (" + Environment.MachineName + "): " + Finder.Describe(c)
                    + " came up over Showcase at " + DateTime.Now.ToString("h:mm tt") + ". Showcase was put straight back on top.");
            }
            // re-asserted every tick: whatever went on top is covered again within a quarter of a second
            Win.SetWindowPos(showcase.Hwnd, Win.HWND_TOPMOST, 0, 0, 0, 0, Win.ZORDER_ONLY);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID)
            {
                SharedPause.Toggle(); // Tick logs the change
                Tick();
                return;
            }
            base.WndProc(ref m);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; return; }
            base.OnFormClosing(e);
        }

        void Log(string msg) { Program.Write(config.LogPath, msg); }
    }

    public class Config
    {
        public string Site = Environment.MachineName, Slack = "", Title = "", LogPath;
        public string[] Browsers = { "chrome", "msedge" };

        public static Config Load(string dir)
        {
            Config c = new Config();
            c.LogPath = Path.Combine(dir, "pin.log");
            string file = Path.Combine(dir, "pin.config");
            if (!File.Exists(file)) return c;
            foreach (string line in File.ReadAllLines(file))
            {
                int eq = line.IndexOf('=');
                if (eq < 0) continue;
                string k = line.Substring(0, eq).Trim(), v = line.Substring(eq + 1).Trim();
                if (k == "Site" && v.Length > 0) c.Site = v;
                else if (k == "Slack") c.Slack = v;
                else if (k == "Title") c.Title = v;
                else if (k == "Browsers" && v.Length > 0) c.Browsers = v.ToLowerInvariant().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            }
            return c;
        }
    }

    public static class Program
    {
        public const string Version = "trial7_241026";

        // Fleet (trial 7): capped at 1 MB like Kiosk's log; the older half goes to pin.log.old
        public static void Write(string path, string msg)
        {
            try
            {
                FileInfo f = new FileInfo(path);
                if (f.Exists && f.Length > 1048576) { File.Copy(path, path + ".old", true); File.Delete(path); }
                File.AppendAllText(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + msg + Environment.NewLine);
            }
            catch { }
        }

        // ShowcasePin.exe            run (settings from pin.config beside the exe)
        // ShowcasePin.exe --check    write check.txt: the window it would pin and what is above it now
        // ShowcasePin.exe --unpin    take Showcase off always-on-top (used by remove-pin.cmd)
        [STAThread]
        public static void Main(string[] args)
        {
            Win.DpiAware();
            string dir = AppDomain.CurrentDomain.BaseDirectory;
            Config config = Config.Load(dir);
            string mode = args.Length > 0 ? args[0] : "";

            if (mode == "--check" || mode == "--unpin")
            {
                List<Found> all = Finder.All();
                int i = Finder.Showcase(all, config.Browsers, config.Title, IntPtr.Zero);
                StringBuilder r = new StringBuilder();
                if (i < 0)
                {
                    r.Append("No browser window fills the Showcase screen " + Finder.ShowcaseScreen() + ".");
                    foreach (Found w in all)
                        if (Array.IndexOf(config.Browsers, w.Process) >= 0 && !w.Owned) r.Append(Environment.NewLine + "    browser window: " + Finder.Describe(w) + " at " + w.Rect);
                }
                else
                {
                    Found f = all[i];
                    if (mode == "--unpin") Win.SetWindowPos(f.Hwnd, Win.HWND_NOTOPMOST, 0, 0, 0, 0, Win.ZORDER_ONLY);
                    r.Append((mode == "--unpin" ? "Unpinned " : "Will pin ") + Finder.Describe(f) + (f.Kiosk ? ", full screen" : ", has a title bar"));
                    if (mode == "--check")
                        foreach (Found c in Finder.Covering(all, i)) r.Append(Environment.NewLine + "    above it right now: " + Finder.Describe(c));
                }
                try { File.WriteAllText(Path.Combine(dir, "check.txt"), r.ToString()); } catch { }
                return;
            }

            bool first;
            using (Mutex mutex = new Mutex(true, @"Local\ShowcasePin", out first))
            {
                if (!first) return; // already running; the 5-minute task trigger lands here

                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.ThreadException += delegate(object s, ThreadExceptionEventArgs e) { Write(config.LogPath, "Error: " + e.Exception.Message); };
                AppDomain.CurrentDomain.UnhandledException += delegate(object s, UnhandledExceptionEventArgs e) { Write(config.LogPath, "Crashed: " + e.ExceptionObject); };

                Pinner pinner = new Pinner(config);
                Application.Run();
                GC.KeepAlive(pinner);
            }
        }
    }
}
'@
  Add-Type -TypeDefinition $src -ReferencedAssemblies System.Windows.Forms, System.Drawing -OutputAssembly $exe -OutputType WindowsApplication

  # dry run: which window would it pin, and is anything above it right now? As the display user, like Pin itself:
  # admin never runs a program from a folder Users can change
  $check = Join-Path $dir 'check.txt'
  Remove-Item $check -ErrorAction SilentlyContinue
  try { $code = Invoke-AsDisplayUser $exe '--check' 30 } catch { $code = $_.Exception.Message }
  $found = if (Test-Path $check) { Get-Content $check -Raw } else { "The check did not run ($code)." }

  $action    = New-ScheduledTaskAction -Execute $exe -WorkingDirectory $dir
  $atLogon   = New-ScheduledTaskTrigger -AtLogOn -User $user
  # every 5 minutes: brings it back if it ever closes, does nothing while it is running
  $revive    = New-ScheduledTaskTrigger -Once -At (Get-Date).Date -RepetitionInterval (New-TimeSpan -Minutes 5)
  $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
  $settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
  Register-ScheduledTask -Force -TaskName $task -Action $action -Trigger @($atLogon, $revive) -Principal $principal -Settings $settings | Out-Null
  Start-ScheduledTask -TaskName $task
  Start-Sleep -Seconds 3

  Write-Host ''
  if (Get-Process ShowcasePin -ErrorAction SilentlyContinue) {
    Write-Host 'Done. Showcase is pinned on top.' -ForegroundColor Green
  } else {
    Write-Host "Installed, but it is not running. Check $dir\pin.log" -ForegroundColor Yellow
  }
  Write-Host "  Window:     $found"
  Write-Host "  Site:       $SiteName"
  Write-Host "  Slack:      $(if ($SlackWebhook) { 'alerts on' } else { 'off, log only (no webhook set)' })"
  Write-Host "  Running as: $user"
  Write-Host '  Pause:      Ctrl+Alt+Q pauses this and the kiosk launcher for 30 minutes'
  Write-Host "  Log:        $dir\pin.log"
}
