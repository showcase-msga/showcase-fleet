# startup_kiosk: remove (trial 7, 24 Oct 2026). The same as remove-showcase-kiosk.cmd and remove-pin.cmd together:
# stops both, unpins Showcase, puts back the startup scripts Kiosk set aside, and deletes what the install added.
# The machine settings (Fast Startup off, Delivery Optimisation, Chrome pop-ups off) stay as they are.
# Trial 7: the unpin runs as the display user (admin never runs a program from a folder Users can change), and each
# startup script goes back to the folder it came from, not always the shared Startup folder.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$ErrorActionPreference = 'Continue'

foreach ($t in 'Showcase Kiosk', 'Showcase Pin') {
  Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue | Stop-ScheduledTask -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $t -Confirm:$false -ErrorAction SilentlyContinue
}
Get-Process ShowcaseKiosk, ShowcasePin -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
$pinExe = Join-Path $env:ProgramData 'ShowcasePin\ShowcasePin.exe'
if (Test-Path $pinExe) {
  $check = Join-Path $env:ProgramData 'ShowcasePin\check.txt'
  Remove-Item $check -Force -ErrorAction SilentlyContinue
  try {
    $null = Invoke-AsDisplayUser $pinExe '--unpin' 30
    $said = if (Test-Path $check) { "$(Get-Content $check -Raw)".Trim() } else { '' }
    if ($said -like 'Unpinned*') { Ok $said } elseif ($said) { Info "Unpin: $said" } else { Warn 'The unpin did not run: Showcase stays on top until Chrome closes or the NUC restarts.' }
  } catch { Warn "The unpin did not run ($($_.Exception.Message)): Showcase stays on top until Chrome closes or the NUC restarts." }
}

# Kiosk set the old startup scripts aside in old-startup; each goes back to the folder it came from (older installs
# that didn't note it: the shared Startup folder, as remove-showcase-kiosk.cmd does)
$old = Join-Path $env:ProgramData 'ShowcaseKiosk\old-startup'
$back = @(Restore-OldStartup $old)
if ($back.Count) { foreach ($b in $back) { Ok "Old startup script put back: $b" } }
else { Warn 'No old startup script was saved: Showcase will not open at the next logon until a launcher is installed.' }

Remove-Item (Join-Path $env:ProgramData 'ShowcaseKiosk'), (Join-Path $env:ProgramData 'ShowcasePin') -Recurse -Force -ErrorAction SilentlyContinue
if (Get-ScheduledTask -TaskName 'Showcase Kiosk', 'Showcase Pin' -ErrorAction SilentlyContinue) { Warn 'A task is still there: delete it in Task Scheduler by hand.' }
elseif ((Test-Path (Join-Path $env:ProgramData 'ShowcaseKiosk')) -or (Test-Path (Join-Path $env:ProgramData 'ShowcasePin'))) { Warn 'Removed, but a folder could not be deleted. Restart the NUC, then remove again.' }
else { Ok 'Startup Kiosk removed (Kiosk and Pin).' }
