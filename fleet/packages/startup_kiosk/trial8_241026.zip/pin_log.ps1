# startup_kiosk: "Pin log" (trial 6). The last 100 lines of Showcase Pin's log (what covered Showcase, and when).
$log = Join-Path $env:ProgramData 'ShowcasePin\pin.log'
if (-not (Test-Path $log)) { Write-Output 'No Pin log yet.'; return }
Get-Content $log -Tail 100 -Encoding UTF8
