# Showcase Kiosk: install. SHOWCASE FLEET COPY (trial 8, 24 Oct 2026) of AD/01 Operations/Showcase Kiosk 161026.
# Fleet changes: takes -Url and -Mode (kiosk | console | troubleshoot) from the Startup Kiosk module (which reads
# them from nuc.config); console mode adds Chrome's remote debugging port and a dated Chrome log; troubleshoot mode
# opens Showcase in a normal window with DevTools; the launcher finds Showcase on the real screen, not Windows' main
# display (the support screen makes them different).
# Trial 7: Fleet's own Chrome windows known by their profile, never closed or taken for Showcase; the Chrome log in
# the display user's own folder; old startup .vbs and shortcuts set aside too, each noting where it came from; the
# check runs as the display user; the real screen read safely while the support screen rewrites it; no tidy-up or
# reload while Blackout is showing; per-monitor DPI aware.
# Trial 8: never touches Chrome's zoom. It's set by hand per NUC, because Showcase's text size follows it (Jordan, 24 Oct).
# One script for every NUC. The only thing that changes per NUC is the auth URL below.
# Replaces the old startup .bat (showcase_startup_*.bat / the bat file with delivery optimisation, v110826), which it moves aside.
#
# What it does:
#   Machine setup (once, needs admin): Fast Startup off, never sleep, network adapters never
#   powered down, Wi-Fi auto-connect, Delivery Optimisation peering off, Chrome pop-ups switched off,
#   and a desktop wallpaper with the support numbers, so a closed Showcase tells the client who to call.
#   Launcher (every logon, as the logged-in user, no console window): opens Showcase in Chrome
#   kiosk mode once the site answers, reopens Chrome if it closes or crashes, reconnects Wi-Fi and
#   reloads the page after an outage, and goes back to the first tab when nobody is using the screen (never the zoom).
#
# Pause:  Ctrl+Alt+Q pauses this and Showcase Pin together for 30 minutes: nothing is reopened,
#         reloaded, reset or pinned, so you can close or work on Chrome. Press again to end early.
#
# Run in an Admin PowerShell window on the NUC (paste the whole file in, or run it with -File).
# Safe to run again. To update a NUC to a newer version, leave $Url blank: it keeps the URL it has.
# Remove: remove-showcase-kiosk.cmd, right-click > Run as administrator.

# ---- settings, passed by Fleet's Startup Kiosk module ----
param(
  [string]$Url = '',        # the Showcase auth URL for this NUC. Blank = keep the URL already installed.
  [string]$Mode = 'kiosk'   # kiosk | console (kiosk plus remote debugging and a Chrome log) | troubleshoot (normal window, DevTools)
)

# ---- install: nothing to change below ----
& {
  $ErrorActionPreference = 'Stop'
  $version = 'trial8_241026'
  if ($Mode -notin 'kiosk', 'console', 'troubleshoot') { $Mode = 'kiosk' }

  $me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
  if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run this in an Admin PowerShell window.' }

  # the launcher has to run as whoever is logged in on the display (Fleet's common.ps1: the NUC's own login, not a Switch User)
  $user = Get-DisplayUser

  $dir    = Join-Path $env:ProgramData 'ShowcaseKiosk'
  $exe    = Join-Path $dir 'ShowcaseKiosk.exe'
  $config = Join-Path $dir 'kiosk.config'
  $task   = 'Showcase Kiosk'

  # keep the installed URL when $Url is left blank (fleet updates)
  if (-not $Url -and (Test-Path $config)) {
    $line = Get-Content $config | Where-Object { $_ -like 'Url=*' } | Select-Object -First 1
    if ($line) { $Url = $line.Substring(4) }
  }
  if (-not $Url) { throw 'Set $Url at the top of this file to the Showcase auth URL for this NUC.' }
  if ($Url -notmatch '^https?://') { throw 'The URL should start with https://' }

  Write-Host 'Machine setup:'
  function Step($name, [scriptblock]$do) {
    try { & $do; Write-Host "  [OK]   $name" -ForegroundColor Green }
    catch { Write-Host "  [WARN] $name - $($_.Exception.Message)" -ForegroundColor Yellow }
  }

  # 1. Fast Startup off: a "shutdown" otherwise becomes a hibernate, and drivers (Wi-Fi especially)
  #    never get a clean start. Also why scheduled restarts did not complete at Dacre and Camberwell.
  Step 'Fast Startup off' {
    New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name HiberbootEnabled -PropertyType DWord -Value 0 -Force | Out-Null
  }
  # 2. never sleep, never turn the display off, never hibernate (on mains power)
  Step 'Never sleep or turn the display off' {
    & powercfg.exe /change standby-timeout-ac 0
    & powercfg.exe /change monitor-timeout-ac 0
    & powercfg.exe /change hibernate-timeout-ac 0
  }
  # 3. network adapters: Wi-Fi at maximum performance, and Windows never powers an adapter down
  Step 'Network adapters never powered down' {
    & powercfg.exe /setacvalueindex SCHEME_CURRENT 19cbb8fa-5279-450e-9fac-8a3d5fedd0c1 12bbebe6-58d6-4636-95bb-3217ef867c1a 0
    & powercfg.exe /setactive SCHEME_CURRENT
    Get-NetAdapter -Physical | ForEach-Object { Disable-NetAdapterPowerManagement -Name $_.Name -NoRestart -ErrorAction SilentlyContinue }
  }
  # 4. Wi-Fi: the connected profile reconnects by itself
  $wifiProfile = ''
  $iface = & netsh.exe wlan show interfaces 2>$null
  $p = $iface | Select-String -Pattern '^\s*Profile\s*:\s*(.+)$' | Select-Object -First 1
  if ($p) { $wifiProfile = $p.Matches[0].Groups[1].Value.Trim() }
  if ($wifiProfile) {
    Step "Wi-Fi '$wifiProfile' set to connect automatically" { & netsh.exe wlan set profileparameter name="$wifiProfile" connectionmode=auto | Out-Null }
  } else {
    Write-Host '  [--]   No Wi-Fi connection right now (network cable?). Wi-Fi auto-connect skipped.'
  }
  # 5. Delivery Optimisation: no peer-to-peer update sharing (from the bat file with delivery optimisation, 7 Sep 2026). The DoSvc
  #    service keeps running because Windows Update downloads through it.
  Step 'Delivery Optimisation peering off' {
    $doKey = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'
    # never New-Item -Force on a key that exists: it wipes every value already in it
    if (-not (Test-Path $doKey)) { New-Item -Path $doKey -Force | Out-Null }
    New-ItemProperty -Path $doKey -Name DODownloadMode -PropertyType DWord -Value 0 -Force | Out-Null
    if ((Get-Service DoSvc -ErrorAction SilentlyContinue).Status -eq 'Running') { Restart-Service DoSvc -Force -ErrorAction SilentlyContinue }
  }
  # 6. Chrome: switch off the prompts and bars that can appear over Showcase, so one clean launch is enough
  Step 'Chrome pop-ups switched off' {
    $cp = 'HKLM:\SOFTWARE\Policies\Google\Chrome'
    if (-not (Test-Path $cp)) { New-Item -Path $cp -Force | Out-Null }   # keeps any Chrome policies already set (see step 5)
    $policies = [ordered]@{
      CommandLineFlagSecurityWarningsEnabled = 0   # "unsupported command-line flag" bar
      TranslateEnabled                       = 0   # translate bar
      PasswordManagerEnabled                 = 0   # save password prompts
      AutofillAddressEnabled                 = 0
      AutofillCreditCardEnabled              = 0
      DefaultBrowserSettingEnabled           = 0   # "make Chrome your default browser"
      BrowserSignin                          = 0   # sign-in prompts
      SyncDisabled                           = 1
      PromotionalTabsEnabled                 = 0   # promotional and welcome tabs
      PrivacySandboxPromptEnabled            = 0   # ad privacy dialog
      MetricsReportingEnabled                = 0
      DefaultNotificationsSetting            = 2   # websites cannot show notifications
    }
    foreach ($k in $policies.Keys) { New-ItemProperty -Path $cp -Name $k -PropertyType DWord -Value $policies[$k] -Force | Out-Null }
  }
  # 7. Support wallpaper: if Showcase closes and stays closed, the desktop tells the client to call support.
  #    Drawn here (logo embedded, Segoe UI); the launcher applies it for the logged-in user every logon.
  Step 'Support wallpaper' {
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    Get-ChildItem -Path $dir -Filter 'showcase_support_wallpaper_*.png' -ErrorAction SilentlyContinue | Remove-Item -Force
    Add-Type -AssemblyName System.Drawing
    $logo64 = 'iVBORw0KGgoAAAANSUhEUgAAAyAAAADgCAQAAABRecrKAAAnN0lEQVR42u2d63HruNK113lrEkAK/ELgDoEOgQ5BDoEKQQpBCkEMQQzBDMEMQQiB3w9SV5NA46ab1+M6U1Nn9pYhXHqhG+jG/3oQQgj5E+TooON93P+xRwkh5I9QYBfz4ygghBDyV9BxJYQCQgghf0lCyngSQgEhhJC/g4opIRQQQgihF0IBIYQQIvRCNhQQQgghPl7IAisKCCGEEFcfBNCoQiXkP/YkIYT8WQkBlvRACCGEwDmQVaGigBBCCPHxQlb+EkIBIYQQSggFhBBCyP0khAJCCCGUEC8JoYAQQgglRGOFBQWEEELIXSSEAkIIIUQBADZuEkIBIYQQcvRCNigpIIQQQvwkpKCAEEIIcZcQhZ1UQigghBBCLku9iyWEAkIIIeRWQjbIKSCEEELcJSTD3i4h71rOPUMBbeygFi3nCSGEGAJZn2Y7+a4Cklufa6zxyVlCCCFGL+TDJCH/vXGd+7D/Tggh9EKMEvLfm3/5OfFQnB2EEBIWyOIhOiGEEFMga4eMAkIIIcTvLCSjgBBCCIkmIRQQQgghkkCWooAQQghxl5Ac+1sJoYAQQgjxkhAKCCGEEKmEXAWyKCCEEEKkElJcSggFhBBCiJeEUEAIIYR4SQgFhBBCiLuEUEAIIYR4ScgeigJCCCHER0I2FBBCCCE+ElJSQAghhHhJCAWEEEKIl4RQQAghhHhBASGEEEIBIYQQQgEhhBBCASGEEEIBIYQQQigghBBCKCCEEEIoIIQQQigghBBCKCCEEEIIBYQQQggFhBBCyKP4D48sBqxO/67H/+EpixZftlMDL9FOPHFL8QcKXT/zWKjxf8ObDs/Svufts1exAH9AQDJkyJEju5rGxwmj0aFDiw7dw6fMsZ3qop3nVrZo0T18KimosZXX/alPU70d+1N7j5eZmMvpcple0kWdfza6gBmTjWOhTmb6PGvOM1s/bKZkY+um2veYWT30WD7TZ4+zB7aVdeyrR9upPyQgOUrkyGeMhLoxSx1aNGgesNgUChQoJk2NujE1DVrUDzEIGQrkM628bGcxtrRFi9p5uuf4tprb/xftO1WoJv//DzTR5qDt+7T45zkWOXLDfh+n/9qOY6HvOFMKZLOt+z2rW7Ro0CZu17DKclGbho1QHW0e2Nf/3GiqC2s2tGuwU3+W//X3GJISi9MeQwtd7GEy16i9pnKJHfSMWAEaClt8TRiYxckoa2ErNbbY3nEnolCgROHQm+eWtqjROLV1bzA8R/Mey9R8z8jhFstIv2GFheVPrLF2nGe+Y9Fgm9jwKJQoT1s27RDeGubKNtEGLhvb5dpngz1IudYKLMboyL3s1P1ZYGOwjO70qX+q/qcfOPSHXsZh/Bn+fd/nzr+17HvDbzv0fb+5+RtFv7/67dJWDv+28Wij+4/qq/7bsZW3f/anX/WZw+jZ+nEV6bvls7/hJ1r/7Q3fZuij/K5jse/LRDMl61dX607auus//d1X0Wfwytse9Ke1liXosdJ5/V9/h0O/64s72IDQn4VxRTuTtrHFuMTcpvDvieM+adwEJO93zpP6dgod+lWvEg/9T5TedGlrZvxdh77vvyN9u9XMiB36PpI459bvsn/AWOyjmx3Vr07jfPA0Fue/+RNR5MqgXjskW2vHzWNou/p+l0Tc/qiArDxN8rSBdpvILgKyGkXKv6XHv/mdbA9yKcV9pP5c3H3Xbvr5nhWQQyQvx+5NVcK5FXssNhHN4aW09ZHat4vQPtVvotqD70jzTo2bxxjtGuxIRQGJ4ULvI03i8/J2GRqpgOQnYxBnsaWYPrGW3m0P9P1esF9aRDK7vp5OPC/n2zLOB0FvxB+LwximK552psRoXzb2flx7UEbyieK2K564/VkBiT1dzhN5FU1Adj364uR7xGzjLmpf5gn68lLwFgLTbvJB4pj3ee8glpeTW77HQfA90o1FH8HPir1pu23fIsB//olrtk6fFtZn8eW2f3o/5AUEJEswXVwlROKBlEaTEjKx99FCEoskbXRbhHtrC8LN+94iUtUTBLBSjsUxlBUikD9JZ4r/hYkiUb8dgi5xZIk2A3FG8w8LSGYNFYQOzSqKgPxECl2llJBVsjbe+kwqKIi1ihDASu3lhJ7lpB6LQ9C8SSsfIeY6Syq7h7738ozyhPIRPpp/WkD2ySdyL4h9loJWHJLK3D64JzdJ23jdC9+GqZ4ZLxjE+K72SX0IvN2SWU4/bBJ1r7HwMzpZcvnwlRCVdDt5lP7iSXyilLGIJxWQ2MUUVyiipqlMpwFuBCUp7J+ikrVTQaPALugzNlgkbeNl0QaNHPvZPu3QGluhT8lXvpSCsSoDU8SUJTWsto4F7jAWw7xRznMlS77qhm+vUVmTMa/tQZ60ZUORkY3Tbxh6WN9pNPfJfw/epxpvPi609IXgNlE+J+3kKbEKlo97Zbdr5AbD1VjHowish6QFyz6tRNXG/PV7yIfv1uMem7ZLCVlZqxOcez39LFbQyBxWWn4n+ZCsK7CUyW0xCpf9hvY26BoKn8Y9o7mUCZK3UNbKuPIR3toGHzMm/tuw6DSAduZvxiquoAH88y5iYWv//DcHVqjuPBYaCjU+HfbT7uvHfzulodDiQ1Tq5/uqYGpKewB8igrDZNh7eGs6YPNpnl1gKRO3c4f5YgFuBQRsBS7KwEhfaAvPfz67Q5QyRmunC7xIb0mFnFHsRedVfcA10tL7BlbMsTg4jUQVKbtF0o6D8+rbBN97i20P9tF7K+Zobt71DCRmNd5KFL7SV0Wb9c37BLJQweC2ll67e9lu43cLlVMLj61U2DjuPgqsHMKAc629Lowtb+8CLbaTJwSF5XsWk39PFsCSfdPS8zeYA1gaCnpm95piLGSjoVGhFeypF0Kf//Y3n8vwu7dPjWPRWtvmZg/0RQuUsz3IUVj7a+MQIdEXDwzoq75Rk7bMb12B5dzPscXM2p3HDh8KoV9W08+gkKNEJh4WjUUCATlOr/b0NoK+esmkcGjhMaLtInTDgaB8kquLwvLX/ZmNZcaVk4horNBOmIZmNLTKYKS3nvNG9n2H9yx8gljDCY0yFqVvo41F++ulCHWaO2o03Uq49fhnMcHKcdOmT227fMdFja/fnOtQS0ZjZdkYlYJQ0bFdQ/l4fTN/z6tNttYWFgFZiAPD5/7qfrVMjbYqd1pbc+vq9YnmGm0EVzF7SwVSdaqJeRC5lnnUENaxRpSpsq68hed2/jhc5ds5ffJQZrIQVWU9iPtg+krv3lKK0DeItRPXPvYNYvkWY9k49dpQjzU3XmktL4r2xQh8yGb5ed0p6/XWnfCC66HvLZdn7eN6rLNVGHpsIczXGILambVYzsHBDqwsmUF5vxJXRYtZdvRN80DslYakCf6VaBKb48SlR+xaXvXXpYKOSzy7dJzksiLy2UW5SP+IrT2Te+FVvUl6I9+/SMzOK4WwdJIPeb3oQpzCZs9w2AuM9MGx4q8sxc42GsqamSKtZqWEKZy2/LC9UBiPdkoJ5+9CuEGL+fTBGwpIbjEEww4hj1g7x3xwVjoflrnV0lXi1DK5D6LE6WAH58q/uTjBc86k2gu77xJfvOj7g0dalrlX52aR6n8cBNe1CrN8i/QdmOPtZ7Zk0QSTz1lYVoebPShF3/Rg8NhKB/nYO/vSlbB9hyco9v6kAmK75+JaEC+3LmCzQXETkINXyerKIRixCHgRY2qS+9zqWDm0d+9xE+vHw7zvnO4Q9R71VwuvAFbqsSiFEmIqYbgQmfkq6uss0lm9iG4PDgJ78GPIhz8IK1OskpWSiV9o9Y0EpIpe9LsQhXOKKFeKfaeNLOQkq/SaiT/L/0LrQngaMh3htp8llFG9g6nvvou+m57aFbqMReVdofYgChT9BHyzkOuje8Gn77zadvCaKwuR4ObeF4oPgVfFM4GPbz85+rMCsrHuTpFg6c8vX7fQSHWH4ciDwwbHndsiyFOUmsa9R8nDTbIAluygdOrnx6NM40oss6nHwmRqv627/J+ASkxZUARgn6A45k5gD0rPcOQheDTRK5Ho7lkLy6cwSOPxmeuL+9fzWQTh13a3WHv//S2W1ipLw9XN0vI9SsGnAArLoPvkNZany4e267WF6LJrSLmRwqnwzZD9k3vUwFJONbAyQQbDcBk3dCy2ogug1Uxv2K7NK2wDCgt1WBtn9tCvuac9qO9oD0pBgkH4ygI0PtFarIGeWFf3RT9nLawUAtKN00zP/CA4JX8oM7AM+ow1tgIJURbDtxAVfVD4Ck5H2uJL8HuGHAO3mlhDcqdbfoZ7iZDSMYVQGZfSVAqhdCyWARuPgaXV4KhJKT+aSm34Mdf3kgmcts7s7I724JhHYfrGmVdCY+g28vw5X0aRG+ZVCbCY4n10rxlzUud/ssA2HYc8zAx01m+okRslpBT6SjGyWbcCyVOTNXZryx5QO+2ucoHwTgmxckwhNP33Ka+qvJvBAZaCXfW0aGbWtaG9a4dJPU44+oOhO2AfezAk0ypLi9rAbeRZ5JYWr1AbNzX4u5noKWrfNlgavAwNFbBEjgGhDuHiuMTOso8c3P3WO2t3KGH3FWk0vpAJKrgqLG6WVYfWGHZSgrLpLuGlaS+nEO+sc2u/1p5j0UUyOA0aq2BN92prXRttBHNYWAvR+FSo9bUHtTHqMG0PStHvW0YL7WxRWtaWCijK87YCoq3Govb61DVSilob6fNrNAKDnBv8Dy2SqXh84VsQAvxtuBpLTawMuTg8UXq/7VGLf4N2LuJeWP9OHL8VpxBo4SWaXdK1cRQQ342htkp743ku417GxnYqoVB7tWZejPbJqrq9bQhLC3abz0e8YVyL9sO+YZn4k3w4IrUbrsw5Ll5G8Q50hLlkPmMZ9ujdxO7QfvoRcyxaNAKvLX/I+uiS2YN7nQMUFn9SJ9imtqgt1w+yCA/ivZmAdBGffMFdzmTU6ZA+VijCfq6gnmaSA2t0ghanu4lVWg+PQ29i2c9YGq/SjrHHohYZwue8sTM3pzvr+Vp1JwGxX29pohc53Bq2WUePkgLisFcZChpXT/bd26hX2hrBYstmDJ0W7Hm76N9/7RVmqq3CXIhPQOY/pYtwVJ8bblPNFXEvRI89xR2LZpRy0+2i/EE+SKrgl+vTuPCuEa6sLdkm+PbNU3qUTy0g2hprXD3Z445N5E+zH0orj5CMTjTJgVrgg2S/2tYYd1fS523nA1gaQGe8yyK9CFl63DIqBOcfsX3BQcjMt4seY3J0kD2wP0u9SmwPckuoaIhDNEnW1jN6lE8sIK11ygwX2H6weor43/wjQmH+jDbePckc/JK0TjZEeQJ6JoilgxeH2f9ox12+DvBy7O/T1AK5nLp4Ed8XXOIf/p/lp37IKglZDbY0RI0K36gS2oNMEJBskGZz2lnPQcBbWNddVglyCxQqLNBgm2jg5CcgOrohaAVS4OfMpuqrekyacxO9xhBZVmO4pQ3wDhQaAPVsBvYgIE3AJeG5FMIMmXXXneYVzPYh8pBdZE8c/WN1M1OVt1dVWtfCcDa6QBP5isjj15Y2WIPjpf4OoIBcGyPpHfASJTrU42tfb5HS7/2Jtl1SfF/p2m+0PfKZTYx0Zb2m2Hp6B+egQmOcT0VgAGvaq8usJlM/dOMTLhjZ+M9MVN4j1B5okT3IsMACLZro9iATbCPbZAHyMmkRprcTkHZMiVKCfcfQgRUqdONzlt3dhaR7wCcqr0neJdyrtNZdWjZ5dmDKerEHmMwphA30+M/pcxLJC9i51ZdovMaiecF9YzY+wJpNnsLpREGsBq3gBfLzo7A5clRo0aFBc/XkbioBsZ/VpDwTpYDgdyS3ENWnUhcTNxvrJ3XoTq9Jv6oHkmqSp9zzNla/MZuI5daCdMLW239oRHs4cyqaWaLUzPlPFiG17pk8jgLFzf0t/WsdpvNCltg5nLTocVRzlKNvfPxfiMdl+35t4mP8+TlIAZlQ8631HOR276Evos/FxTP27XtECCPtklL6YdpgaueuwTbGvzWYrta4I9aCWzHmIEhpvA1Venl1jx2LuNJRXtxB0hE8Cp/NyTCCysMeHIVEjx6JT2hLWYPDQJkoxVlb5Vl5VIJ7+1pYS+SCkh5TDrK+yMrOR4+kSZL98GxLXVm9pC7pDsle9+n3RO+sVZJM5t3sHZxNRYvOkGJp8nJyqxTUzgEbPZqz559R1VjA/Dh/1MMuzy+RC8JYdntQjfEJN3uggtdfyvtrih7IFJ/4thajM3XntUdSnY7W3llCYDlmTO2B2H2kbvImlrkEual0pCxgN3+T5XgTqzXmoLvdwLIbE/X0AjIcR6sL6cCD6z18YRdgD64jFCUqtKhPZd1jmGj9wJVND2RyQD6wc9p1mIRkiOJqtNiOR6vvKCA2H0A/vFwFZm5iaUOe95x5ny9Eon+dTdRGsZn3cgprLkfrZXD0U8/BxZhToZ9of9vi01NCpjySS3tQRwgOP66f9AP9Qjz3eyAdPse6UDowtKNOIZYCO+zvUvrg+VK1ntNkddbjx8LwxJPtBpb9Josad6XThqNwTiGUjsizCkiOPTbIxvWinqqoyeepVEtce1CCvOWDUh0+UEdy0dSpSlCODfbvU0PmSdxs/09vrA9oZR7JXc1E1sX8gXspLELvmoH/apTYo3hC8ThKyL8E9qDADrsXvcukKCCwnoV8jSGJcLdfnaZN8aZ+yCtO99qrJlY2m8U+Xd6w9vBySuvDXL4nGc/pf1TYjV7dsxomjU+sE9iDEt/0Q971Sdst/mF7Mdhx9h5DCTaCpwhiueeCF8YKub9Nu6mm0LSXYy/23rzVznGFlfUu3TOwxMfpSdqY9mD3ovZAU0DsJuYLH+NOVV0Upw47cNaohAlK7zKN0poG/1OY2qMWqvlB3HqysDucvBxzDSz10sVIpuSjeqpDcxhDWR/4GM+14tqD1cutevUuEvJ/SJ1M9IkPrNGeClOHTZxjVd/NnxGQ5zUNjeXZnN/mPZt9n2H+cm3t6OXYnhCyeU76hUajDJQPbf2JP2c+8Dk+ZnZpD0K2P68oIc9+ow+PusY7vfNoAeRjbmz2K1XIZ9+xiPxG+KMrAz8uY9XfA7GnExY375iYnrGdqzNlrimU32Sp2N/ArgPf39NPdPNq4yEf2lJl4B4bjwZr5ChQXBTQ1wHWQKNC9+vNHP3kIWAKiIeMDIXdfk8ct8mjoMekovcQEPNyT7nMVdBFYls6YXFj3kuPs4n50o1HL2crznI3V9OVnCRkT5RKuBK8djEtHJde3+3bh+c/qZFhk+h0RaNBMyac5ihO89DXGmisfmX36Cc+i9DvcgbyH+6tu8NL5NlY5i2/EBI3Y6mxeoPkQm15hktDIUuYiZ8JnvzsDLv5yvoc1fbi2+SzI6wMh9u10c+5FRBbNd3W05gcxwJPE76SFw26XFkt9FikUFt3wSp5qPho9HMUyK8uQLh4JMfrNf886papB20aOwpIaOHFYf87TB11U71HMmUyVG8QxtKCUEX9oDfbbBPdVtj92rwXhmdslaFARTsb5lM3WR/2QvKtZVbmEbKbcafLu9pJPHweTlB3jk+osYRRftrYuNiDHIurzYS2hofxwNeIWgpInP334JEoFMivisBJQisLrF/eB+mivKuGZG+2mX2kxmKy8wvzXni+9NcaDPvg5dSCM5b5Iu7PMhZu/oekXJA++XY16hdYKXosmTiEuoczEpdAbnUjIOYNweCRrp923VNAHN/nrrFGjnKcNrZJM+wtFg+bAPH2Xnajle7otghsX41qdpc3eIlH8z7vHWjrS3+1wRBolCdZKA39NHhTbbCAPMcx+kLQCj2Kx/oFLy4PoW7laA+yi7kg8yjx1oVa8frXeN2P1r7wD1/jNT8dwQC+RghLG2WySPhWXVj1J3s6YSG6gWX+nNqYPZKf3l6wve1Qi3aFjxkL13FT1nFT0GP63qsmuw324ANLoT3QN9c0XsejpIBEnTZb/BsnjbbGPbOX90DsoYhU5RpKgZFoA/O6y/HblZZQmL10ozZ4OeczFl8v5/y81v3H4vxO+fyPcvKD9KmAyOvXbOqwxj8sDVlHvzcTUu9CvcvLgBSQ2wWwxses2cDNzR689BlIZ+2LVDJZCvawrfVpJj0rQ5d79sK7Pq5dYIqLf86fgNi9Jcnr80WCsaiwt/6UDn63HuvRNclfy7ynPfhnsQe/78l1RtF5Ho+SApLItEok5PWd0NbiZ2F8N/4RB7F2k2ov7F4aK+RqkWlvjPvhQmRW6whjMV8DOGwk7B5I62TYFbYRTj7yJ7QHtsvWuXg03yUITgExVvHUL7NLgndmrhIcmqoE+97Qou2yP5NbiihKTHs7azqOQazc8myRFn6X+49FMb7jYfq5FHJb2GWQ5OVd7ujd/4VD5WQPGusnFgxi4cG3sDJD7Pn4Apz23nXUWFhKfby+gHTG++qDiYx936wUvRMnMbr2m1il4RquXKZyoxmAtYh7C3l9L3XH/KOFZR7rm720pHrAFnEO6/1kR1mvXmhvb72xZB7dCsjC6lFW+KIQPFJAKqOJ11BYBhi/xvICiHqDe1itIKpdoY56d3xlfXZJElqS1MTS41OryvtswjYPJGGlWnzvpxTc9dlGG4vMWv5xqBPmUpErTsXhwrIxnJ9ZhcUefAakxjZOQacGndUzLbF+l6wMvGQISyc9jNN/4HUvW+BkCP/ErDi6EfofOvh1QvXrbsxvY6cd/DTT87YxirjXgvmWRRyLylLWcK71yvjnuyiekV/BRZ00NNZFzfiOv7LogbxYLvU7UKOyGPShiP0iUmiiFCaibR3abyuJ4vIKyFz4IvMuOtmJE8bse9aYY5FZrjef23TvUn05Ss9CimntgXJeW6W1CEq8lXV5cR2emU1/TkC0oGpV7p3xmf2BkgDaGqg7lo9sI2TOSsqAy08NJEEsFRwmGxbdwnAlM0YA61gTobrbWGxEFXW3D0gA3CTbUOpfRfjTCkhn9bZjjebgt21EJ7tgCEuWvzsM+iLZTZD3UPKtIZvi0tneBd8ZybAThibWTkE4BDxL5XbZwE+gXUyOdCzyYGNTCIr9TZs2nTSsuxLV2vIRECUqegnva7faWX5jrayhdSvBM11v43/EOgPprGUVSs/hUR4TBi+ZC1Jbl+vgy+2DJvrw97WgfInbayv+S8LNtPuVznbbXbaCy7zDWIRJyGBs7Cvgtm+1VXSyQGMoC3GGBNCqgCIu2lG+hgsPWjCaWbB8HDdncz8x78i9kQeiBQpfee7RbObuXYqhrUXGZJCQPKl8HBPR3OZA6+wduL9Q3npuGdqEY1F4e9Z2T3AI8a0d35AJrc9wfDBaBdgDW8Z45mkPVtY+6ybP8pSoHPw+sN92goCkinyb8i0SCVvRI7QLD0W3v3rwLoMxVB/VQrO18NofyeRj2LNvE3oSrjewroNY7k+e1l7+oBY9Y7TzGotcZGymd6taUFSw8jb/JTaBz91K3rrQqDykt7ReeZ6+f2b3Qc5eSOl9m24nen1EG0PDGRbY4Rvf+MYO1QtcP+pj/Cz6vj/0Jg79oe/7hdOn5v3B+LnDf80m/25p/ZubHpF/KuvvXBn/ftYfxn7qBX256ZVD21S/svTm9acXzt8+F37+dY8sHH/LTtRD17/j22MsVf8jHIveeSzQL0R9degP/c/kJ+8sf9t/flcOo3jo+5n2VQJ70PcHx1lWWNbHMNbKwx6EjSb6bByRg+DzV4ZP2fz6hEO/6/OoVqp0XKUW4jQqEy4Imwl1W2SHvu/3Xt30nAIiEeJLI/8jNr9l/32xQOyjtPP6/nunqWmS/3jT/9D3fZVoU+Q3FoOxkZqzhcdMc19rxy3AXjxLzAKSi8e/iihth/5gmLk7h+3Tj8PGRolFd35DMMzsn9OfOv8M/0/57gIiMx7nwVGWISlFU9m0SF5TQFyM8PCnvvvKaISzfnHqS6k5/HHegUnN2u1v2nt5Bi4m7tAfvHdwO8ex+LGMBfpi3GNKfZu90duTbASUWDzkLbMLCPpv4X687/d9YbUHC9EGyOzRSv37y5WVW32i1cnIyz63NNirqd4/eMVu7igg/0VLhctFN7g1MmxQoUGL9ioyqS5eSJe8QKadUt1ehS98WxLvLmO2QI4cFVo0Y7KZvsiWlvfl9ed+ed7AGfIntMNvqr3i65nTCYj//f4lCqexyLAax+Ky9OPxUHsYDQg/cZjdS+dX4m8T5HJsxyvipvq1i7HYpY5W16EW3DAbeq1AgXbsNX3Ta+cX0iHKXDLlV3RYjvlP8pWlx5Z1Ny3LkI8/Lg9wK9Qz7cuwmel9NZ55rdA957uS/0XMpZYcCh6X2uJ0HKhPnajEecVveZ9hnOZf2Fkval5OruGqc3HVm5dXBl3EQ0Nh7Z3kNKQTaofD7cbr2m+Z/HA/fCzOdxNvxwJC+VBYGqRPkuw4HAuvUKFGiw7dzfzIkCM7vdOiRUUa49qDY6/lyLGYncHyOWy+krFFbinMOj2alXFtyVo2yNuXVzrp8N9W+HjGlIX/Ir5pXgn1/drrmMrpUOKXC/GGZU3Wwp4096Z2Tiob9kjLoJpehcPvarzkvx7LQKqEuSMxxiKbzFVy8c7Wlqx8CAy0PqXxXt/durxnpRPUlOvEQh/HHtjvNw3+fWZN3Zxq19zakluqoRS9nrkdmQu8yTx6Pe6nEhBgK5rSt92ub8ruuRm7p3TqglmOFZKUc3EHHZCNPFze/bqLHxriG2ixTOmgANZxLJRw1xpvLCQj0aIRVdFSFwKhZlJwVaK8psLZHuhfZTjhEKyUVEj+xN4hx17NpCsr58IyCsvZ+b4QZVBpFO8tIB3WoszaGEUXzBHi1+cTO69SdiF39xU6wfNdYTWx/FMIb4NY+g7+h/uuNcZYDH1jH4m12NtTM+mXKnltBdd8dhVQjU/2hJbGpziZNl5fKWwNxl+a6xFSQQyv8CLh2iMb2X9Ilm9dw/9TlMqGaAFIhRYfEXq0ifgWvO3Rp5QidT0Wzd3G4igfXaRkx+v9/FRZjXSFgpaC9D1EKuaqsBT+pg6f3jXVfEe0NviTmShtUwleonyDJ22/rGXoYg3J9i3PPx4jIUfvo4vysokWtroO8nNi/0nbrvU+EnKUj0ZsoNO2KuxWlsby5iQhnXy4XP1o7yghg3x8AhYBuYcf9AIC0o5TJvWQNG8cvrqUkC1UlLcdzIXvYnkfmK0cOxWAbO7g59TReunjLmPhIh84Bbp00vbowEsI6g7RCNerHy0+7hAt0eNW9xN8kRDyo/R10oU2yMfn+5RDtnh0a8EDpqG7tzqafEiNuwr0DWS1f3XUSxZpx0KPfuCHY3HJr2R7/GN72qDVvEwqvHq0B18eXuzH6OGntFQKW2vbOodNgH5/AQGW465DJ9st/xX5GHrz6G7rRAGKZeT+rBMHsGS1f3WwSN1zLAZj0+DDucV1Igk5rjTJMwM24d0mswfH7Y/2DEym2xIM3tuXQNo64WYo1kPFTy8gwBLLcWD000wXvHBeyAeayP2px97s8Bn9aqDduMc43G6QMoXw3mOhAKw9/cBhjxu/RfUoZ3XwUXga320Q3XVQgGiJj9OWQCfwJrcRA7J6rNzxBwRkWAxtxElzXGRff8r7uHS3v9BF6089Gpw1/iXJpGkEVy7bCH6O7c2JOvlY6CjzejiDWgaEjYfVFmOXr3/5pZLXNO7tu+nTxY9l8Fz9N8pbrLV1DF39E8/xrSiIpZ70Gdw+1Y86FSc+BBTvOhdAcytr/KrFFO0F2UP68/w3YxeJlhd2D+2Hc7k+8+/47p97bh9OJRhXkVp0vV78V9r+Zm6omfE0FVOcLlbeR7UHWcQZuwvsvev+c30MYSOoO/793sUUp7T4C1tUpzJtbhfRrv9861Gh6R4Xiu950KWxRI0FSo/+1Fd5yQ22SXP4W7TIDT0R53C7vihlN3XZsU46xl/YRhmLrSh/WtaiYXbAs0XzK02PhVN+97V2rCxWR7IHDdZRZ3CLTxRBvXdu2dZj5i1RGJIbj+cpeOdiivMDk6FCcUqBMRd40BPFDZrZGpbwvjed7lZI2t/Z4gtrlChP2aum/vzdmy1abO/wCHAzm7sd73C7mc1U0NFvYM2NxRKLgLGoIxcDbdCgOFXWNdds0hOZ6u2s8duinOhr7dXCofZviD1YJ5nBx7blE+MpaVk3jqhvptEO2YT9OIabP5/16e7/9bhL3niBAsVsSbLfw6ShL4qUw+t9YtsONvb97AorQ+rVUOk2Vv5KgRzlTRKSNvTmML3bO/lkGb4N+7dtpN3Ut6EIRIt/d1tD7mNRo00ocBmKUxF02VobVprJRM29/d7hn8ecur89cGlbjtLStt8tq4OPuDPsJvx2Nfpu8WZLiV3Esv13EhBcVHM5/qhJXe+g0aFDG2jslLVSUBdd0zNjmbbhYmQX/TfmyKAm+nO4WXLsy3vf3ygMUzRWa3KD29/dfcc2FEfPx5F4/FiocW5Mr7Vjezp0onfpsxmxDvP0zj02bQ+6q1beezyLi96bG88uuFzn9Ra0vOnnDjXWUbd9Ly0gv8tJq19nFn/vllWc/pzqTfYlx2J6rT3bSlOTJdOfo5X3HM/hSb3stAlqov+eNxEQQggh9yaygPwfe5QQQggFhBBCCAWEEEIIBYQQQggFhBBCCKGAEEIIoYAQQgihgBBCCKGAEEIIoYAQQgghFBBCCCEUEEIIIRQQQgghFBBCCCEUEEIIIYQCQgghhAJCCCGEAkIIIYQCQgghhAJCCCGEUEAIIYRQQAghhFBACCGEUEAIIYRQQAghhBAKCCGEEAoIIYQQCgghhBAKCCGEEAoIIYQQQgEhhBBCASGEEEIBIYQQQgEhhBBCASGEEEIoIIQQQigghBBCKCCEEEIoIIQQQggFhBBCCAWEEELIPfkPGRS7gRBC3h6NLL6AbJBBU0YIIeTNBUQBMW39/3ogxx6KEkIIIQSOZyAtPtBBQbM7CCGEuB2it/hASwkhhBDifgurwwcaSgghhBD3a7wan5QQQgghPnkglBBCCCGeiYQaH6gpIYQQQnwy0T+xpoQQQgiBIA/kNxVW0AAzQwghhLjVwlpjCQXQDyGEEOJaTJESQgghxLMa7xqfAE9DCCGEwOEM5EiBHatkEUIIcX8PpMEnNL0QQggh7g9KNSy0SAghxO9FQhZaJIQQAtczkCMKe+Q8CyGEEOL6JrqmF0IIIcRHQAYJYaFFQgghzgIy1OploUVCCCFwOQM5s8GCVbIIIYS4eCADX1hTPAghhAD/Of+NJYCKXgghhNADgYeErFlokRBCwDMQL0psAHohhBBCD8SVGl+s1UsIIRQQXwlhoUVCCAFDWD6w3DshhNAD8YK1egkhhALiCWv1EkIIBcSTDp+UEEIIAc9AvMiwQ04JIYQQCog7ChuU7E5CCKGA+FDxNhYhhPwd/j8R+rtqZ5wctgAAAABJRU5ErkJggg=='
    $W = 3840; $H = 2160; $cx = $W / 2
    $bmp = New-Object Drawing.Bitmap $W, $H
    $g = [Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'; $g.InterpolationMode = 'HighQualityBicubic'; $g.TextRenderingHint = 'AntiAlias'
    $g.Clear([Drawing.Color]::FromArgb(11, 27, 43))
    $white = [Drawing.Brushes]::White
    $blue  = New-Object Drawing.SolidBrush ([Drawing.Color]::FromArgb(1, 112, 203))
    $grey  = New-Object Drawing.SolidBrush ([Drawing.Color]::FromArgb(160, 176, 192))
    $mid   = New-Object Drawing.StringFormat; $mid.Alignment = 'Center'
    $px    = [Drawing.GraphicsUnit]::Pixel
    function Line($text, $size, $style, $brush, $y) {
      $f = New-Object Drawing.Font('Segoe UI', $size, $style, $px)
      $g.DrawString($text, $f, $brush, ([Drawing.RectangleF]::new(0, $y, $W, $size * 2)), $mid); $f.Dispose()
    }
    $logo = [Drawing.Image]::FromStream((New-Object IO.MemoryStream(,[Convert]::FromBase64String($logo64))))
    $g.DrawImage($logo, [int]($cx - 400), 380, 800, 224); $logo.Dispose()
    $g.FillRectangle($blue, [int]($cx - 90), 700, 180, 10)
    Line 'Showcase is not on screen' 132 'Bold' $white 800
    Line 'If this stays up for more than 5 minutes, please call Showcase Support.' 64 'Regular' $grey 1010
    $lab = New-Object Drawing.Font('Segoe UI', 96, 'Bold', $px)
    $num = New-Object Drawing.Font('Segoe UI', 96, 'Regular', $px)
    $y = 1230
    foreach ($row in @(@('VIC', '+61 480 062 490'), @('NSW', '+61 485 995 062'), @('QLD', '+61 468 230 180'))) {
      $g.DrawString($row[0], $lab, $blue, [float]($cx - 530), [float]$y)
      $g.DrawString($row[1], $num, $white, [float]($cx - 230), [float]$y)
      $y += 150
    }
    $lab.Dispose(); $num.Dispose()
    Line 'Monday to Saturday, 9am to 5pm' 64 'Regular' $grey 1740
    $wall = Join-Path $dir "showcase_support_wallpaper_$version.png"
    $bmp.Save($wall, [Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bmp.Dispose(); $blue.Dispose(); $grey.Dispose()
  }

  # ---- replace the old startup script ----
  Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue | Stop-ScheduledTask
  Get-Process ShowcaseKiosk -ErrorAction SilentlyContinue | Stop-Process -Force
  Start-Sleep -Seconds 1
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  & icacls.exe $dir /grant '*S-1-5-32-545:(OI)(CI)M' | Out-Null
  $backup = Join-Path $dir 'old-startup'

  $sid = (New-Object Security.Principal.NTAccount($user)).Translate([Security.Principal.SecurityIdentifier]).Value
  $profilePath = (Get-CimInstance Win32_UserProfile | Where-Object SID -eq $sid).LocalPath
  $startupDirs = @("$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp")
  if ($profilePath) { $startupDirs += "$profilePath\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" }
  # the old script sits in a Startup folder itself, or a shortcut there points at it (often on the Desktop).
  # Fleet: .vbs too; a shortcut counts by its target and arguments (straight to chrome.exe --kiosk <url>) plus the
  # script it runs; each one moved notes the folder it came from, so Remove puts it back there (Restore-OldStartup)
  $moved = @()
  $shell = New-Object -ComObject WScript.Shell
  foreach ($sd in $startupDirs) {
    if (-not (Test-Path -LiteralPath $sd)) { continue }
    Get-ChildItem -LiteralPath $sd -File | Where-Object { $_.Extension -in '.bat', '.cmd', '.vbs', '.lnk' } | ForEach-Object {
      $target = $_.FullName; $text = ''
      if ($_.Extension -eq '.lnk') { $lnk = $shell.CreateShortcut($_.FullName); $target = $lnk.TargetPath; $text = "$($lnk.TargetPath) $($lnk.Arguments)" }
      $isScript = $target -and (Test-Path -LiteralPath $target) -and [IO.Path]::GetExtension($target) -in '.bat', '.cmd', '.vbs'
      if ($isScript) { $text += ' ' + (Get-Content -LiteralPath $target -Raw -ErrorAction SilentlyContinue) }
      if ($text -match '--kiosk|app\.showcase\.space') {
        New-Item -ItemType Directory -Force -Path $backup | Out-Null
        Set-Content -Path (Join-Path $backup "$($_.Name).from.txt") -Value $sd -Encoding UTF8
        Move-Item -LiteralPath $_.FullName -Destination (Join-Path $backup $_.Name) -Force
        # stop the copy that is running now, or its loop keeps fighting the new launcher until a restart
        if ($isScript) {
          $name = [IO.Path]::GetFileName($target)
          Get-CimInstance Win32_Process -Filter "Name='cmd.exe' OR Name='wscript.exe'" | Where-Object { $_.CommandLine -like "*$name*" } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        }
        $moved += "$($_.Name) (from $sd)"
      }
    }
  }

  Set-Content -Path $config -Encoding UTF8 -Value @("Url=$Url", "WifiProfile=$wifiProfile", "Mode=$Mode")
  # console mode: Chrome writes a dated log in the display user's own folder (%LOCALAPPDATA%\ShowcaseChromeLogs),
  # kept 14 days. Not in ProgramData: the log can carry the page URL and its keys.

  $src = @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace ShowcaseKiosk
{
    public static class Win
    {
        public delegate bool EnumProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr lParam);
        [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr hWnd, uint cmd);
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
        [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder sb, int max);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
        [DllImport("user32.dll")] public static extern bool GetLastInputInfo(ref LASTINPUTINFO info);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint mods, uint vk);
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr value);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern bool SystemParametersInfo(uint action, uint param, string value, uint winIni);

        [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)] public struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }

        // Fleet (trial 7): per-monitor DPI aware (v2), so window and screen sizes are real pixels on every screen,
        // whatever each one's scaling; older Windows falls back to system aware
        public static void DpiAware()
        {
            try { if (SetProcessDpiAwarenessContext(new IntPtr(-4))) return; } catch { }
            try { SetProcessDPIAware(); } catch { }
        }

        // Fleet: the screen Showcase belongs on. With Fleet's support screen installed, Windows' main display is
        // the hidden support screen, so use the first real screen the support screen program reports; else the main one.
        // Trial 7: a read that fails or lands mid-write keeps the last good answer.
        static string lastScreenName = "";

        public static Rectangle ShowcaseScreen()
        {
            string name = RealScreenName();
            if (name != null) lastScreenName = name;
            if (lastScreenName.Length > 0)
                foreach (Screen sc in Screen.AllScreens) if (sc.DeviceName == lastScreenName) return sc.Bounds;
            return Screen.PrimaryScreen.Bounds;
        }

        // the first real screen in the support screen program's state file; "" = no support screen (no file, or no
        // real screen listed), null = it couldn't be read this time
        static string RealScreenName()
        {
            try
            {
                string state = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), @"showcase_fleet\support_screen\state.json");
                if (!File.Exists(state)) return "";
                string s;
                // share everything, so the writer can still swap the file in while this reads it
                using (FileStream fs = new FileStream(state, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                using (StreamReader r = new StreamReader(fs)) s = r.ReadToEnd();
                if (!s.TrimEnd().EndsWith("}")) return null;
                int i = s.IndexOf("\"realScreens\":[");
                if (i < 0) return null;
                if (string.CompareOrdinal(s, i, "\"realScreens\":[\"", 0, 16) != 0) return "";
                int start = i + 16, sp = s.IndexOf(' ', start);
                if (sp < 0) return null;
                return s.Substring(start, sp - start).Replace("\\\\", "\\");
            }
            catch { return null; }
        }

        // Showcase Blackout's black screen is up: a visible ShowcaseBlackout window (the same test Showcase Pin uses)
        public static bool BlackoutShowing()
        {
            HashSet<uint> pids = new HashSet<uint>();
            foreach (Process p in Process.GetProcessesByName("ShowcaseBlackout")) { pids.Add((uint)p.Id); p.Dispose(); }
            if (pids.Count == 0) return false;
            bool showing = false;
            EnumWindows(delegate(IntPtr h, IntPtr l)
            {
                uint pid;
                GetWindowThreadProcessId(h, out pid);
                if (pids.Contains(pid) && IsWindowVisible(h)) { showing = true; return false; }
                return true;
            }, IntPtr.Zero);
            return showing;
        }

        // seconds since anyone touched the screen, mouse or keyboard
        public static int IdleSeconds()
        {
            LASTINPUTINFO li = new LASTINPUTINFO();
            li.cbSize = (uint)Marshal.SizeOf(li);
            if (!GetLastInputInfo(ref li)) return 0;
            return (int)(((uint)Environment.TickCount - li.dwTime) / 1000);
        }

        // bring a window to the front; Windows only allows it after a key event, hence the Alt tap
        public static bool Activate(IntPtr h)
        {
            if (GetForegroundWindow() == h) return true;
            keybd_event(0x12, 0, 0, UIntPtr.Zero);
            keybd_event(0x12, 0, 2, UIntPtr.Zero);
            SetForegroundWindow(h);
            Thread.Sleep(300);
            return GetForegroundWindow() == h;
        }
    }

    public class Config
    {
        public string Url = "", WifiProfile = "", Mode = "kiosk", Dir, LogPath;

        public static Config Load(string dir)
        {
            Config c = new Config();
            c.Dir = dir;
            c.LogPath = Path.Combine(dir, "kiosk.log");
            string file = Path.Combine(dir, "kiosk.config");
            if (File.Exists(file))
                foreach (string line in File.ReadAllLines(file))
                {
                    int eq = line.IndexOf('=');
                    if (eq < 0) continue;
                    string k = line.Substring(0, eq).Trim(), v = line.Substring(eq + 1).Trim();
                    if (k == "Url") c.Url = v;
                    else if (k == "WifiProfile") c.WifiProfile = v;
                    else if (k == "Mode") c.Mode = v.ToLowerInvariant();
                }
            // polling keeps Showcase in sync with the tablet; add it once, with ? or & as the URL needs
            if (c.Url.Length > 0 && c.Url.IndexOf("polling=", StringComparison.OrdinalIgnoreCase) < 0)
                c.Url += (c.Url.IndexOf('?') < 0 ? "?" : "&") + "polling=true";
            return c;
        }

        // scheme and host only, for logs: the full URL carries the auth token
        public string Site { get { try { return new Uri(Url).GetLeftPart(UriPartial.Authority); } catch { return "(bad URL)"; } } }
    }

    public static class Net
    {
        // the Showcase site answers at all (any HTTP status counts); no answer within 10 s = down
        public static bool SiteUp(string site)
        {
            try
            {
                ServicePointManager.SecurityProtocol |= (SecurityProtocolType)3072; // TLS 1.2
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(site + "/");
                req.Method = "HEAD";
                req.Timeout = 10000;
                using (req.GetResponse()) { }
                return true;
            }
            catch (WebException e) { return e.Response != null; }
            catch { return false; }
        }

        static string Netsh(string args)
        {
            try
            {
                ProcessStartInfo si = new ProcessStartInfo("netsh.exe", args);
                si.UseShellExecute = false; si.CreateNoWindow = true; si.RedirectStandardOutput = true;
                using (Process p = Process.Start(si)) { string o = p.StandardOutput.ReadToEnd(); p.WaitForExit(15000); return o; }
            }
            catch { return ""; }
        }

        // null = this NUC has no Wi-Fi interface (network cable), true/false = Wi-Fi connected
        public static bool? WifiConnected(out string profile)
        {
            profile = "";
            string o = Netsh("wlan show interfaces");
            bool any = false, connected = false;
            foreach (string raw in o.Split('\n'))
            {
                string line = raw.Trim();
                int c = line.IndexOf(':');
                if (c < 0) continue;
                string k = line.Substring(0, c).Trim(), v = line.Substring(c + 1).Trim();
                if (k.Equals("State", StringComparison.OrdinalIgnoreCase)) { any = true; if (v.Equals("connected", StringComparison.OrdinalIgnoreCase)) connected = true; }
                if (k.Equals("Profile", StringComparison.OrdinalIgnoreCase)) profile = v;
            }
            if (!any) return null;
            return connected;
        }

        public static void WifiConnect(string profile) { Netsh("wlan connect name=\"" + profile + "\""); }
    }

    // One pause for all the Showcase tools. Ctrl+Alt+Q writes "paused until" to a shared file that the
    // kiosk launcher and the pin both read, so one key pauses both. Whichever tool got the key handles it.
    public static class SharedPause
    {
        static readonly string FilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "ShowcasePause.txt");
        public static readonly TimeSpan Length = TimeSpan.FromMinutes(30);

        public static DateTime Until
        {
            get
            {
                try
                {
                    if (!File.Exists(FilePath)) return DateTime.MinValue;
                    long ticks;
                    return long.TryParse(File.ReadAllText(FilePath).Trim(), out ticks) ? new DateTime(ticks) : DateTime.MinValue;
                }
                catch { return DateTime.MinValue; }
            }
        }

        public static bool Active { get { return DateTime.Now < Until; } }

        public static void Toggle()
        {
            try
            {
                if (Active) File.Delete(FilePath);
                else File.WriteAllText(FilePath, (DateTime.Now + Length).Ticks.ToString());
            }
            catch { }
        }
    }

    public class Kiosk : Form
    {
        readonly Config config;
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        readonly Queue<DateTime> launches = new Queue<DateTime>();
        DateTime lastLaunch = DateTime.MinValue, lastHeal = DateTime.Now, holdUntil = DateTime.MinValue;
        int missing;
        bool wasPaused;
        volatile bool reloadWanted;
        const int WM_HOTKEY = 0x0312, HOTKEY_ID = 1;

        public Kiosk(Config config)
        {
            this.config = config;
            ShowInTaskbar = false;
            FormBorderStyle = FormBorderStyle.None;
            IntPtr h = Handle; // the hotkey needs a window handle; this window is never shown
            bool hotkey = Win.RegisterHotKey(h, HOTKEY_ID, 2 | 1 | 0x4000, (uint)Keys.Q); // Ctrl+Alt+Q, no repeat
            Log("==== Showcase Kiosk " + Program.Version + " started for " + config.Site
                + (hotkey ? ", Ctrl+Alt+Q pauses it for 30 minutes" : ", Ctrl+Alt+Q is held by Showcase Pin (the pause still applies here)"));
            UserSettings();
            WaitForSite(TimeSpan.FromMinutes(3));
            Launch();

            Thread net = new Thread(NetworkLoop);
            net.IsBackground = true;
            net.Start();

            timer.Interval = 10000;
            timer.Tick += delegate { Tick(); };
            timer.Start();
        }

        protected override void SetVisibleCore(bool value) { base.SetVisibleCore(false); }

        // Windows nags that can pop over Showcase, for this user (repeated every start, so it sticks)
        void UserSettings()
        {
            try
            {
                Set(@"Software\Microsoft\Windows\CurrentVersion\PushNotifications", "ToastEnabled", 0);
                Set(@"Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement", "ScoobeSystemSettingEnabled", 0);
                string cdm = @"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager";
                Set(cdm, "SubscribedContent-310093Enabled", 0);
                Set(cdm, "SubscribedContent-338389Enabled", 0);
                Set(cdm, "SoftLandingEnabled", 0);
                Set(cdm, "SystemPaneSuggestionsEnabled", 0);
            }
            catch (Exception e) { Log("Could not switch off Windows notifications: " + e.Message); }

            // the support wallpaper the installer drew: only seen if Showcase closes and stays closed
            try
            {
                string[] walls = Directory.GetFiles(config.Dir, "showcase_support_wallpaper_*.png");
                if (walls.Length > 0)
                {
                    using (RegistryKey k = Registry.CurrentUser.CreateSubKey(@"Control Panel\Desktop"))
                    {
                        k.SetValue("WallpaperStyle", "10");   // fill the screen
                        k.SetValue("TileWallpaper", "0");
                    }
                    Set(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers", "BackgroundType", 0);   // a picture, not a slideshow or Spotlight
                    Win.SystemParametersInfo(0x14, 0, walls[0], 3);   // SPI_SETDESKWALLPAPER, saved and broadcast
                }
            }
            catch (Exception e) { Log("Could not set the support wallpaper: " + e.Message); }
        }

        static void Set(string key, string name, int value)
        {
            using (RegistryKey k = Registry.CurrentUser.CreateSubKey(key)) k.SetValue(name, value, RegistryValueKind.DWord);
        }

        void WaitForSite(TimeSpan max)
        {
            DateTime until = DateTime.Now + max;
            if (Net.SiteUp(config.Site)) { Log("Site answers, launching"); return; }
            Log("Waiting for " + config.Site + " to answer (up to " + (int)max.TotalMinutes + " minutes)");
            while (DateTime.Now < until)
            {
                Thread.Sleep(10000);
                if (Net.SiteUp(config.Site)) { Log("Site answers, launching"); return; }
            }
            Log("Site still not answering, launching anyway");
        }

        static string ProfileDir
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Google\Chrome\User Data\showcase"); }
        }

        // Fleet: Fleet's own browser processes (its window and screen tests run in Chrome or Edge with a
        // showcase_fleet_manager_window or showcase_fleet_screen_N profile), and the processes they started.
        // Trial 7: by the profile only; Showcase's own command line can have showcase_fleet in it (trial 6's log path did)
        static readonly System.Text.RegularExpressions.Regex FleetProfile = new System.Text.RegularExpressions.Regex(
            @"showcase_fleet_(manager_window|screen_\d)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        static HashSet<int> FleetBrowsers()
        {
            HashSet<int> fleet = new HashSet<int>();
            try
            {
                List<int[]> others = new List<int[]>();   // process, its parent
                using (System.Management.ManagementObjectSearcher s = new System.Management.ManagementObjectSearcher(
                    "SELECT ProcessId, ParentProcessId, CommandLine FROM Win32_Process WHERE Name='chrome.exe' OR Name='msedge.exe'"))
                    foreach (System.Management.ManagementObject o in s.Get())
                    {
                        int pid = Convert.ToInt32(o["ProcessId"]), parent = Convert.ToInt32(o["ParentProcessId"]);
                        string cl = o["CommandLine"] as string;
                        if (cl != null && FleetProfile.IsMatch(cl)) fleet.Add(pid); else others.Add(new int[] { pid, parent });
                    }
                foreach (int[] p in others) if (fleet.Contains(p[1])) fleet.Add(p[0]);
            }
            catch { }
            return fleet;
        }

        // Fleet: leaves Fleet's own windows alone, so opening Showcase never closes the window a tech is working in
        static void CloseBrowsers()
        {
            HashSet<int> keep = FleetBrowsers();
            foreach (string n in new string[] { "chrome", "msedge" })
                foreach (Process p in Process.GetProcessesByName(n))
                    if (!keep.Contains(p.Id)) try { p.Kill(); } catch { }
            Thread.Sleep(2000);
        }

        // Fleet: Chrome's own log for console mode, a new dated file each launch (Chrome starts its log afresh every
        // launch), 14 days kept. Trial 7: in the display user's own folder, not ProgramData: it can carry the URL's keys
        static string ChromeLog()
        {
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ShowcaseChromeLogs");
            try
            {
                Directory.CreateDirectory(dir);
                foreach (string f in Directory.GetFiles(dir, "chrome_*.log"))
                    if (File.GetLastWriteTime(f) < DateTime.Now.AddDays(-14)) File.Delete(f);
            }
            catch { }
            return Path.Combine(dir, "chrome_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".log");
        }

        void StartChrome()
        {
            // Fleet modes: kiosk (as before); console = kiosk plus remote debugging (inspect from the support
            // screen with chrome://inspect) and a dated Chrome log; troubleshoot = a normal window with DevTools
            bool trouble = config.Mode == "troubleshoot";
            string args = (trouble ? "\"" + config.Url + "\"" : "--kiosk \"" + config.Url + "\"") + " --autoplay-policy=no-user-gesture-required"
                + " --user-data-dir=\"" + ProfileDir + "\" --window-name=\"showcase\" --disk-cache-size=2174836480"
                + " --no-first-run --no-default-browser-check --disable-background-timer-throttling"
                + " --disable-backgrounding-occluded-windows --disable-renderer-backgrounding"
                + " --disable-features=CalculateNativeWinOcclusion,IntensiveWakeUpThrottling,SideBySide,SideBySideLinkMenuNewBadge,SideBySideSessionRestore"
                + " --disable-pinch" + (trouble ? " --start-maximized --auto-open-devtools-for-tabs" : " --start-fullscreen");
            if (config.Mode == "console")
                args += " --remote-debugging-port=9222 --enable-logging --log-file=\"" + ChromeLog() + "\"";
            // on the real screen, not the support screen (Fleet's support screen makes them different)
            Rectangle s = Win.ShowcaseScreen();
            args += " --window-position=" + s.X + "," + s.Y + " --window-size=" + s.Width + "," + s.Height;
            ProcessStartInfo si = new ProcessStartInfo("chrome.exe", args);
            si.UseShellExecute = true; // finds Chrome wherever it is installed
            Process.Start(si);
        }

        void Launch()
        {
            CloseBrowsers();
            if (!Directory.Exists(ProfileDir))
            {
                // brand-new profile: Chrome can show a one-off first-run screen, so open, wait, reopen (from the bat file with delivery optimisation, first run only)
                Log("New Chrome profile: first-run launch, reopening in 30 seconds");
                StartChrome();
                Thread.Sleep(30000);
                CloseBrowsers();
            }
            StartChrome();
            lastLaunch = DateTime.Now;
            launches.Enqueue(lastLaunch);
            Log("Chrome launched");
        }

        // Fleet (trial 7): Fleet's browsers, refreshed every 30 s, so the Fleet window ("Showcase Fleet") is never
        // taken for Showcase
        HashSet<int> fleetBrowsers = new HashSet<int>();
        DateTime fleetBrowsersAt = DateTime.MinValue;

        // the Showcase window: Chrome, titled "showcase" (--window-name), or filling the main screen
        IntPtr FindShowcase()
        {
            IntPtr found = IntPtr.Zero;
            if (DateTime.Now - fleetBrowsersAt > TimeSpan.FromSeconds(30)) { fleetBrowsers = FleetBrowsers(); fleetBrowsersAt = DateTime.Now; }
            HashSet<uint> chrome = new HashSet<uint>();
            foreach (Process p in Process.GetProcessesByName("chrome")) { if (!fleetBrowsers.Contains(p.Id)) chrome.Add((uint)p.Id); p.Dispose(); }
            Rectangle screen = Win.ShowcaseScreen();
            long need = (long)screen.Width * screen.Height * 9 / 10;
            Win.EnumWindows(delegate(IntPtr h, IntPtr l)
            {
                if (!Win.IsWindowVisible(h) || Win.IsIconic(h) || Win.GetWindow(h, 4) != IntPtr.Zero) return true;
                uint pid;
                Win.GetWindowThreadProcessId(h, out pid);
                if (!chrome.Contains(pid)) return true;
                StringBuilder sb = new StringBuilder(256);
                Win.GetWindowText(h, sb, sb.Capacity);
                Win.RECT r;
                Win.GetWindowRect(h, out r);
                Rectangle o = Rectangle.Intersect(Rectangle.FromLTRB(r.Left, r.Top, r.Right, r.Bottom), screen);
                if (sb.ToString().IndexOf("showcase", StringComparison.OrdinalIgnoreCase) >= 0 || (long)o.Width * o.Height >= need)
                {
                    found = h;
                    return false;
                }
                return true;
            }, IntPtr.Zero);
            return found;
        }

        static bool RemoteSession() { return Process.GetProcessesByName("remoting_desktop").Length > 0; }

        // Ctrl+Alt+Q: maintenance pause, shared with Showcase Pin. For 30 minutes nothing is reopened,
        // reloaded or reset, so Chrome can be closed or worked on. Press again to end it early.
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID)
            {
                SharedPause.Toggle(); // Tick logs the change
                Tick();
                return;
            }
            base.WndProc(ref m);
        }

        void Tick()
        {
            if (SharedPause.Active)
            {
                if (!wasPaused) { wasPaused = true; Log("Paused until " + SharedPause.Until.ToString("HH:mm") + " (Ctrl+Alt+Q)"); }
                return;
            }
            if (wasPaused) { wasPaused = false; Log("Pause over"); }
            IntPtr w = FindShowcase();

            // 1. Chrome closed or crashed: reopen it (twice in a row missing, not in the first minute after a launch)
            if (w == IntPtr.Zero)
            {
                missing++;
                while (launches.Count > 0 && DateTime.Now - launches.Peek() > TimeSpan.FromMinutes(10)) launches.Dequeue();
                if (missing >= 2 && DateTime.Now - lastLaunch > TimeSpan.FromMinutes(1) && DateTime.Now > holdUntil)
                {
                    if (launches.Count >= 3)
                    {
                        holdUntil = DateTime.Now.AddMinutes(10);
                        Log("Chrome has closed 3 times in 10 minutes. Waiting 10 minutes before trying again.");
                    }
                    else
                    {
                        Log("Showcase window gone. Reopening Chrome.");
                        Launch();
                    }
                }
                return;
            }
            missing = 0;

            // Fleet (trial 7): while Blackout's black screen is up, nothing is brought to the front (it would lift
            // Showcase over the black screen until Blackout's next check); a wanted reload waits until it's down
            bool blackout = Win.BlackoutShowing();

            // 2. the network came back after an outage: reload the page (it may be sitting on an error page)
            if (reloadWanted && !blackout)
            {
                reloadWanted = false;
                if (Win.Activate(w)) { SendKeys.SendWait("{F5}"); Log("Page reloaded after the outage"); }
                else { Log("Could not bring Showcase to the front to reload. Reopening Chrome instead."); Launch(); }
                return;
            }

            // 3. every ~100 s, when nobody has touched the screen for 2 minutes and nobody is connected remotely:
            //    go back to the first tab (Ctrl+1). Never Ctrl+W: with one tab it would close Chrome. Never the zoom (Ctrl+0):
            //    techs set it by hand per NUC over remote access, because Showcase's text size follows it (trial 8).
            if (DateTime.Now - lastHeal > TimeSpan.FromSeconds(100))
            {
                lastHeal = DateTime.Now;
                if (Win.IdleSeconds() >= 120 && !RemoteSession() && !blackout && Win.Activate(w))
                {
                    SendKeys.SendWait("^1");
                }
            }
        }

        // checks the site every 30 s; reconnects Wi-Fi when it is down; asks for a reload once it is back
        void NetworkLoop()
        {
            bool wasDown = false;
            int fails = 0;
            while (true)
            {
                Thread.Sleep(30000);
                try
                {
                    if (Net.SiteUp(config.Site))
                    {
                        if (wasDown) { Log("[NET] Site answering again after " + fails + " failed checks"); reloadWanted = true; }
                        wasDown = false;
                        fails = 0;
                        continue;
                    }
                    fails++;
                    if (!wasDown) Log("[NET] Site not answering");
                    wasDown = true;
                    string profile;
                    bool? wifi = Net.WifiConnected(out profile);
                    if (wifi == false)
                    {
                        string p = config.WifiProfile.Length > 0 ? config.WifiProfile : profile;
                        if (p.Length > 0)
                        {
                            Net.WifiConnect(p);
                            if (fails == 1 || fails % 10 == 0) Log("[NET] Wi-Fi disconnected, reconnecting to '" + p + "'");
                        }
                    }
                    else if (fails % 20 == 0) Log("[NET] Still not answering after " + fails + " checks");
                }
                catch (Exception e) { Log("[NET] check failed: " + e.Message); }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; return; }
            base.OnFormClosing(e);
        }

        void Log(string msg) { Program.Write(config.LogPath, msg); }
    }

    public static class Program
    {
        public const string Version = "trial8_241026";
        static readonly object logLock = new object();

        public static void Write(string path, string msg)
        {
            lock (logLock)
            {
                try
                {
                    FileInfo f = new FileInfo(path);
                    if (f.Exists && f.Length > 1048576) { File.Copy(path, path + ".old", true); File.Delete(path); }
                    File.AppendAllText(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + msg + Environment.NewLine);
                }
                catch { }
            }
        }

        // ShowcaseKiosk.exe           run (settings from kiosk.config beside the exe)
        // ShowcaseKiosk.exe --check   write check.txt: settings, site, Wi-Fi, Chrome window. Changes nothing.
        [STAThread]
        public static void Main(string[] args)
        {
            Win.DpiAware();
            string dir = AppDomain.CurrentDomain.BaseDirectory;
            Config config = Config.Load(dir);

            if (args.Length > 0 && args[0] == "--check")
            {
                StringBuilder r = new StringBuilder();
                r.AppendLine("Version:       " + Version);
                r.AppendLine("Site:          " + (config.Url.Length > 0 ? config.Site : "(no URL set)"));
                if (config.Url.Length > 0) r.AppendLine("Site answers:  " + (Net.SiteUp(config.Site) ? "yes" : "NO"));
                string profile;
                bool? wifi = Net.WifiConnected(out profile);
                r.AppendLine("Wi-Fi:         " + (wifi == null ? "no Wi-Fi adapter (network cable)" : wifi == true ? "connected to '" + profile + "'" : "NOT connected"));
                r.AppendLine("Remote session: " + (Process.GetProcessesByName("remoting_desktop").Length > 0 ? "yes" : "no"));
                r.AppendLine("Idle:          " + Win.IdleSeconds() + " s");
                try { File.WriteAllText(Path.Combine(dir, "check.txt"), r.ToString()); } catch { }
                return;
            }

            if (config.Url.Length == 0) { Write(config.LogPath, "No URL in kiosk.config. Run the installer with the auth URL."); return; }

            bool first;
            using (Mutex mutex = new Mutex(true, @"Local\ShowcaseKiosk", out first))
            {
                if (!first) return; // already running; the 5-minute task trigger lands here

                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.ThreadException += delegate(object s, ThreadExceptionEventArgs e) { Write(config.LogPath, "Error: " + e.Exception.Message); };
                AppDomain.CurrentDomain.UnhandledException += delegate(object s, UnhandledExceptionEventArgs e) { Write(config.LogPath, "Crashed: " + e.ExceptionObject); };

                Kiosk kiosk = new Kiosk(config);
                Application.Run();
                GC.KeepAlive(kiosk);
            }
        }
    }
}
'@
  Add-Type -TypeDefinition $src -ReferencedAssemblies System.Windows.Forms, System.Drawing, System.Management -OutputAssembly $exe -OutputType WindowsApplication

  $action    = New-ScheduledTaskAction -Execute $exe -WorkingDirectory $dir
  $atLogon   = New-ScheduledTaskTrigger -AtLogOn -User $user
  # every 5 minutes: brings the launcher back if it ever closes, does nothing while it is running
  $revive    = New-ScheduledTaskTrigger -Once -At (Get-Date).Date -RepetitionInterval (New-TimeSpan -Minutes 5)
  $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
  $settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
  Register-ScheduledTask -Force -TaskName $task -Action $action -Trigger @($atLogon, $revive) -Principal $principal -Settings $settings | Out-Null

  # the check runs as the display user, like the launcher: admin never runs a program from a folder Users can change
  $check = Join-Path $dir 'check.txt'
  Remove-Item $check -Force -ErrorAction SilentlyContinue
  try { $code = Invoke-AsDisplayUser $exe '--check' 45 } catch { $code = $_.Exception.Message }
  $found = if (Test-Path $check) { Get-Content $check } else { @("The check did not run ($code).") }

  Start-ScheduledTask -TaskName $task
  Start-Sleep -Seconds 3

  Write-Host ''
  if (Get-Process ShowcaseKiosk -ErrorAction SilentlyContinue) {
    Write-Host "Done. Showcase Kiosk $version is running; Showcase reopens in a few seconds." -ForegroundColor Green
  } else {
    Write-Host "Installed, but it is not running. Check $dir\kiosk.log" -ForegroundColor Yellow
  }
  $found | ForEach-Object { Write-Host "  $_" }
  if ($moved.Count) { Write-Host "  Old startup script moved to $backup :"; $moved | ForEach-Object { Write-Host "    $_" } }
  else { Write-Host '  No old startup script found in the Startup folders.' }
  Write-Host "  Running as: $user"
  Write-Host "  Log:        $dir\kiosk.log"
  Write-Host ''
  Write-Host 'Restart the NUC once when convenient: Fast Startup only switches off on the next restart.' -ForegroundColor Cyan
}
