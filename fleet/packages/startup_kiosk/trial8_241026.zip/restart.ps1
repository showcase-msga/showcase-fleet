# startup_kiosk: "Reopen Showcase now" (trial 6). Restarts the Kiosk launcher, which closes Chrome (never the
# Fleet window) and opens Showcase again. For a new URL or mode from This NUC, press Reinstall instead.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
if (-not (Get-ScheduledTask -TaskName 'Showcase Kiosk' -ErrorAction SilentlyContinue)) { Fail 'Startup Kiosk is not installed.'; return }
Stop-ScheduledTask -TaskName 'Showcase Kiosk' -ErrorAction SilentlyContinue
Get-Process ShowcaseKiosk -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 1
Start-ScheduledTask -TaskName 'Showcase Kiosk'
Ok 'Kiosk restarted: Showcase reopens once the site answers (a few seconds).'
Info 'A new URL or mode from This NUC needs Reinstall, which rewrites the Kiosk settings.'
