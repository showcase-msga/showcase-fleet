# startup_kiosk: status (trial 6). Returns a hashtable; reads only.
$kTask = Get-ScheduledTask -TaskName 'Showcase Kiosk' -ErrorAction SilentlyContinue
if (-not $kTask) { return @{ installed = $false } }
$dir = Join-Path $env:ProgramData 'ShowcaseKiosk'
$version = "$(Get-Content (Join-Path $dir 'fleet_version.txt') -ErrorAction SilentlyContinue | Select-Object -First 1)".Trim()
if (-not $version) { $version = 'standalone' }   # Showcase Kiosk installed before Fleet
$mode = 'kiosk'
$m = Select-String -Path (Join-Path $dir 'kiosk.config') -Pattern '^Mode=(.+)$' -ErrorAction SilentlyContinue | Select-Object -First 1
if ($m) { $mode = $m.Matches[0].Groups[1].Value.Trim() }
$kiosk = [bool](Get-Process ShowcaseKiosk -ErrorAction SilentlyContinue)
$pin = [bool](Get-Process ShowcasePin -ErrorAction SilentlyContinue)
$pinTask = [bool](Get-ScheduledTask -TaskName 'Showcase Pin' -ErrorAction SilentlyContinue)
@{ installed = $true; version = $version; problem = -not ($kiosk -and $pin)
   detail = "Mode: $mode. Kiosk $(if ($kiosk) { 'running' } else { 'not running' }), Pin $(if ($pin) { 'running' } elseif ($pinTask) { 'not running' } else { 'not installed' })." }
