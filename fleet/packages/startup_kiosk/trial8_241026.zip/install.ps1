# startup_kiosk: install or update (trial 8, 24 Oct 2026). Runs the Fleet copies of the Showcase Kiosk and
# Showcase Pin installers with the URL, mode and name from This NUC (nuc.config).
# Trial 7: whatever the bat launcher's Remove puts back in a Startup folder is set aside again, so one launcher runs.
. (Join-Path $PSScriptRoot '..\..\app\common.ps1')
$Version = 'trial8_241026'

$cfg = Get-NucConfig
if (-not $cfg.ShowcaseUrl) { Fail 'No Showcase URL for this NUC yet. Set it in This NUC (or press "Read from this NUC" there), save, then install this again.'; return }
Ok "Showcase URL from This NUC: $(Hide-UrlKeys $cfg.ShowcaseUrl)"
Info "Mode: $($cfg.LauncherMode). Name: $(if ($cfg.NucId) { $cfg.NucId } else { "$env:COMPUTERNAME (no NUC name set in This NUC)" })"

# one launcher per NUC
$batRemove = Join-Path $PSScriptRoot '..\showcase_startup_bat\remove.ps1'
if ((Test-Path (Join-Path $FleetData 'launcher\version.txt')) -and (Test-Path $batRemove)) {
  Info 'Removing showcase_startup.bat first (one launcher per NUC)...'
  & $batRemove
  # its Remove puts back the startup scripts it set aside; set them aside again for Kiosk (Kiosk's Remove restores them)
  try {
    $again = @(Move-OldStartup (Join-Path $env:ProgramData 'ShowcaseKiosk\old-startup'))
    foreach ($m in $again) { Ok "Set aside again for Kiosk: $m" }
  } catch { Warn "Could not check the Startup folders: $($_.Exception.Message)" }
}

Info ''
Info '---- Showcase Kiosk ----'
& (Join-Path $PSScriptRoot 'kiosk_installer.ps1') -Url $cfg.ShowcaseUrl -Mode $cfg.LauncherMode
Info ''
Info '---- Showcase Pin ----'
& (Join-Path $PSScriptRoot 'pin_installer.ps1') -SiteName $cfg.NucId

Set-Content (Join-Path $env:ProgramData 'ShowcaseKiosk\fleet_version.txt') $Version -ErrorAction SilentlyContinue
Info ''
if ((Get-Process ShowcaseKiosk -ErrorAction SilentlyContinue) -and (Get-Process ShowcasePin -ErrorAction SilentlyContinue)) { Ok "Startup Kiosk $Version is running (Kiosk and Pin)" }
else { Warn 'Installed, but Kiosk or Pin is not running. Check the logs.' }
